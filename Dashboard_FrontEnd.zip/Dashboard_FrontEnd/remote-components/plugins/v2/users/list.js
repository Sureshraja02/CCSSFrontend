import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Table from "Table";
import loadData from "loadData";
import usePageContext from "usePageContext";
import ListLayout from "ListLayout";
const headers = [

  {
    id: "userID",
    label: "id",
    //    width: "200",
    type: "text",
    hidden: true,
  },
  {
    id: "userName",
    label: "user Name",
    //    width: "200",
    type: "text",
  },
  {
    id: "groupName",
    label: "group Name",
    //    width: "200",
    type: "text",
  },

  {
    id: "email",
    label: "email",
    //    width: "200",
    type: "text",
  },

  {
    id: "instID",
    label: "Institution ID",
    //    width: "200",
    type: "text",
  },

  {
    id: "insertDate",
    label: "created At",
    //    width: "200",
    type: "date",
  },

  {
    id: "modifiedDate",
    label: "updated At",
    //    width: "200",
    type: "date",
  },







];

const InstitionManagement = () => {
  const { setCurrentPage, setPageData } = usePageContext();
  const [selectedRows, setSelectedRows] = useState([]);
  const [tableData, setTableData] = useState([]);

  const [pageSize, setpageSize] = useState(10);

  const [pageNo, setpageNo] = useState(1);



  const storeSelectedRows = (e) => {
    console.warn(e);
    setSelectedRows(e);
  };

  const ld = () => {
    loadData.get("/app/rest/v1.0/fetch/user/10/0", {}).then((res) => {
      if ("content" in res) setTableData(res);
    });
  };

  useEffect(() => {
    ld();
    console.log("into call");
  }, []);

  const triggernewRegistration = () => {
    setCurrentPage("v2-users-create");
  };

  const triggerEditIns = (id) => {
    setPageData({
      id
    });

    setCurrentPage("v2-users-create");
  }

  return (
    <>
      <ListLayout
        title={"User List"}
        subTitle={"to manage the list of users in application"}
      >
        <Row>
          <Col>
            <Table
              title={"User List"}
              subTitle={"Users maintained in the application"}
              tableData={tableData}
              headers={headers}
              suffix={"User"}
              selectType={"radio"}
              selectKey={"userID"}
              pageNoCallback={(a) => setpageNo(a)}
              selectedRowCallback={(e) => storeSelectedRows(e)}
              refreshCallback={() => ld()}
              newEntryCallback={() => triggernewRegistration()}
              //  deleteCallback={(e) => console.log(e)}
              editCallback={(e) => triggerEditIns(e)}
              customHeaderComponents={
                <>
                  {/* <button
                    type="button"
                    className="btn fis-outline ml-10 mr-10"
                    onClick={() => console.warn(selectedRows)}
                    disabled={selectedRows.length === 1 ? false : true}
                  >
                    Edit User
                  </button> */}
                </>
              }
            ></Table>
          </Col>
        </Row>
      </ListLayout>
    </>
  );
};
export default InstitionManagement;
