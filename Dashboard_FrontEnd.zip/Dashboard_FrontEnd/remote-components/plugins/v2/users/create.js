import React, { useEffect, useState } from "react";
import RenderForm from "RenderForm";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import sendData from "sendData";
import loadData from "loadData";
import userCreation from "../../../json/userRegistration.json";
import hash from 'hash';
import addNotification from 'addNotification';
import usePageContext from "usePageContext";
function CreateUser({ id }) {
  const [formData, SetFormData] = useState([]);

  const { setCurrentPage, setPageData } = usePageContext();

  const callback = (values, actions) => {

    //create account first but api not available
    // var data = {
    //   email,
    //   instId,
    //   mobileNo: phoneNo,
    //   password,
    //   userName: email,
    //   userType: "admin",
    // };


    values['password'] = hash(values['password']);
    values['confPassword'] = null;






    sendData.post("/app/rest/v1.0/save/user", values).then((d) => {
      addNotification({
        id: Math.random(),
        type: "success",
        title: "Success",
        desc: "Record inserted / updated successfully.",
      });


      setCurrentPage("v2-users-list");
    });


  };

  useEffect(() => {

    if (id != undefined) {
      console.debug("id to load : " + id);
      loadData.get("/app/rest/v1.0/fetch/user/" + id, {}).then((res) => {
        SetFormData(res);
      });
    }
  }, [id]);


  return (
    <>
      <>
        <div className={`p-4`}>
          <Row>
            <Col lg={8}>
              <Heading
                title="User Creation"
                subHeading={
                  ""}
              />

              <RenderForm formFormat={userCreation} formData={formData} callback={callback} cancelCallback={() => setCurrentPage("v2-users-list")} />
            </Col>
          </Row>
        </div>
      </>
    </>
  );
}

export default CreateUser;
