import React, { useEffect, useState } from "react";
import Heading from "Heading";
import Row from "Row";
import Col from "Col";
import Card from "Card";
import Chart from 'Chart';
import CategoryScale from 'CategoryScale';
import BarChart from "BarChart";
import LineChart from "LineChart";
import PieChart from "PieChart";
import DonutChart from "DonutChart";
import loadData from "loadData";
import useGlobalContext from "useGlobalContext";
import mixColors from "mixColors";
import LoadingComponent from "Loading";
import Moment from "Moment";
import PolarAreaChart from "PolarAreaChart";
import { ArrowClockwise } from "react-bootstrap-icons";
import Modal from "Modal";
import Table from "Table";




Chart.register(CategoryScale);
function Flow() {

    const [timeline, settimeline] = useState("TODAY");
    const [loading, setloading] = useState(false);

    const [inlineLoading, setinlineLoading] = useState(false);

    const [LayersChart, setLayersChart] = useState({});

    const [ChannelChart, setChannelChart] = useState({});
    const [modalisOpen, setmodalisOpen] = useState(false);

    const [modelName, setmodelName] = useState(null);

    const [modalData, setmodalData] = useState({});

    const [modelUrl, setmodelUrl] = useState(null);

    const [pageSize, setpageSize] = useState(10);

    const [pageNo, setpageNo] = useState(1);

   const chartColors = [
  "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF",
  "#FF9F40", "#C9CBCF", "#8E44AD", "#2ECC71", "#E74C3C", "#3498DB", "#F1C40F"
];


    const { globalState, updateGlobalState } = useGlobalContext();

    const plugins = [{
        beforeInit: (chart) => {
            const dataset = chart.data.datasets[0];
            chart.data.labels = [dataset.label];
            dataset.data = [dataset.percent, 100 - dataset.percent];
        }
    },
    {
        beforeDraw: (chart) => {

            var width = chart.width,
                height = chart.height,
                ctx = chart.ctx;
            ctx.restore();
            var fontSize = (height / 80).toFixed(2);
            ctx.font = fontSize + "em roboto-regular";
            ctx.fillStyle = globalState.appPrimaryColor;
            ctx.textBaseline = "middle";
            var text = chart.data.datasets[0].percent + "%",
                textX = Math.round((width - ctx.measureText(text).width) / 2),
                textY = height / 2;
            ctx.fillText(text, textX, textY);
            ctx.save();
        }
    }
    ];

    const donutOptions = {
        plugins: {
            legend: {
                display: false
            },
            tooltips: {
                filter: tooltipItem => tooltipItem.index === 0
            },
            maintainAspectRatio: false,
            cutoutPercentage: 85,

        },
        responsive: true,
        cutout: "85%",
    }





    const options = {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };


    // const dashData = {
    //     "CompliantsReceived": 10,
    //     "FreezedAccounts": 5,
    //     "TotalTxns": 2000000,
    //     "TotalSuspeciousTxns": 20000,
    // }

    const defaultData =
    {
        "totalCompliantsReceived": "0",
        "freezedAccounts": "0",
        "openComplaints": "0",
        "closeComplaints": "0",
        "successCount": "0.0",
        "failureCount": "0.0",
        "challengeCount": "0.0",
        "debitCreditCard": "0",
        "phonecalls": "0",
        "wallet": "0",
        "ibank": "0",
        "dematFraud": "0",
        "debitCreditCardPercentage": "0.0",
        "phonecallsPercentage": "0.0",
        "walletPercentage": "0.0",
        "ibankPercentage": "100.0",
        "creditCardFraud": "0",
        "businessFraud": "0",
        "txnsCount": {
            "count": [
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0"
            ],
            "date": [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ]
        },
        "statusCount": {
            "success": "0.0",
            "failure": "0.0",
        }
    }



    const [dashData, setdashData] = useState(defaultData);

    const [pieData, setpieData] = useState({});

    const [barData, setbarData] = useState({});


    const headers = [

        {
            id: "0",
            label: "dummy",
            //    width: "200",
            type: "text",
            hidden: false,
        },
		{
            id: "1",
            label: "Acknowledgement Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "2",
            label: "Account Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "3",
            label: "RRN",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "4",
            label: "Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "5",
            label: "Disputed Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "6",
            label: "Transaction Date",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        
        {
            id: "8",
            label: "Status",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "9",
            label: "Reason",
            //    width: "200",
            type: "text",
            hidden: false,
        },

        
    ]



    const loadAPI = (timeline) => {

        setloading(true);
        loadData.get("/app/rest/v1.0/service/nccrpdashboard", { timeline }).then((res) => {


            setdashData(res);
            const dt = res;

            const pieData = res['statusCount'];

            var keys = [];
            var values = [];
            if (pieData != null) {
                Object.keys(pieData).map((d, i) => {
                    keys.push(d);
                    values.push(pieData[d]);
                });

                setpieData({
                    labels: keys,
                    values: values
                });
            }


            const lineData = res['layersMap'];
            keys = [];
            values = [];

            Object.keys(lineData).map((d, i) => {
                keys.push(d);
                values.push(lineData[d]);
            });

            setLayersChart({
                labels: keys,
                values: values
            });



            const channelMap = res['channelMap'];
            keys = [];
            values = [];

            Object.keys(channelMap).map((d, i) => {
                keys.push(d);
                values.push(channelMap[d]);
            });

            setChannelChart({
                labels: keys,
                values: values
            });


            setloading(false);




        });
    }


    useEffect(() => {

        loadAPI(timeline);

    }, [timeline]);




    const renderSumAmount = (num) => {
        if (num != null && num > 0) {
            if (num >= 100000) {
                return (num / 100000).toFixed(1) + "L";
            } else if (num >= 1000) {
                return (num / 1000).toFixed(1) + "K";
            } else {
                return num;
            }
        }
        return num;
    }



    const loadDataFromAPI = (id, filter = {
        timeline: timeline
    }) => {
       
        console.log(modelUrl);
       
        if (modelUrl) {
            setmodalisOpen(true)
            setinlineLoading(true);
            loadData.get(`${modelUrl}${pageSize}/${pageNo - 1}`, filter).then((res) => {
                setmodalData(res);
                setinlineLoading(false);
               
            });
        }

    }




    useEffect(() => {
        loadDataFromAPI();
        updateTimelineInfo(timeline);
     
        updateGlobalState({
            timeline: timeline,
         
          });
    }, [pageNo]);


    const triggerfilterCallback = (ackNo) => {
        loadDataFromAPI(null, {
            acknowledgementNo: ackNo,
            timeline: timeline
        })
    }

    const updateTimelineInfo = (timelineValue) => {
        

        var timeLineLabel='Today';
      
        if(timelineValue=='TODAY')
        {
            timeLineLabel='Today';
        }
        if(timelineValue=='YESTERDAY')
        {
            timeLineLabel='Yesterday----';
        }
        if(timelineValue=='DAYBYESTER')
            {
                timeLineLabel='Day before Yesterday'; 
            }
            if(timelineValue=='7DAY')
                {
                    timeLineLabel='Last 7 Days'; 
                }
                if(timelineValue=='MONTH')
                    {
                        timeLineLabel='This Month';  
                    }
                    if(timelineValue=='YTD')
                        {
                            timeLineLabel='This Year';   
                        }
        updateGlobalState({
            timeline: timelineValue,
            timelineLable:timeLineLabel,
         
          });
    }



    return (
        <>
            <div className="p-4">
                <Heading title="Dashboard" subTitle={`Overview of ${timeline} day data`} />
                <Row>

                    <Col sm={12} md={12} lg={12}>
                        <Row>
                            <Col sm={9} md={9} lg={9}>
                                {dashData !== undefined && dashData['lastTxnDt'] && (
                                    <div className="fis-primary">
                                        Last Txn received Time : {dashData['lastTxnDtAsString']}
                                    </div>
                                )}
                            </Col>
                            <Col sm={3} md={3} lg={3}>

                                <Row>

                                    <Col className={`justify-flex-end`}>
                                        <button className={`custom-reload-button btn btn-outline`} onClick={() => loadAPI(timeline)}>
                                            <ArrowClockwise size={20} />
                                        </button>
                                    </Col>

                                    <Col>
                                        <select className="btn btn-fis-outline bg-fis-secondary fis-primary ml-10 mr-10" name="reportSelect"
                                            style={{
                                                float: "right",
                                            }}

                                            onClick={(e) => {settimeline(e.target.value), updateTimelineInfo(e.target.value);}}
                                        >
                                            <option value="TODAY" >Today</option>
                                            <option value="YESTERDAY" >Yesterday</option>
                                            <option value="DAYBYESTER" >Day before Yesterday</option>
                                            <option value="7DAY" >Last 7 Days</option>
                                            <option value="MONTH" >This Month</option>
                                            <option value="YTD">YTD</option>
                                        </select>
                                    </Col>
                                </Row>


                            </Col>
                        </Row>
                    </Col>
                </Row>


                {(!loading) ? (<>
                    <Row>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-primary-2">
                                        <p className="mini-card-heading uppercase">Total no:of Ack Received </p>
                                        <div className="h1 font-bolder fis-primary">
                                            {dashData['noOfAck']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>







                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Total no:of ack processed </p>
                                        <div className="h1 font-bolder fis-info">
                                            {dashData['noOfAckProcessed']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>

                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">no:of ack successfully processed </p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder fis-success"    onClick={() => {
                                                 
                                                   //setmodelUrl(`/app/rest/v1.0/service/getFullySuccessRecord/`)
                                                    // loadDataFromAPI()
                                                    
                                                }}>
                                                    
                                                    {dashData['noOfackSucceeded']}

                                                  
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="fis-primary">
                                                    <div className="max-height-50">
                                                        <DonutChart data={{
                                                            datasets: [{
                                                                percent: (dashData !== undefined && dashData['statusCount'] ? dashData['statusCount']['success'] : 0),
                                                                backgroundColor: [globalState.appPrimaryColor,
                                                                globalState.appSecondaryColor]
                                                            }]
                                                        }} options={donutOptions} plugins={plugins} />
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>

                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>

                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">no:of ack partially processed </p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder fis-info cursor-pointer"


                                                    onClick={() => {
                                                   // setmodelUrl(`/app/rest/v1.0/service/getPartialSuccessRecord/`)                                                   
                                                   // loadDataFromAPI()
                                                    //setmodelName("Partially Processed")
                                                  
                                                }}
                                                                                                // onClick={() => {
                                                //     setmodelUrl("/app/rest/v1.0/service/nccrpComplaintstatus/")
                                                //     setmodalisOpen(true)
                                                //     loadDataFromAPI()
                                                // }}

                                                >
                                                    {dashData['noOfackPartiallyCompleted']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="fis-primary">
                                                    <div className="max-height-50">
                                                        <DonutChart data={{
                                                            datasets: [{
                                                                percent: (dashData !== undefined && dashData['statusCount'] ? dashData['statusCount']['partiallyCompleted'] : 0),
                                                                backgroundColor: [globalState.appPrimaryColor,
                                                                globalState.appSecondaryColor]
                                                            }]
                                                        }} options={donutOptions} plugins={plugins} />
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>


                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">no:of ack failed proceesing </p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder fis-danger cursor-pointer"
                                                onClick={() => {
                                                   // setmodelUrl(`/app/rest/v1.0/service/getFullyFailedRecord/`)
                                                    //loadDataFromAPI()
                                                    //setmodelName("Fully Failed")
                                                   
                                                }}
                                                // onClick={() => {

                                                //     setmodelUrl("/app/rest/v1.0/service/nccrpComplaintstatus/")
                                                //     setmodalisOpen(true)
                                                //     loadDataFromAPI()
                                                // }}

                                                >
                                                    {dashData['noOfackFailed']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="fis-primary">
                                                    <div className="max-height-50">
                                                        <DonutChart data={{
                                                            datasets: [{
                                                                percent: (dashData !== undefined && dashData['statusCount'] ? dashData['statusCount']['failure'] : 0),
                                                                backgroundColor: [globalState.appPrimaryColor,
                                                                globalState.appSecondaryColor]
                                                            }]
                                                        }} options={donutOptions} plugins={plugins} />
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>




                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">No:Of Txns Received</p>
                                        <div className="h1 font-bolder fis-info">
                                            {dashData['noOftxn']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>



                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">No:Of Txns Processed</p>
                                        <div className="h1 font-bolder fis-warning">
                                            {dashData['noOftxnProcessed']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">No:of Hold Made</p>
                                        <div className="h1 font-bolder fis-warning">
                                            {dashData['noOfAccountsHolded']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">No:of Accounts holded</p>
                                        <div className="h1 font-bolder fis-warning">
                                            {dashData['noOfHoldMade']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Sum of Dispute Amount</p>
                                        <div className="h1 font-bolder fis-danger">
                                            {renderSumAmount(dashData['amtofDisputeMade'])}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Sum of Hold Amount</p>
                                        <div className="h1 font-bolder fis-success">
                                            {renderSumAmount(dashData['amtOfHoldMade'])}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Digital block Count</p>
                                        <div className="h1 font-bolder fis-success">
                                            {(dashData['digitalBlockCount'])}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                    </Row>




                    <Row>


                        {LayersChart !== undefined && LayersChart['labels'] !== undefined && (

                            <Col sm={8} md={8} lg={8}>

                                <div className="p-1">
                                    <Card className="">
                                        <div className="p-3 ">
                                            <Heading title="Layers Count" />
                                            <div className="">
                                                <LineChart data={{
                                                    labels: LayersChart['labels'],
                                                    // datasets is an array of objects where each object represents a set of data to display corresponding to the labels above. for brevity, we'll keep it at one object
                                                    datasets: [{
                                                        data: LayersChart['values'],
                                                        tension: 0.4,
                                                        borderColor: globalState.appPrimaryColor,
                                                        label: 'Layers',
                                                        backgroundColor: globalState.appSecondaryColor,

                                                    }],
                                                }} options={options} />
                                            </div>
                                        </div>
                                    </Card>
                                </div>

                            </Col>
                        )}

                        {/* {pieData !== undefined && pieData['labels'] !== undefined && (

                            <Col sm={4} md={4} lg={4}>
                                <div className="p-1">
                                    <Card className="">
                                        <div className="p-3 min-height-500">
                                            <Heading title="Ack Status Count" />
                                            <div className="">
                                                <PieChart data={{
                                                    labels: pieData['labels'],
                                                    datasets: [{
                                                        data: pieData['values'],
                                                        backgroundColor: [
                                                            globalState.appPrimaryColor,
                                                            globalState.appSecondaryColor,
                                                            mixColors(globalState.appPrimaryColor, globalState.appSecondaryColor, 20)
                                                        ],
                                                    }]
                                                }} />
                                            </div>
                                        </div>
                                    </Card>
                                </div>
                            </Col>
                        )} */}



                        {ChannelChart !== undefined && ChannelChart['labels'] !== undefined && (

                            <Col sm={4} md={4} lg={4}>
                                <div className="p-1">
                                    <Card className="">
                                        <div className="p-3 min-height-500">
                                            <Heading title="Channel wise Count" />
                                            <div className="">
                                                <DonutChart
  data={{
    labels: ChannelChart['labels'],
    datasets: [{
      data: ChannelChart['values'],
      backgroundColor: chartColors.slice(0, ChannelChart['values'].length),
    }]
  }}
/>
                                            </div>
                                        </div>
                                    </Card>
                                </div>
                            </Col>
                        )}


                    </Row>
                    {/* 
                    <Row>

                        <Col>
                            <Heading title="Channel-wise Compliants statistics" />
                        </Col>

                    </Row>

                    <Row>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-primary-2">
                                        <p className="mini-card-heading uppercase">E-Wallet </p>

                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['wallet']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Debit/Credit Card</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['debitCreditCard']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Demat /Depository Fraud</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['dematFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Credit Card Fraud</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['creditCardFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Business Email Compromise</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['businessFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-success-2">
                                        <p className="mini-card-heading uppercase">Internet Banking</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['ibank']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Fraud Call</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['phonecalls']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">UPI</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['phonecalls']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                    </Row> */}
                </>
                ) : (
                    <LoadingComponent show={loading}>

                    </LoadingComponent>
                )}



                <Modal isOpen={modalisOpen} title={modelName} handleClose={() => setmodalisOpen(!modalisOpen)} close={true}>
                    <>
                        <Table
                            tableData={modalData}
                            headers={headers}
                            pageNoCallback={(a) => setpageNo(a)}
                            isLoading={inlineLoading}
                            filterCallback={(e) => triggerfilterCallback(e.target.value)}
                            filterLabel={"acknowledgement no"}
                            
                        ></Table>
                    </>
                </Modal>


            </div>
        </>
    );
}

export default Flow;
