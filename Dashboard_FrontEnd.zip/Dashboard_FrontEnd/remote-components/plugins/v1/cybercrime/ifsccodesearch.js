import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import usePageContext from "usePageContext";
import RenderForm from "RenderForm";
import TextBox from "TextBox";
import Card from "Card";
import Modal from "Modal";
import sendData from "sendData";
import loadData from "loadData";
import ListLayout from "ListLayout";
import Table from "NewTable";
import message from "message";







const columns = [
    {
        title: 'SNo',
        dataIndex: 'sNo',
        key: 'sNo',
    },
    {
        title: 'Bank Name',
        dataIndex: 'bankName',
        key: 'bankName',
    },
    {
        title: 'Bank Code',
        dataIndex: 'bankCode',
        key: 'bankCode',
    },
    {
        title: 'IFSCCODE',
        dataIndex: 'ifscCode',
        key: 'ifscCode',
    },
];



const index = ({
    values
}) => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [formData, setformData] = useState([]);
    const [radioBtndata, setradioBtndata] = useState([]);
    const [ModalData, setModalData] = useState([]);
    const [postContent, setPostContent] = useState('');
    const [ifsccodeData, setIfsccodeData] = useState([]);
    const [i4CCallBackRequest, setI4CCallBackRequest] = useState([]);
    const [totalItems, setTotalItems] = useState(0);


    const requestOptions = {
        defaultValue: '',
    };

    const toggleModal = () => {
        setmodalisOpen(!modalisOpen);
    }





    const isEmptyObject = (obj) => Object.keys(obj).length === 0;
    const callback = (values, actions) => {


        requestOptions['ifsccode'] = values['defaultValue'];
        if (isEmptyObject(values)) {

            message.info('Please Fill the search Box');
        }
        else {
            sendData.post("/app/rest/v1.0/service/ifsccodesearch", requestOptions).then((d) => {

                message.open({

                    type: 'loading',
                    content: 'Loading...',
                });

                if (isEmptyObject(d['bankDetails'])) {

                    message.info('No record Found for the Search');
                }
                else {
                    setIfsccodeData(d['bankDetails']);

                    setTotalItems(5);
                }




            });

            toggleModal();
        }




    };



    const triggerAccountList = () => {




        setCurrentPage("v1-cybercrime-accountview");
    }





    return (
        <>
            <div className="p-4">

                <Row>
                    <Col>
                        <Heading
                            title="IFSC Code Search"

                        />
                    </Col>
                </Row>
                <Row>
                    <Col>

                        <RenderForm formFormat={[]} formData callback={callback} cancel={false}>

                            {(props) => {


                                return (

                                    <>
                                        <Row>


                                            <Col sm={6} md={6} lg={6}>


                                                <div className="form-group">

                                                    <label> Search by </label>


                                                    <TextBox
                                                        key={"txnId"}
                                                        label={""}
                                                        name={"defaultValue"}
                                                        placeholder={"Search key"}
                                                        value={props.values["defaultValue"]}
                                                        onChange={props.handleChange}
                                                        error={
                                                            props.errors.hasOwnProperty("defaultValue") &&
                                                            props.errors["defaultValue"]
                                                        }
                                                        id={"txnId"}
                                                        tooltip={"Enter a valid details"}
                                                        type={"text"}
                                                    />
                                                </div>
                                            </Col>
                                        </Row>





                                    </>

                                )
                            }}

                        </RenderForm>
                        <br></br>

                    </Col>
                </Row>
                <Heading
                    title="Bank Details"

                />
                <Table dataSource={ifsccodeData} columns={columns} scroll={{ x: 200, y: 150 }} headerSplitColor="#bae0ff" />;


            </div>


        </>
    );
};

export default index;
