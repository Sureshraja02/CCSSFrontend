import React, { useState } from 'react';
import newapi from 'newapi';
import sendData from "sendData";

const inputFields = [
  { name: 'bankCode', label: 'Bank Code', type: 'text' },
  { name: 'bankName', label: 'Bank Name', type: 'text' },
  {
    name: 'bankType',
    label: 'Bank Type',
    type: 'select',
    options: [
      { label: 'BNK', value: 'BNK' },
      { label: 'WLT', value: 'WLT' },
      { label: 'MER', value: 'MER' },
      { label: 'PPI', value: 'PPI' },
      { label: 'CBD', value: 'CBD' },
        { label: 'INS', value: 'INS' },
    ],
  },
  { name: 'ifscCode', label: 'IFSC Code', type: 'text' },
];

 
const IfscMaster = () => {
  const [formData, setFormData] = useState({});
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    sendData.post("/app/rest/v1.0/service/ifscCodeInsertApi", formData)
      .then((res) => {
        if (res === "Success" || res.data === "Success") {
          setMessage("Bank details inserted successfully!");
        } else {
          setMessage("Unexpected response from server.");
        }
      })
      .catch((error) => {
        console.error("API call failed:", error);
        setMessage("Failed to insert bank details.");
      });
  };

  return (
    <div className="container mt-4 px-5 pt-3">
      <h3 className='pb-3'>IFSC Master</h3>
      {message && (
        <div className="mt-3 alert alert-info">
          {message}
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <div className="row">
          {inputFields.map((field) => (
            <div key={field.name} className="col-md-6 mb-3">
              <label htmlFor={field.name} className="form-label">{field.label}</label>
              {field.type === 'select' ? (
                <select
                  className="form-control"
                  id={field.name}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select {field.label}</option>
                  {field.options.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type={field.type}
                  className="form-control"
                  id={field.name}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleChange}
                  required
                />
              )}
            </div>
          ))}
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
};

export default IfscMaster;
