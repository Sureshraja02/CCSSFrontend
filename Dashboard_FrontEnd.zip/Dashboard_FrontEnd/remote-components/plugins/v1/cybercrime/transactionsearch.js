import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import usePageContext from "usePageContext";
import RenderForm from "RenderForm";
import TextBox from "TextBox";
import Card from "Card";
import Modal from "Modal";
import sendData from "sendData";
import loadData from "loadData";
import ListLayout from "ListLayout";
import Table from "NewTable";
import message from "message";




const columns = [
    {
        title: 'SNo',
        dataIndex: 'sNo',
        key: 'sNo',
    },
    {
        title: 'Acknowledgement No',
        dataIndex: 'acknowledgementNo',
        key: 'acknowledgementNo',
    },
    {
        title: 'Acct No',
        dataIndex: 'acctNo',
        key: 'acctNo',
    },
    {
        title: 'Sub Category',
        dataIndex: 'subCategory',
        key: 'subCategory',
    },
    {
        title: 'Complaint Date',
        dataIndex: 'complaintDate',
        key: 'complaintDate',
    },
    {
        title: 'Transaction Date',
        dataIndex: 'transactionDate',
        key: 'transactionDate',
    },
    {
        title: 'Amount',
        dataIndex: 'amount',
        key: 'amount',
    },
    ,
    {
        title: 'Disputed Amount',
        dataIndex: 'disputedAmount',
        key: 'disputedAmount',
    },

];



const ackResponsecolumns = [
    {
        title: 'SNo',
        dataIndex: 'sNo',
        key: 'sNo',
    },
    {
        title: 'Acknowledgement No',
        dataIndex: 'acknowledgementNo',
        key: 'acknowledgementNo',
    },
    {
        title: 'Response Date',
        dataIndex: 'complaintDate',
        key: 'complaintDate',
    },
    {
        title: 'Response Code',
        dataIndex: 'responseCode',
        key: 'responseCode',
    },
    {
        title: 'Response Msg',
        dataIndex: 'responseMsg',
        key: 'responseMsg',
    },
    {
        title: 'Message',
        dataIndex: 'message',
        key: 'message',
    },
];


const callBackResponsecolumns = [
    {
        title: 'SNo',
        dataIndex: 'sNo',
        key: 'sNo',
    },
    {
        title: 'Acknowledgement No',
        dataIndex: 'acknowledgementNo',
        key: 'acknowledgementNo',
    },
    {
        title: 'Acct No',
        dataIndex: 'acctNo',
        key: 'acctNo',
    },
    {
        title: 'Complaint Date',
        dataIndex: 'complaintDate',
        key: 'complaintDate',
    },
    {
        title: 'Remarks',
        dataIndex: 'remarks',
        key: 'remarks',
    },
    {
        title: 'Dispute Balance',
        dataIndex: 'disputeBalance',
        key: 'disputeBalance',
    },
    {
        title: 'Amount',
        dataIndex: 'amount',
        key: 'amount',
    },

    {
        title: 'Bene Name',
        dataIndex: 'beneName',
        key: 'beneName',
    },
    {
        title: 'Bene Remi Acct Num',
        dataIndex: 'beneRemiAcctNum',
        key: 'beneRemiAcctNum',
    },
    {
        title: 'Bene Remi Bank',
        dataIndex: 'beneRemiBank',
        key: 'beneRemiBank',
    },
    {
        title: 'Bene Remi Ifsc',
        dataIndex: 'beneRemiIfsc',
        key: 'beneRemiIfsc',
    },

    {
        title: 'Root Rrn',
        dataIndex: 'complaintRrn',
        key: 'complaintRrn',
    },

    {
        title: 'Rrn',
        dataIndex: 'txnRefNo',
        key: 'txnRefNo',
    },
];



const index = ({
    values
}) => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [formData, setformData] = useState([]);
    const [radioBtndata, setradioBtndata] = useState([]);
    const [ModalData, setModalData] = useState([]);
    const [postContent, setPostContent] = useState('');
    const [i4CRequestData, setI4CRequestData] = useState([]);
    const [i4CCallBackRequest, setI4CCallBackRequest] = useState([]);
    const [i4CCallBackResponse, setI4CCallBackResponse] = useState([]);
    const [i4CResponseData, setI4CResponseData] = useState([]);
    const [totalItems, setTotalItems] = useState(0);


    const requestOptions = {
        defaultValue: '',
    };

    const toggleModal = () => {
        setmodalisOpen(!modalisOpen);
    }




    const onOptionChange = e => {

        setradioBtndata(e.target.value);
    }
    const isEmptyObject = (obj) => Object.keys(obj).length === 0;
    const callback = (values, actions) => {


        requestOptions[radioBtndata] = values['defaultValue'];



        message.open({

            type: 'loading',
            content: 'Loading...',
        });
        sendData.post("/app/rest/v1.0/service/transactionSearchPage", requestOptions).then((d) => {

            if (isEmptyObject(d['i4CRequestData'])) {

                message.info('No record Found for the Search');
            }
            else {
                setI4CRequestData(d['i4CRequestData']);
                setI4CCallBackRequest(d['i4CCallBackRequest']);
                setI4CCallBackResponse(d['i4CCallBackResponse']);
                setI4CResponseData(d['i4CResponseData']);
                setTotalItems(5);
            }



            //setPostContent(d['i4CRequestJsonRequest']);
        });
        // sendData.post("/app/rest/v1.0/group/save", values).then((d) => {
        //   console.log(d);
        // });

        //       setCurrentPage("v1-cybercrime-accountview");

        //loadDataFromAPI(values['txnId']);

        toggleModal();
    };



    const triggerAccountList = () => {




        setCurrentPage("v1-cybercrime-accountview");
    }





    return (
        <>
            <div className="p-4">

                <Row>
                    <Col>
                        <Heading
                            title="Transaction Search"
                            subTitle="Search by Acknowledgement No"
                        />
                    </Col>
                </Row>
                <Row>
                    <Col>

                        <RenderForm formFormat={[]} formData callback={callback} cancel={false}>

                            {(props) => {


                                return (

                                    <>
                                        <Row>


                                            <Col sm={6} md={6} lg={6}>


                                                <div className="form-group">

                                                    <label> Search by </label>


                                                    <div className="form-check">
                                                        <input type="radio" name="rad" className="form-check-input" onChange={onOptionChange} value="acctNo" />
                                                        <label> Account Number </label>
                                                    </div>
                                                    <div className="form-check">
                                                        <input type="radio" className="form-check-input checked" onChange={onOptionChange} name="rad" value="acknowledgementNo" />
                                                        <label>  AcknowledgementNo Number </label>
                                                    </div>
                                                    <div className="form-check">
                                                        <input type="radio" className="form-check-input checked" onChange={onOptionChange} name="rad" value="transactionId" />
                                                        <label>  Transaction Ref Number </label>
                                                    </div>
                                                    <TextBox
                                                        key={"txnId"}
                                                        label={""}
                                                        name={"defaultValue"}
                                                        placeholder={"Search key"}
                                                        value={props.values["defaultValue"]}
                                                        onChange={props.handleChange}
                                                        error={
                                                            props.errors.hasOwnProperty("defaultValue") &&
                                                            props.errors["defaultValue"]
                                                        }
                                                        id={"txnId"}
                                                        tooltip={"Enter a valid details"}
                                                        type={"text"}
                                                    />
                                                </div>
                                            </Col>
                                        </Row>





                                    </>

                                )
                            }}

                        </RenderForm>
                        <br></br>

                    </Col>
                </Row>
                <Heading
                    title="I4C To Bank Request"

                />
                <Table dataSource={i4CRequestData} columns={columns} scroll={{ x: 1500, y: 150 }} headerSplitColor="#bae0ff" />
                <br></br>
                <Heading
                    title="Bank to I4C Ack"

                />
                <Table dataSource={i4CCallBackResponse} scroll={{ x: 1500, y: 150 }} columns={ackResponsecolumns} />
                <br></br>
                <Heading
                    title="Bank to I4C CallBack Request"

                />
                <Table dataSource={i4CCallBackRequest} scroll={{ x: 1500, y: 150 }} columns={callBackResponsecolumns} />
                <br></br>
                <Heading
                    title="I4C to Bank Ack"

                />
                <Table dataSource={i4CResponseData} scroll={{ x: 1500, y: 150 }} columns={ackResponsecolumns} />
            </div>


        </>
    );
};

export default index;
