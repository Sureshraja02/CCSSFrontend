import React, { useEffect, useState } from "react";
import RenderFlow from "RenderFlow";
import Heading from "Heading";
import Row from "Row";
import Col from "Col";
import Card from "Card";
import sendData from "sendData";

import groupJsonByKey from "groupJsonByKey";

import DagreLayout from "DagreLayout";
import Drawer from "Drawer";
import ReadOnlyField from "../../../components/ReadOnlyField";
import usePageContext from "usePageContext";


// const initialEdges = [
//     { id: '1-2', source: '1', target: '2', type: 'smoothstep' },
//     { id: '1-3', source: '1', target: '3', type: 'smoothstep' },
//     { id: '1-4', source: '1', target: '4', type: 'smoothstep' },
//     { id: '1-5', source: '1', target: '5', type: 'smoothstep' },
//     { id: '1-6', source: '1', target: '6', type: 'smoothstep' }

// ];





function Flow({ data }) {

    const [intialNodes, setintialNodes] = useState([]);

    const { setCurrentPage, setPageData } = usePageContext();

    const [layoutType, setlayoutType] = useState(null);

    const [acknowledgementNo, setacknowledgementNo] = useState(null);

    const [initalEdges, setinitalEdges] = useState([]);

    const [isDrawerOpen, setisDrawerOpen] = useState(false);

    const [DrawerData, setDrawerData] = useState({});
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [ModalData, setModalData] = useState([]);

    const whitelistedColumns = {
        "UPI": ['acknowledgementNo', 'accountNo', 'rrn', 'beneName', 'beneRemiAccNum', 'beneRemiIfsc', 'beneRemiBank', 'transactionTimeHh24mi', 'disputeAmount', 'channel', 'fraud_fg', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "IMPS": ['acknowledgementNo', 'accountNo', 'rrn', 'beneName', 'beneRemiAccNum', 'beneRemiIfsc', 'beneRemiBank', 'transactionTimeHh24mi', 'disputeAmount', 'channel', 'fraud_fg', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "RTGS": ['acknowledgementNo', 'accountNo', 'rrn', 'beneName', 'beneRemiAccNum', 'beneRemiIfsc', 'beneRemiBank', 'transactionTimeHh24mi', 'disputeAmount', 'channel', 'fraud_fg', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "NEFT": ['acknowledgementNo', 'accountNo', 'rrn', 'beneName', 'beneRemiAccNum', 'beneRemiIfsc', 'beneRemiBank', 'transactionTimeHh24mi', 'disputeAmount', 'channel', 'fraud_fg', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "ATM": ['acknowledgementNo', 'accountNo', 'rrn', 'channel', 'fraud_fg', 'atmId', 'atmPlace', 'atmBranch', 'disputeAmount', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "POS": ['acknowledgementNo', 'accountNo', 'rrn', 'channel', 'fraud_fg', 'terminalId', 'merchantId', 'merchantName', 'disputeAmount', 'amount', 'complaintRrn', 'txnTypeId', 'txnType'],
        "ECOM": ['acknowledgementNo', 'accountNo', 'rrn', 'channel', 'fraud_fg', 'terminalId', 'merchantId', 'merchantName', 'disputeAmount', 'amount', 'complaintRrn', 'txnTypeId', 'txnType']
    }

    useEffect(() => {

        console.log("data...." + data);

        if (data) {
            setlayoutType(data.type);
            loadDataFromAPI(data);
        }



    }, [data]);


    const randomPos = (i) => {
        return {
            x: (i % 10) * 200, y: Math.floor(i / 10) * 150
        }
    }

    const loadDataFromAPI = (data) => {



        const requestOptions = {
            [data.type]: data.value
        };

        if (data.type === "acknowledgementNo") {
            setacknowledgementNo(data.value);
        }


        // loadData.get("/app/rest/v1.0/service/nccrpsuspectedChain/" + id, {}).then((res) => {
        //   setModalData(res['chain']);
        // });

        sendData.post("/app/rest/v1.0/service/nccrpsuspectedChainv2", requestOptions).then((d) => {

            if ("fraudDetails" in d) d = d['fraudDetails'];

            if (Array.isArray(d) && d.length > 0) {
                let nodeArray = [];
                let edgeArray = [];


                if (data.type === "acknowledgementNo") {
                    nodeArray.push({
                        id: data.value,
                        position: { x: 0, y: 50 },
                        sourcePosition: 'right',
                        targetPosition: 'left',
                        type: "input",
                        data: { label: data.value },
                    });
                }


                const grp = groupJsonByKey(d, "complaintRrn");




                if (grp) {
                    Object.keys(grp).map((gp, _index) => {
                        if (_index === 0) {
                            setacknowledgementNo(grp[gp][_index]['acknowledgementNo']);
                        }



                        nodeArray.push({
                            id: gp,
                            position: { x: 250, y: _index * 100 },
                            sourcePosition: 'right',
                            targetPosition: 'left',
                            data: { label: gp },
                        });

                        if (data.type === "acknowledgementNo") {

                            edgeArray.push({
                                id: `${data.value}-${gp}`, source: data.value, target: gp, label: 'rrn', data: {
                                    //        startLabel: 'start edge label',
                                    endLabel: 'end edge label',
                                },
                            });
                        }

                        //sub divisions 
                        console.log(grp[gp]);
                        if (Array.isArray(grp[gp]) && grp[gp].length > 0) {

                            let rootRRN = null;

                            grp[gp].map((b, __index) => {
                                if (b['fraud_Fg'] === "R") {
                                    rootRRN = b;
                                }
                                if (b['fraud_Fg'] === "B") {

                                    nodeArray.push({
                                        id: b['id'].toString(),
                                        position: randomPos(_index + __index),
                                        sourcePosition: 'right',
                                        targetPosition: 'left',
                                        data: {
                                            label: b['txnRefNo'],
                                            ...b
                                        },
                                        type: 'output'
                                    });

                                    edgeArray.push({
                                        id: `${b.id}-${gp}`, source: gp, target: b['id'].toString(), label: b['channel'], type: "custom", data: {
                                            startLabel: rootRRN ? `${rootRRN['disputeBalance']} / ${rootRRN['holdAmount']}` : '',
                                            endLabel: `${b['disputeBalance']} / ${b['holdAmount']}`,
                                            label: b['channel']
                                        },
                                    });
                                }
                            });

                        }


                    });

                    const layouts = DagreLayout(nodeArray, edgeArray, { rankdir: 'LR', nodesep: 100, ranksep: 200, marginx: 20, marginy: 20 })
                    setintialNodes([...intialNodes, ...layouts.nodes]);
                    setinitalEdges([...initalEdges, ...layouts.edges]);
                }
                // data.forEach((d, __index) => {
                //     console.log(d);


                // });
            }
        }).catch((err) => {
            setCurrentPage("v1-cybercrime-listv2");
        });
    }


    useEffect(() => {
        console.log(intialNodes);
    }, [intialNodes]);



    const holdStatusTrigger = (acknowledgementNo) => {

        console.log(acknowledgementNo);

        sendData.post("/app/rest/v1.0/service/nccrpgetsupsectedHoldstatus", {
            acknowledgementNo: acknowledgementNo
        }).then((d) => {
            if (d) {
                setModalData(d);
                setmodalisOpen(true);
            }
        });
    }


    const getRRNDetails = (rrn) => {

        const data = {
            rrn: rrn
        }

        sendData.post("/app/rest/v1.0/service/nccrpsuspectedChainForRoot", data).then((d) => {

            console.log(d);
            if ("fraudDetail" in d) {
                console.log("into fraud details");
                console.log(d['fraudDetail']);
                return d['fraudDetail'];
            }

        });

        return null;
    }



    return (
        <>
            <div className="p-4">

                <Heading title="Suspected Chain" subTitle="Maps the Acknowledgement no with the beneficary"
                />
                <Row>
                    <Col sm={12} md={12} lg={12}>
                        <Card
                            title="Fraud Chain"
                            subTitle=""
                            customHeaderComponents={(
                                <button type="button" className='btn btn-success' onClick={() => holdStatusTrigger(acknowledgementNo)}>
                                    View Hold Status
                                </button>
                            )}
                        >
                            <RenderFlow
                                initialNodes={intialNodes}
                                intialEdges={initalEdges}
                                onNodeClickCallback={(e, n) => {
                                    if ("fraud_Fg" in n.data && n.data['fraud_Fg'] === "B") {
                                        console.log(n.data);
                                        setDrawerData(n.data);
                                        setisDrawerOpen(true);
                                    }
                                }}
                                fitView
                                attributionPosition="bottom-left"
                            ></RenderFlow>
                        </Card>
                    </Col>

                    <Drawer
                        open={isDrawerOpen}
                        onClose={() => setisDrawerOpen(!isDrawerOpen)}
                        direction='right'
                        className={`overflow-scroll height-100vh custom-drawer-width`}
                    >
                        <div>
                            {Object.keys(DrawerData).map((d, _index) => {

                                if ('channel' in DrawerData && whitelistedColumns[DrawerData['channel']].includes(d)) {
                                    return (
                                        <ReadOnlyField title={d}>
                                            {DrawerData[d]}
                                        </ReadOnlyField>
                                    )
                                }
                            })}
                        </div>
                    </Drawer>


                    {ModalData.map((d, i) => {
                        return (
                            <>
                                <tr className="table-row">
                                    <td className="table-cell ps-4">
                                        <>
                                            <span>
                                                {d.payer}
                                            </span>
                                        </>
                                    </td>
                                    <td className="table-cell ">
                                        <>
                                            <span>
                                                {d.payee}
                                            </span>
                                        </>


                                    </td>
                                </tr>

                            </>
                        )
                    })}

                </Row>
            </div>
        </>
    );
}

export default Flow;
