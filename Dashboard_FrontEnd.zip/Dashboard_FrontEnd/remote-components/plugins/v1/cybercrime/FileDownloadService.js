//import loadData from "loadData";
import newapi from 'newapi';
import { BACKEND_URL as API_BASE_URL } from "config";

// const API_BASE_URL = "http://localhost:9998/app/rest/v1.0";

class FileDownloadService {
    async downloadFile(fileName) {
        return newapi.newapi(`${API_BASE_URL}/download/${fileName}`, {
            responseType: 'blob',
        });
    }
}

export default new FileDownloadService();
