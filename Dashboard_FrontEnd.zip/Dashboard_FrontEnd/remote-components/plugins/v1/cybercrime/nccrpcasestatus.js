import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Table from "Table";
import loadData from "loadData";
import usePageContext from "usePageContext";
import ListLayout from "ListLayout";

const InstitionManagement = () => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState({});

    const [pageSize, setpageSize] = useState(10);

    const [pageNo, setpageNo] = useState(1);


    const headers = [

        {
            id: "0",
            label: "dummy",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "1",
            label: "acknowledgement No",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "2",
            label: "Success",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "3",
            label: "Beneficary not found",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "4",
            label: "Invalid RRN",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "5",
            label: "Invalid input param",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "6",
            label: "Invalid length",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "7",
            label: "API failed",
            //    width: "200",
            type: "text",
            hidden: false,
        },
    ]




    const storeSelectedRows = (e) => {
        console.warn(e);
        setSelectedRows(e);
    };


    const loadDataFromAPI = (id, filter = {}) => {
        loadData.get(`/app/rest/v1.0/service/nccrpComplaintstatus/${pageSize}/${pageNo - 1}`, filter).then((res) => {
            setTableData(res);
        });
    }






    useEffect(() => {
        loadDataFromAPI();
    }, []);


    useEffect(() => {
        loadDataFromAPI();
    }, [pageNo]);


    const triggerfilterCallback = (ackNo) => {
        loadDataFromAPI(null, {
            acknowledgementNo: ackNo
        })
    }





    return (
        <>
            <ListLayout
                title={"NCCRP Case Status"}
                subTitle={"List of reported cases and its necessary status are recorded here"}
            >
                <Row>
                    <Col>
                        <Table
                            title={"Reported Case status"}
                            subTitle={"Reported Cases status"}
                            tableData={tableData}
                            headers={headers}
                            suffix={"Report"}
                            pageNoCallback={(a) => setpageNo(a)}
                            // selectType={"radio"}
                            // selectKey={"id"}
                            //      name={"hello"}
                            selectedRowCallback={(e) => storeSelectedRows(e)}
                            filterCallback={(e) => triggerfilterCallback(e.target.value)}
                            filterLabel={"acknowledgement no"}
                            // refreshCallback={() => ld()}
                            //createlabel={"Register a Case"}
                            //newEntryCallback={() => triggernewRegistration()}
                            //             deleteCallback={(e) => console.log(e)}
                            //           editCallback={(e) => triggerEditIns(e)}
                            customHeaderComponents={
                                <>


                                </>
                            }
                        ></Table>
                    </Col>
                </Row>
            </ListLayout>
        </>
    );
};
export default InstitionManagement;
