import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import usePageContext from "usePageContext";
import RenderForm from "RenderForm";
import Card from "Card";
import sendData from "sendData";
import newapi from "newapi";

const Index = () => {
  const { setCurrentPage } = usePageContext();
  const [message, setMessage] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('CCSS');
  const [formFormat, setFormFormat] = useState([]);

  useEffect(() => {
    const reportOptions = {
      CCSS: [
        { value: 'Complaint via File', name: 'FILE' },
        { value: 'I4C Request', name: 'API' },
        { value: 'CCSS Overall Request', name: 'OVERALL' },
        { value: 'Transaction Hold Report', name: 'TRANSACTION' },
        { value: 'Digital Block Report', name: 'DIGITAL' },
        { value: 'Fully Succeess', name: 'SUCCESS' },
         { value: 'Fully Failed (Technical Failure)', name: 'FAILED_TECH' },
          { value: 'Fully Failed (Business Failure)', name: 'FAILED_BUS' },
           { value: 'Partial Success(Technical Failure)', name: 'PARTIAL_TECH' },
            { value: 'Partial Success(Business Failure)', name: 'PARTIAL_BUS' },
        // { value: 'Technical Error code Report', name: 'ERROR' }
      ]
    };

    setFormFormat([
      {
        data: [
          {
            type: 'select',
            name: 'downloadType',
            label: 'Report',
            id: 'downloadType',
            value: '',
            placeholder: 'Select a report',
            rData: null,
            data: reportOptions[selectedCategory] || [],
            validationType: 'string',
            validations: []
          },
          {
            type: 'date',
            name: 'fromDate',
            label: 'Start Date',
            id: 'fromDate',
            className: 'no-wrap',
            value: '',
            grid: 6,
            validationType: 'string',
            validations: []
          },
          {
            type: 'date',
            name: 'toDate',
            label: 'End Date',
            id: 'toDate',
            className: 'no-wrap',
            value: '',
            grid: 6,
            validationType: 'string',
            validations: []
          }
        ]
      }
    ]);
  }, [selectedCategory]);

  const callback = (values) => {
    console.debug(values);

    if (!values.downloadType || !values.fromDate || !values.toDate) {
      setMessage('Please fill all fields before submitting.');
      return;
    }

    sendData.post('/app/rest/v1.0/preparedownloadfile', values).then((d) => {
      if (d.status === '00') {
        if (d.reportOptions) {
          setFormFormat((prev) => {
            const updated = [...prev];
            const selectField = updated[0].data.find((f) => f.name === 'downloadType');
            if (selectField) {
              selectField.data = d.reportOptions;
            }
            return updated;
          });
        }

        newapi
          .newapi(`/app/rest/v1.0/download/${d.fileName}`, {
            responseType: 'blob'
          })
          .then((ress) => {
            const url = window.URL.createObjectURL(new Blob([ress]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', d.fileName);
            document.body.appendChild(link);
            link.click();
            setMessage('File downloaded successfully!');
          })
          .catch(() => {
            setMessage('File download failed!');
          });
      } else {
        setMessage(d.statusDesc);
      }
    });
  };

  return (
    <>
      <div className="p-4">
        {message && <div className="alert alert-info">{message}</div>}
        <Row>
          <Col>
            <Heading
              title="Reports"
              subTitle="NCCRP Specific reports can be downloaded here"
            />
          </Col>
        </Row>

        <Row>
          <Col>
            <div className="mb-3">
              <label><strong>Report Category:</strong></label><br />
              <label>
                <input
                  type="radio"
                  name="reportCategory"
                  value="CCSS"
                  checked={selectedCategory === 'CCSS'}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                />{' '}
                CCSS
              </label>
            </div>
          </Col>
        </Row>

        <Row>
          <Col sm={8} md={8} lg={8}>
            <Card>
              <div className="p-3">
                <RenderForm
                  formFormat={formFormat}
                  formData={{}}
                  callback={callback}
                  cancel={false}
                />
              </div>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default Index;
