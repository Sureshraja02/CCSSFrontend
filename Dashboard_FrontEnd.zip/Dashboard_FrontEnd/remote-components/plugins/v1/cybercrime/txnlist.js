import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Table from "Table";
import loadData from "loadData";
import usePageContext from "usePageContext";
import ListLayout from "ListLayout";

const InstitionManagement = () => {
  const { setCurrentPage, setPageData } = usePageContext();
  const [selectedRows, setSelectedRows] = useState([]);
  const [tableData, setTableData] = useState({});

  const [pageSize, setpageSize] = useState(10);

  const [pageNo, setpageNo] = useState(1);


  const headers = [

    {
      id: "payerAccountNumber",
      label: "Payer Account Number",
      //    width: "200",
      type: "text",
      hidden: true,
    },
    {
      id: "acknowledgementNo",
      label: "acknowledgementNo",
      //    width: "200",
      type: "link",
      callback: (a, b) => {
        setPageData({
          data: {
            type: 'acknowledgementNo',
            value: a
          }
        });

        setCurrentPage("v1-cybercrime-suspectedchain");
      },
    },

    {
      id: "transactionDate",
      label: "Transaction Date",
      //    width: "200",
      type: "text",
    },
    {
      id: "subCategory",
      label: "Sub Category",
      //    width: "200",
      type: "text",
    },

    {
      id: "modeOfPayment",
      label: "ModeOfPayment",
      //    width: "200",
      type: "text",
    },

    {
      id: "amount",
      label: "Amount",
      //    width: "200",
      type: "text",
    },
    {
      id: "payerMobileNumber",
      label: "Payer MobileNumber",
      //    width: "200",
      type: "text",
    },
    {
      id: "rrn",
      label: "rrn",
      //    width: "200",
      type: "link",
      callback: (a, b) => {
        setPageData({
          data: {
            type: 'rrn',
            value: a
          }
        });

        setCurrentPage("v1-cybercrime-suspectedchain");
      },

    },
    {
      id: "remarks",
      label: "remarks",
      //    width: "200",
      type: "text",
    },
  ];




  const storeSelectedRows = (e) => {
    console.warn(e);
    setSelectedRows(e);
  };


  const loadDataFromAPI = (id, filter = {}) => {
    loadData.get(`/app/rest/v1.0/service/nccrpComplaintHistory/${pageSize}/${pageNo - 1}`, filter).then((res) => {
      setTableData(res);
    });
  }






  useEffect(() => {
    loadDataFromAPI();
  }, []);


  useEffect(() => {
    loadDataFromAPI();
  }, [pageNo]);


  const triggerfilterCallback = (ackNo) => {
    loadDataFromAPI(null, {
      acknowledgementNo: ackNo
    })
  }



  const triggernewRegistration = () => {
    setCurrentPage("v1-cybercrime-newtxnlist");
  };

  const triggerEditIns = (id) => {
    setPageData({
      id
    });

    setCurrentPage("institution-v2-inscreation");
  }

  return (
    <>
      <ListLayout
        title={"NCCRP Case List"}
        subTitle={"List of reported cases and its necessary details are recorded here"}
      >
        <Row>
          <Col>
            <Table
              title={"Reported Case List"}
              subTitle={"Reported Cases"}
              tableData={tableData}
              headers={headers}
              suffix={"Report"}
              pageNoCallback={(a) => setpageNo(a)}
              // selectType={"radio"}
              // selectKey={"id"}
              //      name={"hello"}
              selectedRowCallback={(e) => storeSelectedRows(e)}
              filterCallback={(e) => triggerfilterCallback(e.target.value)}
              filterLabel={"acknowledgement no"}
              // refreshCallback={() => ld()}
              //createlabel={"Register a Case"}
              //newEntryCallback={() => triggernewRegistration()}
              //             deleteCallback={(e) => console.log(e)}
              //           editCallback={(e) => triggerEditIns(e)}
              customHeaderComponents={
                <>


                </>
              }
            ></Table>
          </Col>
        </Row>
      </ListLayout>
    </>
  );
};
export default InstitionManagement;
