import Card from "Card";
import Col from "Col";
import PieChart from "DonutChart";
import Heading from "Heading";
import React, { useEffect, useState } from "react";
import Row from "Row";
import sendData from "sendData";
import usePageContext from "usePageContext";
import ReadOnlyField from "../../../components/ReadOnlyField";
import Modal from "Modal";
import Timeline from "Timeline";
import { XCircleFill, CheckCircleFill, Envelope, Paperclip } from "react-bootstrap-icons";

const index = ({
    values
}) => {
    const { setCurrentPage } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [acctData, setAcctData] = useState([]);
    const [channelData, setChannelData] = useState([]);
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [modalisOpen3, setmodalisOpen3] = useState(false);
     const [modalisOpen4, setmodalisOpen4] = useState(false);

    const [timelineData, settimelineData] = useState(null);

    const [currentEmail, setcurrentEmail] = useState("STEP_1");

     const toggleModal3 = () => {
        setmodalisOpen3(!modalisOpen3);
    }

    const toggleModal = () => {
        setmodalisOpen(!modalisOpen);
    }

      const toggleModal4 = (d) => {
        setmodalisOpen4(!modalisOpen4);
        setcurrentEmail(d);
    }

      const toggleModal5 = () => {
        setmodalisOpen4(!modalisOpen4);
    }

    const data = {
        "name": "DEMO",
        "customerNo": ["demo 2"],
        "shortName": "XXXXXX",
        "accountType": "Saving Account",
        "balance": "1000",
        "acountOpeningDate": "10/10/10",
        "issuedBranch": "T-NAGAR",
        "status": "Active",
        "acctNo": "XXXX10",
        "mobileNo": "XXXXX145",
        "pan": "XXXXXXXX",
        "name": "Completed",
        "address": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "emailaadress": "demo@dd.com",
        "txnStatus": {
            labels: ['Success', 'Failure'],
            datasets: [{
                data: [60, 40],
                backgroundColor: [
                    '#009775',
                    '#4bcd3e',
                ],
            }]
        },
        "monthlyTxnStatus": {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            // datasets is an array of objects where each object represents a set of data to display corresponding to the labels above. for brevity, we'll keep it at one object
            datasets: [{
                label: 'Success',
                data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
                backgroundColor: [
                    '#4bcd3e',

                ],
            },
            {
                label: 'Failure',
                data: [2, 3, 5, 20, 80, 120, 70, 80, 90, 100],
                backgroundColor: [
                    '#8dc63f',
                ],
            }],
        }

    }
    useEffect(() => {

        //  loadData.get("/app/rest/v1.0/service/account/" + values['mobileNo'], {}).then((res) => {
        //  setdata(res['accountList']);
        // });


        sendData.post("/app/rest/v1.0/service/nccrpdemographicAccountInfo", values).then((res) => {

            if (res['accountList'][0] !== undefined) {


                setAcctData(res['accountList'][0]);
                setChannelData(res['accountList'][0]['channelStatisticsListData']);



            }
            else {
                setAcctData(data);
            }

        });


        //console.log('--------->>>' + d['accountList']);

        //values['acctNo'] = '0000007932818891';




    }, [values]);


 const timelineDt = {
        "STEP_1": {
            "Subject": "FR-0001/33455-Block the account",
            "Sender": "cybercrime@delhi.gov.in",
            "Body": "please block the account holder account no : 11222456 pan number : 123556789",
            "attachments": ["att-1.jpg", "att-2.jpg"],
            "type": "sender"
        },
        "STEP_2": {
            "Subject": "CX1232345567-FR-0001/33455-Block the account",
            "Sender": "bandraBranch@psb.in",
            "Body": "Dear Bandra Branch , please have a look into the below content received from cybercrime and respond to it promptly.please block the account holder account no : 11222456 pan number : 123556789",
            "type": "receiver"
        },
        "STEP_3": {
            "Subject": "CX1232345567-FR-0001/33455-Block the account",
            "Sender": "nodaloffice@psb.in",
            "Body": "Dear nodal office , We didnt receive any updates from bandra branch for the respective below email..please reply to the email promptly for the below content please block the account holder account no : 11222456 pan number : 123556789",
            "type": "receiver"
        }
    }


    return (
        <>
            <div className="p-4">

                <Row>
                    <Col>
                        <Heading
                            title="Demo Graphic View"
                            subTitle="Get to know the demo graphic view based on search criteria"
                        />
                    </Col>
                </Row>
                <Row>
                    <Col>


                        <Row>

                            <Card title="Account Details" customHeaderComponents={<><button className="btn btn-fis-secondary" >Freeze/Lien </button> &nbsp;
                             <button onClick={() => toggleModal3()} className="btn btn-fis-secondary">
                                                                           Mail Tracker
                                                                       </button></>}>
                                 <div className="p-2">
                                                                      
                                                                   </div>

                                                                    <Modal isOpen={modalisOpen4} handleClose={toggleModal5} close={true} title={"Mail Data"}>
                                                                   
                                                                                       <div>
                                                                   
                                                                                           {timelineDt[currentEmail]['type'] == "sender" ? (
                                                                   
                                                                                               <p>Sender : {timelineDt[currentEmail]['Sender']}</p>
                                                                                           ) : (
                                                                                               <p>Receiver : {timelineDt[currentEmail]['Sender']}</p>
                                                                                           )}
                                                                                           <p>Subject : {timelineDt[currentEmail]['Subject']}</p>
                                                                   
                                                                                           <p>Body : {timelineDt[currentEmail]['Body']}</p>
                                                                   
                                                                                           {"attachments" in timelineDt[currentEmail] && (
                                                                   
                                                                   
                                                                                               <p>attachments :
                                                                   
                                                                                                   {timelineDt[currentEmail]['attachments'].map((att, i) => {
                                                                                                       return <>
                                                                                                           <div className="attachment p-2" key={i}>
                                                                                                               <Paperclip color={"blue"} /><span>   {att} </span>
                                                                                                           </div>
                                                                                                       </>
                                                                                                   })}
                                                                   
                                                                   
                                                                                               </p>
                                                                   
                                                                                           )}
                                                                                       </div>
                                                                   
                                                                   
                                                                                   </Modal>
                                                                   
                               
                                                                     <Modal isOpen={modalisOpen3} handleClose={toggleModal3} close={true} title={"Case History"}>
                                                                   
                                                                                       <Timeline
                                                                                           mode={'left'}
                                                                                           items={[
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Mail received and forwarded to Ops team &nbsp; <Envelope color="blue" style={{ cursor: "pointer" }} onClick={() => toggleModal4("STEP_1")} />
                                                                                                           <p>10/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Ops team Entered the data
                                                                                                           <p>10/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Mail Forwared to Branch Based on the IFSC code : IFSC123457 &nbsp; <Envelope color="blue" style={{ cursor: "pointer" }} onClick={() => toggleModal4("STEP_2")} />
                                                                                                           <p>10/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Mail re-forwared to branch based on the IFSC code : IFSC123457 &nbsp; <Envelope color="blue" style={{ cursor: "pointer" }} onClick={() => toggleModal4("STEP_2")} />
                                                                                                           <p>11/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Mail re-forwared to branch based on the IFSC code : IFSC123457 &nbsp; <Envelope color="blue" style={{ cursor: "pointer" }} onClick={() => toggleModal4("STEP_2")} />
                                                                                                           <p>13/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                               {
                                                                                                   children: <>
                                                                                                       <div>
                                                                                                           Mail forwarded to Nodal Office &nbsp; <Envelope color="blue" style={{ cursor: "pointer" }} onClick={() => toggleModal4("STEP_3")} />
                                                                                                           <p>14/11/2024</p>
                                                                                                       </div>
                                                                                                   </>,
                                                                                               },
                                                                                           ]}
                                                                                       />
                                                                   
                                                                   
                                                                   
                                                                   
                                                                                   </Modal>
                               
                                <div className="p-2">

                                    <Row>

                                        <Col sm={6} md={6} lg={6} className="border-right-1">
                                            <div className="p-2">

                                                <Row>
                                                    <Col sm={6} md={6} lg={6}>
                                                        <ReadOnlyField title={"Customer No"}>
                                                            {acctData['customerNo']}
                                                        </ReadOnlyField>
                                                    </Col>
                                                    <Col sm={6} md={6} lg={6} style={{
                                                        display: "flex",
                                                        justifyContent: "flex-end",
                                                        alignItems: "center",
                                                    }}>



                                                    </Col>
                                                </Row>

                                                <ReadOnlyField title={"Name"}>

                                                    {acctData['name']}
                                                </ReadOnlyField>


                                                <ReadOnlyField title={"AccountNo"}>

                                                    {acctData['acctNo']}
                                                </ReadOnlyField>


                                                <ReadOnlyField title={"AccountStatus"}>
                                                    {acctData['status']}
                                                </ReadOnlyField>


                                                <ReadOnlyField title={"shortName"}>

                                                    {acctData['shortName']}
                                                </ReadOnlyField>






                                            </div>
                                        </Col>

                                        <Col sm={6} md={6} lg={6}>
                                            <div className="p-3">

                                                <Row>

                                                    <Heading title="Account Credit/Debit Ratio" />

                                                    <Col sm={6} md={6} lg={6}>
                                                        <div className="max-height-300">
                                                            <PieChart data={data['txnStatus']} options={{
                                                                plugins: {
                                                                    legend: {
                                                                        display: false
                                                                    },
                                                                },
                                                                cutout: "85%"
                                                            }} />
                                                        </div>
                                                    </Col>


                                                    <Col sm={6} md={6} lg={6}>

                                                        <ReadOnlyField title={"Account Opening Date"}>

                                                            {acctData['openDate']}
                                                        </ReadOnlyField>


                                                        <ReadOnlyField title={"Account Opening Branch"}>

                                                            {acctData['branchCode']}
                                                        </ReadOnlyField>

                                                        <ReadOnlyField title={"Account Balance"}>

                                                            {acctData['balance']}
                                                        </ReadOnlyField>

                                                    </Col>

                                                </Row>
                                            </div>
                                        </Col>
                                    </Row>

                                </div>
                            </Card>


                        </Row>


                    </Col>
                </Row>
                <div className="pb-2"></div>
                <Row>
                    <Card title={"Additional Details"}>
                        <Row>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"PAN"}>
                                    {acctData['pan']}
                                </ReadOnlyField>
                            </Col>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"Aadhar"}>
                                    {acctData['aadhar']}
                                </ReadOnlyField>
                            </Col>


                        </Row>
                        <Row>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"Mobile Number"}>
                                    {acctData['mobileNo']}
                                </ReadOnlyField>
                            </Col>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"Email"}>
                                    {acctData['emailaddress']}
                                </ReadOnlyField>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"currency"}>
                                    {acctData['currency']}
                                </ReadOnlyField>
                            </Col>
                            <Col sm={6} md={6} lg={6}>
                                <ReadOnlyField title={"Address"}>
                                    {acctData['address']}
                                </ReadOnlyField>
                            </Col>
                        </Row>
                    </Card>
                </Row>
                <div className="pb-2"></div>
                {/* 				
                <Heading title={"Spending Analysis (Monthly)"} />
                <Row>
                    <MiniCard title={"Total Credits"}> {acctData['totalCredit']}</MiniCard>
                    <MiniCard title={"Total Debits"} >{acctData['totalDebit']}</MiniCard>
                    <MiniCard title={"Average Monthly Spending"}> {acctData['averageMonthlySpending']} </MiniCard>
                    <MiniCard title={"Average Monthly Income"}> {acctData['averageMontlyincome']} </MiniCard>
                    <MiniCard title={"Transaction Count"}>{acctData['txnCount']} </MiniCard>
                    <MiniCard title={"Largest Transactions"}> {acctData['maximumTxnAmout']} </MiniCard>
                    <MiniCard title={"Recurring Transactions"}>0</MiniCard>
                    <MiniCard title={"Involved Channels"}>{acctData['channelCount']} </MiniCard>
                </Row> */}

                <Row>
                    <Col sm={6} md={6} lg={6}>
                        <Card title="Average Channel Statistics (Monthly)">
                            <div className="">

                                <table className="table simple-table">
                                    <tr className="table-row">
                                        <th className="table-cell ps-4">Channel</th>
                                        <th className="table-cell">Count</th>
                                        <th className="table-cell">Pending</th>
                                        <th className="table-cell">In Progress</th>
                                        <th className="table-cell">Closed</th>
                                    </tr>

                                    {channelData.map((item) => {
                                        return (
                                            <tr className="table-row">

                                                <td className="table-cell ps-4">{item["txnType"]}</td>
                                                <td className="table-cell">{item["totalCount"]}</td>
                                                <td className="table-cell">{item["pending"]}</td>
                                                <td className="table-cell">{item["success"]}</td>
                                                <td className="table-cell">{item["failure"]}</td>
                                            </tr>
                                        );
                                    })}




                                </table>
                            </div>
                        </Card>
                    </Col>

                </Row>
            </div>
        </>
    );
};

export default index;
