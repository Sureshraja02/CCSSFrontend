import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import usePageContext from "usePageContext";
import RenderForm from "RenderForm";
import TextBox from "TextBox";
import Card from "Card";
import sendData from "sendData";
import message from "message";

const index = () => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [formData, setformData] = useState([]);
    const [radioBtndata, setradioBtndata] = useState([]);



    const toggleModal = () => {
        setmodalisOpen(!modalisOpen);
    }

    const onOptionChange = e => {

        setradioBtndata(e.target.value);
    }
    const isEmptyObject = (obj) => Object.keys(obj).length === 0;
    const callback = (values, actions) => {

        console.debug('------>' + values);

        values[radioBtndata] = values['defaultValue'];

        const isEmptyObject = (obj) => Object.keys(obj).length === 0;

        sendData.post("/app/rest/v1.0/service/nccrpDemographicView", values).then((d) => {
            console.log('---------------' + d['accountList']);
            console.log(isEmptyObject(d['accountList'])); // true
         
            if (isEmptyObject(d['accountList'])) {
                message.info('No record Found for the Search');
                values['mobileNo'] = '';
                values['acctNo'] = '';
                values['transactionId'] = '';
                values['acknowledgementNo'] = '';
                values['pan'] = '';
              
            }
            else {

                setPageData({
                    values
                });


                setCurrentPage("v1-cybercrime-accountview");
            }

            // setdata(d['accountList']);
        });




    };




    return (
        <>
            <div className="p-4">

                <Row>
                    <Col>
                        <Heading
                            title="Search Customer Details"
                            subTitle="Search the account based on the below filters"
                        />
                    </Col>
                </Row>
                <Row>
                    <Col>

                        <RenderForm formFormat={[]} formData callback={callback} cancel={false}>

                            {(props) => {


                                return (

                                    <>
                                        <Row>
                                            <Col sm={6} md={6} lg={6}>

                                                <div className="form-group">

                                                    <label> Search by </label>

                                                    <div className="form-check">
                                                        <input type="radio" className="form-check-input checked" onChange={onOptionChange} name="rad" value="mobileNo" />
                                                        <label>  Mobile Number </label>
                                                    </div>

                                                    <div className="form-check">

                                                        <input type="radio" name="rad" className="form-check-input" onChange={onOptionChange} value="acctNo" />
                                                        <label> Account Number </label>
                                                    </div>
                                                    <div className="form-check">
                                                        <input type="radio" name="rad" className="form-check-input" onChange={onOptionChange} value="transactionId" />
                                                        <label>Transaction Id </label>
                                                    </div>

                                                    <div className="form-check">
                                                        <input type="radio" name="rad" className="form-check-input" onChange={onOptionChange} value="acknowledgementNo" />
                                                        <label>Acknowledgement No </label>
                                                    </div>


                                                    <div className="form-check">
                                                        <input type="radio" name="rad" className="form-check-input" onChange={onOptionChange} value="pan" />
                                                        <label>        PAN </label>
                                                    </div>
                                                </div>






                                                <TextBox
                                                    key={"mNumber"}
                                                    label={""}
                                                    name={"defaultValue"}
                                                    placeholder={"Enter the details"}
                                                    value={props.values["defaultValue"]}
                                                    onChange={props.handleChange}
                                                    error={
                                                        props.errors.hasOwnProperty("defaultValue") &&
                                                        props.errors["defaultValue"]
                                                    }
                                                    id={"mNumber"}
                                                    tooltip={"Enter a mobile number"}
                                                    type={"text"}
                                                />
                                            </Col>
                                        </Row>
                                    </>

                                )
                            }}

                        </RenderForm>
                    </Col>
                </Row>
            </div>
        </>
    );
};

export default index;
