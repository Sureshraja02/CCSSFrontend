import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Table from "Table";
import loadData from "loadData";
import usePageContext from "usePageContext";
import ListLayout from "ListLayout";
import useGlobalContext from "useGlobalContext";
import newapi from 'newapi';

const InstitionManagement = () => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState({});

    const [pageSize, setpageSize] = useState(10);

    const [pageNo, setpageNo] = useState(1);
    const { globalState, updateGlobalState } = useGlobalContext();
    const [message, setMessage] = useState('');


    const headers = [

        {
            id: "0",
            label: "dummy",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "1",
            label: "Complaint Date",
            //    width: "200",
            type: "date",
            hidden: false,
        },
		{
            id: "2",
            label: "Acknowledgement Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "3",
            label: "Account Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "4",
            label: "RRN",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "5",
            label: "Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "6",
            label: "Disputed Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "7",
            label: "Transaction Date",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        
        {
            id: "9",
            label: "Status",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "10",
            label: "Reason",
            //    width: "200",
            type: "text",
            hidden: false,
        },

        
    ]





    const storeSelectedRows = (e) => {
        console.warn(e);
        setSelectedRows(e);
    };


    const loadDataFromAPI = (id, filter = {
        timeline: globalState.timeline
    }) => {
        loadData.get(`/app/rest/v1.0/service/getFullyFailedRecord/${pageSize}/${pageNo - 1}`, filter).then((res) => {
            setTableData(res);
        });
    }



    const downloadPartialSuccessFromAPI = (id, filter = {
        timeline: globalState.timeline
    }) => {
        loadData.get(`/app/rest/v1.0/service/downloadFullyFailedRecord/${pageSize}/${pageNo - 1}`, filter).then((res) => {
            if (res['status'] === '00') {
                   
                // const API_BASE_URL = "http://10.100.26.43:9998/app/rest/v1.0";
                // const API_BASE_URL = "http://localhost:9998/app/rest/v1.0";

                try {
                    newapi.get(`/app/rest/v1.0/download/${res['fileName']}`, {
                        responseType: 'blob',
                    }).then((ress) => {

                        
                        const url = window.URL.createObjectURL(new Blob([ress.data]));
                        const link = document.createElement('a');
                        link.href = url;
                        link.setAttribute('download', res['fileName']);
                        document.body.appendChild(link);
                        link.click();
                        setMessage('File downloaded successfully!');
                    });
                } catch (error) {
                    setMessage('File download failed!');
                }

            }
            else {
                setMessage(res['statusDesc']);
            }
            
            //setTableData(res);
        });
    }




    useEffect(() => {
        loadDataFromAPI();
       
    }, []);


    useEffect(() => {
        loadDataFromAPI();
    }, [pageNo]);


    const triggerfilterCallback = (ackNo) => {
        loadDataFromAPI(null, {
            acknowledgementNo: ackNo
        })
    }





    return (
        <>
            <ListLayout
                title={"Fully Failed List"} 
                //subTitle={"List of reported cases and its necessary status are recorded here"}
            >
                  {message && <div className="alert alert-info">{message}</div>}                
                 <button type="button" style={{ display: 'flex', justifyContent: 'flex-end' }} className='btn btn-primary btn-sm' onClick={() => downloadPartialSuccessFromAPI()}>
                                   Download
                                </button>                               
                                <br></br>
                <Row>
                    <Col>
                   
                        <Table
                            title={globalState.timelineLable+ " Records"}
                           
                            tableData={tableData}
                            headers={headers}
                            suffix={"Report"}
                            pageNoCallback={(a) => setpageNo(a)}
                            // selectType={"radio"}
                            // selectKey={"id"}
                            //      name={"hello"}
                            selectedRowCallback={(e) => storeSelectedRows(e)}
                           // filterCallback={(e) => triggerfilterCallback(e.target.value)}
                           // filterLabel={"acknowledgement no"}
                            // refreshCallback={() => ld()}
                            //createlabel={"Register a Case"}
                            //newEntryCallback={() => triggernewRegistration()}
                            //             deleteCallback={(e) => console.log(e)}
                            //           editCallback={(e) => triggerEditIns(e)}
                            customHeaderComponents={
                                <>


                                </>
                            }
                        ></Table>
                        
                    </Col>
                </Row>
            </ListLayout>
        </>
    );
};
export default InstitionManagement;
