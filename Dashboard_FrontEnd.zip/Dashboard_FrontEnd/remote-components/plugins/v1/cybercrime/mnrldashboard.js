import React, { useEffect, useState } from "react";
import Heading from "Heading";
import Row from "Row";
import Col from "Col";
import Card from "Card";
import Chart from 'Chart';
import CategoryScale from 'CategoryScale';
import BarChart from "BarChart";
import LineChart from "LineChart";
import PieChart from "PieChart";
import DonutChart from "DonutChart";
import loadData from "loadData";
import useGlobalContext from "useGlobalContext";
import mixColors from "mixColors";
import LoadingComponent from "Loading";
import Moment from "Moment";
import PolarAreaChart from "PolarAreaChart";
import { ArrowClockwise } from "react-bootstrap-icons";
import Modal from "Modal";
import Table from "Table";




Chart.register(CategoryScale);
function Flow() {

    const [timeline, settimeline] = useState("TODAY");
    const [loading, setloading] = useState(false);

    const [inlineLoading, setinlineLoading] = useState(false);

    const [LayersChart, setLayersChart] = useState({});

    const [ChannelChart, setChannelChart] = useState({});
    const [modalisOpen, setmodalisOpen] = useState(false);

    const [modelName, setmodelName] = useState(null);

    const [modalData, setmodalData] = useState({});

    const [modelUrl, setmodelUrl] = useState(null);

    const [pageSize, setpageSize] = useState(10);

    const [pageNo, setpageNo] = useState(1);

   


    const { globalState, updateGlobalState } = useGlobalContext();

    

  



    const options = {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };


    // const dashData = {
    //     "CompliantsReceived": 10,
    //     "FreezedAccounts": 5,
    //     "TotalTxns": 2000000,
    //     "TotalSuspeciousTxns": 20000,
    // }

    const defaultData =
    {
       "readMnrlCount": 0,
  "readMobileMatchedWithBankCount": 0,
  "readDebitFreezeCount": 0,
  "readcifBlockCount": 0,
  "readAtrCount": 0,
  "readFriCount": 0,
  "readFriMobileMatchedWithBankCount": 0,
  "readFriMobileremovalCount": 0,
  "readFriCifBlock": 0,
  "readFriAtr": 0,
      
       
    }



    const [dashData, setdashData] = useState(defaultData);

    const [pieData, setpieData] = useState({});

    const [barData, setbarData] = useState({});


    const headers = [

        {
            id: "0",
            label: "dummy",
            //    width: "200",
            type: "text",
            hidden: false,
        },
		{
            id: "1",
            label: "Acknowledgement Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "2",
            label: "Account Number",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "3",
            label: "RRN",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "4",
            label: "Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "5",
            label: "Disputed Amount",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "6",
            label: "Transaction Date",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        
        {
            id: "8",
            label: "Status",
            //    width: "200",
            type: "text",
            hidden: false,
        },
        {
            id: "9",
            label: "Reason",
            //    width: "200",
            type: "text",
            hidden: false,
        },

        
    ]



    const loadAPI = (timeline) => {

        setloading(true);
        //alert('----');
        
        loadData.getmnrl("/app/rest/v1.0/service/mnrlpdashboard", { timeline }).then((res) => {


            setdashData(res);
            //const dt = res;

            setloading(false);

        });
        
    }


    useEffect(() => {

        loadAPI(timeline);

    }, [timeline]);




    const renderSumAmount = (num) => {
        if (num != null && num > 0) {
            if (num >= 100000) {
                return (num / 100000).toFixed(1) + "L";
            } else if (num >= 1000) {
                return (num / 1000).toFixed(1) + "K";
            } else {
                return num;
            }
        }
        return num;
    }



    const loadDataFromAPI = (id, filter = {
        timeline: timeline
    }) => {
       
        console.log(modelUrl);
       
        if (modelUrl) {
            setmodalisOpen(true)
            setinlineLoading(true);
           /* loadData.get(`${modelUrl}${pageSize}/${pageNo - 1}`, filter).then((res) => {
                setmodalData(res);
                setinlineLoading(false);
               
            });
            */
        }

    }




    useEffect(() => {
        loadDataFromAPI();
        updateTimelineInfo(timeline);
     
        updateGlobalState({
            timeline: timeline,
         
          });
    }, [pageNo]);


    const triggerfilterCallback = (ackNo) => {
        loadDataFromAPI(null, {
            acknowledgementNo: ackNo,
            timeline: timeline
        })
    }

    const updateTimelineInfo = (timelineValue) => {
        

        var timeLineLabel='Today';
      
        if(timelineValue=='TODAY')
        {
            timeLineLabel='Today';
        }
        if(timelineValue=='YESTERDAY')
        {
            timeLineLabel='Yesterday----';
        }
        if(timelineValue=='DAYBYESTER')
            {
                timeLineLabel='Day before Yesterday'; 
            }
            if(timelineValue=='7DAY')
                {
                    timeLineLabel='Last 7 Days'; 
                }
                if(timelineValue=='MONTH')
                    {
                        timeLineLabel='This Month';  
                    }
                    if(timelineValue=='YTD')
                        {
                            timeLineLabel='This Year';   
                        }
        updateGlobalState({
            timeline: timelineValue,
            timelineLable:timeLineLabel,
         
          });
    }



    return (
        <>
            <div className="p-4">
                <Heading title="Overview" subTitle={`MNRL Records`} />
                <Row>
 <Col sm={9} md={9} lg={9}>
                                {dashData !== undefined && dashData['mnrlDate'] && (
                                    <div className="fis-primary">
                                        Last downloaded Date and Time : {dashData['mnrlDate']}
                                    </div>
                                )}
                            </Col>
                    <Col sm={12} md={12} lg={12}>
                        <Col>
                                                               <select className="btn btn-fis-outline bg-fis-secondary fis-primary ml-10 mr-10" name="reportSelect"
                                                                   style={{
                                                                       float: "right",
                                                                   }}
                       
                                                                   onClick={(e) => {settimeline(e.target.value), updateTimelineInfo(e.target.value);}}
                                                               >
                                                                   <option value="TODAY" >Today</option>
                                                                   <option value="YESTERDAY" >Yesterday</option>
                                                                   <option value="DAYBYESTER" >Day before Yesterday</option>
                                                                   <option value="7DAY" >Last 7 Days</option>
                                                                   <option value="MONTH" >This Month</option>
                                                                   <option value="YTD">YTD</option>
                                                               </select>
                                                           </Col>
                    </Col>
                </Row>


                {(!loading) ? (<>
                    <Row>

 <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>


                                    <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">MNRL COUNT</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder fis-danger cursor-pointer"
                                                onClick={() => {
                                             
                                                }}
                                               

                                                > {dashData['readMnrlCount']}
                                                   
                                                </div>
                                            </Col>
                                          
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-primary-2">
                                        <p className="mini-card-heading uppercase">Mobile Number Matched with bank account </p>
                                        <div className="h1 font-bolder fis-primary">
                                           {dashData['readMobileMatchedWithBankCount']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>







                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                      <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Debit Freezed </p>
                                        <div className="h1 font-bolder fis-info">
                                         {dashData['readDebitFreezeCount']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>

                                    <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">CIF Block</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder fis-success"    onClick={() => {
                                                 
                                                   //setmodelUrl(`/app/rest/v1.0/service/getFullySuccessRecord/`)
                                                    // loadDataFromAPI()
                                                    
                                                }}>
                                                    
                                              {dashData['readcifBlockCount']}

                                                  
                                                </div>
                                            </Col>
                                           
                                        </Row>
                                    </div>

                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                     <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">MNRL ATR</p>
                                        <div className="h1 font-bolder fis-warning">
                                          {dashData['readAtrCount']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                          <Heading title="Overview" subTitle={`FRI Records`} />
                          <Row>
<Col sm={9} md={9} lg={9}>
                                {dashData !== undefined && dashData['fridate'] && (
                                    <div className="fis-primary">
                                        Last downloaded Date and Time : {dashData['fridate']}
                                    </div>
                                )}
                            </Col>
                            </Row>
  <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">FRI COUNT</p>
                                        <div className="h1 font-bolder fis-info">
                                           {dashData['readFriCount']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Mobile Number Matched with bank account </p>
                                        <div className="h1 font-bolder fis-info">
                                           {dashData['readFriMobileMatchedWithBankCount']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                  

                       



                      



                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">FRI CIF BLOCK</p>
                                        <div className="h1 font-bolder fis-warning">
                                          {dashData['readFriCifBlock']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>



                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-4 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">FRI ATR</p>
                                        <div className="h1 font-bolder fis-warning">
                                          {dashData['readFriAtr']}
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                     
                    </Row>




                   
                    {/* 
                    <Row>

                        <Col>
                            <Heading title="Channel-wise Compliants statistics" />
                        </Col>

                    </Row>

                    <Row>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-primary-2">
                                        <p className="mini-card-heading uppercase">E-Wallet </p>

                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['wallet']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>

                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Debit/Credit Card</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['debitCreditCard']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Demat /Depository Fraud</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['dematFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Credit Card Fraud</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['creditCardFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-info-2">
                                        <p className="mini-card-heading uppercase">Business Email Compromise</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['businessFraud']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-success-2">
                                        <p className="mini-card-heading uppercase">Internet Banking</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['ibank']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>


                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">Fraud Call</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['phonecalls']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                        <Col sm={3} md={3} lg={3}>
                            <div className="p-1">
                                <Card>
                                    <div className="p-2 border-bottom-fis-warning-2">
                                        <p className="mini-card-heading uppercase">UPI</p>
                                        <Row>
                                            <Col sm={10} md={10} lg={10}>
                                                <div className="h1 font-bolder">
                                                    {dashData['phonecalls']}
                                                </div>
                                            </Col>
                                            <Col sm={2} md={2} lg={2} className="flex-bottom">
                                                <div className="h4 fis-primary">
                                                    <div className="max-height-50">

                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                    </Row> */}
                </>
                ) : (
                    <LoadingComponent show={loading}>

                    </LoadingComponent>
                )}



                <Modal isOpen={modalisOpen} title={modelName} handleClose={() => setmodalisOpen(!modalisOpen)} close={true}>
                    <>
                        <Table
                            tableData={modalData}
                            headers={headers}
                            pageNoCallback={(a) => setpageNo(a)}
                            isLoading={inlineLoading}
                            filterCallback={(e) => triggerfilterCallback(e.target.value)}
                            filterLabel={"acknowledgement no"}
                            
                        ></Table>
                    </>
                </Modal>


            </div>
        </>
    );
}

export default Flow;
