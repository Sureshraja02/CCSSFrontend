import React, { useEffect, useState } from "react";
import Row from "Row";
import Col from "Col";
import Heading from "Heading";
import usePageContext from "usePageContext";
import RenderForm from "RenderForm";
import TextBox from "TextBox";
import Card from "Card";
import sendData from "sendData";
import ReadOnlyField from "../../../components/ReadOnlyField";
import loadData from "loadData";
const index = ({
    values
}) => {
    const { setCurrentPage, setPageData } = usePageContext();
    const [selectedRows, setSelectedRows] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [modalisOpen, setmodalisOpen] = useState(false);
    const [formData, setformData] = useState([]);

    const [data, setdata] = useState([]);

    const toggleModal = () => {
        setmodalisOpen(!modalisOpen);
    }

    useEffect(() => {

        //  loadData.get("/app/rest/v1.0/service/account/" + values['mobileNo'], {}).then((res) => {
        //  setdata(res['accountList']);
        // });





        console.log(values);



        sendData.post("/app/rest/v1.0/service/nccrpDemographicView", values).then((d) => {
            setdata(d['accountList']);

            values['acctNo'] = d['accountList'][0]['acctNo'];
            values['transactionId'] ='';
            values['pan'] = '';
            values['acknowledgementNo'] = '';
            values['mobileNo'] = '';
        });


    }, [values]);



    const showDemoView = () => {
        setPageData({
            values
        });
        setCurrentPage("v1-cybercrime-demographicview");
    }

    // const data = [{
    //     "accoutType": "SAVINGS",
    //     "accountNo": "123456789",
    //     "currentAmount": "2000000",
    //     "status": "KYC PENDING",
    //     "click": "true"
    // }, {
    //     "accoutType": "CURRENT",
    //     "accountNo": "123456789",
    //     "currentAmount": "200000",
    //     "status": "Kyc Completed",
    //     "click": "true"
    // }, {
    //     "accoutType": "CREDITCARD",
    //     "accountNo": "123456789",
    //     "currentAmount": "2000000",
    //     "status": "active",
    //     "click": "true"
    // }, {
    //     "accoutType": "HOUSINGLOAN",
    //     "accountNo": "123456789",
    //     "currentAmount": "2000000",
    //     "status": "Partially / Fully Dispursed",
    //     "click": "true"
    // }];




    return (
        <>
            <div className="p-4">

                <Row>
                    <Col>
                        <Heading
                            title="Accounts List"
                            subTitle="click on the each individual account for demographic view"
                        />
                    </Col>
                </Row>
                <Row>
                    <Col>

                        {data.map((d, i) => {
                            return (
                                <>
                                    <Card>
                                        <div className="p-4">

                                            <Row>
                                                <Col sm={6} md={6} lg={6} className="flex-start">
                                                    <p className="uppercase highlight-primary">
                                                        {d.shortName}
                                                    </p>
                                                </Col>


                                            </Row>

                                            <Row>

                                                <Col sm={3} md={3} lg={3} className="flex-start">
                                                    <ReadOnlyField title={"ACCOUNT NO"} className={"uppercase"}>
                                                        <h4 className="bold">
                                                            {d.acctNo}
                                                        </h4>
                                                    </ReadOnlyField>
                                                </Col>

                                                <Col sm={3} md={3} lg={3} className="flex-center">
                                                    <ReadOnlyField title={"AMOUNT"} className={"uppercase"}>
                                                        <h4 className="bold">

                                                            {d.currentAmount}
                                                        </h4>
                                                    </ReadOnlyField>
                                                </Col>
                                                <Col sm={3} md={3} lg={3} className="flex-center">
                                                    <ReadOnlyField title={"CUSTOMER NO"} className={"uppercase"}>
                                                        <h4 className="bold">

                                                            {d.customerNo}
                                                        </h4>
                                                    </ReadOnlyField>
                                                </Col>
                                                <Col sm={3} md={3} lg={3} className="flex-end flex-center">
                                                    <button
                                                        type="button"
                                                        onClick={() => showDemoView()}
                                                        className="btn btn-outline-primary"
                                                    >
                                                        {"View Details"}
                                                    </button>


                                                </Col>
                                            </Row>
                                        </div>
                                    </Card>
                                    <div className="pb-2"></div>
                                </>
                            )
                        })}

                    </Col>
                </Row>
            </div>
        </>
    );
};

export default index;
