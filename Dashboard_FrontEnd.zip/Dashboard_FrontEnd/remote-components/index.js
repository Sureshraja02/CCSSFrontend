export { default as pom } from "./plugins/createRule";
