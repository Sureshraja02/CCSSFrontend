import {
  BrowserRouter as Router,
  Routes,
  Route,
  BrowserRouter,
  useLocation,
  useNavigate
} from "react-router-dom";
import Home from "../pages/Home";
import Login from "../pages/Login";
import ChangePassword from "../pages/ChangePassword";
import FirstTimeLogin from "../pages/FirstTimeLogin";
import { useEffect } from "react";
import { useGlobalContext } from "../utilites/GlobalContext";

function UamNavigations() {

  const location = useLocation();
  const navigate = useNavigate();
  const { globalState } = useGlobalContext();

  useEffect(() => {
    if (globalState['initApp'] === undefined && location.pathname !== "/login")
      navigate("/");
  }, [globalState['initApp']]);
  return (
    <>
      <Routes>
        <Route exact path="/" Component={Login} />
        <Route exact path="/login" Component={Login} />
        <Route extact path="/change-password" Component={ChangePassword} />
        <Route extact path="/firstTimeLogin" Component={FirstTimeLogin} />
        <Route exact path="/home" Component={Home} />

      </Routes>
    </>
  );
}

export default UamNavigations;
