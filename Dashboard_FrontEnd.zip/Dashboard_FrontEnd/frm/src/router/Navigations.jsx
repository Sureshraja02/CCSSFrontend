import {
    BrowserRouter as Router,
    Routes,
    Route,
    BrowserRouter,
    HashRouter,
} from "react-router-dom";
import UamNavigations from "./SubNavigations";
import { useEffect } from "react";
import { useGlobalContext } from "../utilites/GlobalContext";
import { Button, ConfigProvider, Space } from 'antd';
import { CONTEXT_PATH } from "../config";


function Navigations() {





    return (<>
        <HashRouter>

            <UamNavigations />

        </HashRouter>
    </>);

}

export default Navigations;

