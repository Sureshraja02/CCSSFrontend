import tinycolor from "tinycolor2";

export function arrayToJson(arr) {
  if (!Array.isArray(arr)) return null;

  var newObj = {};

  arr.forEach((key, i) => {
    newObj[key] = key;
  });

  return newObj;
}

export function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function reduceJson(json, key, value) {
  return json.filter((item) => item[key] >= value);
}

export function reduceArray(arr1, arr2) {
  //arr 1 is parent
  //arr 2 is child arr
  return arr1.filter((ele) => !arr2.includes(ele));
}

export function findObject(json, key, value) {
  if (!Array.isArray(json)) return null;

  return (
    json.length > 0 &&
    json.reduce((obj) => {
      if (typeof obj === "object" && obj != null) {
        if (key in obj && obj[key] === value) {
          return obj;
        } else {
          return findObject(obj["children"], key, value);
        }
      }
    })
  );
}

export function mergeJson(prevState, newState) {
  Object.keys(newState).forEach((key, i) => {
    prevState[key] = newState[key];
  });

  return prevState;
}

export function isColorLight(color) {
  return tinycolor(color).isLight();
}

export function isColorDark(color) {
  return tinycolor(color).isDark();
}

export function findTextColor(backgroundColor) {
  var c = tinycolor(backgroundColor);
  return c.isDark() ? c.lighten(50) : c.darken(50);
}

export function mixColors(color1, color2, depth) {
  return tinycolor.mix(color1, color2, depth).toHexString();
}

export function groupJsonByKey(data, key) {
  if (!Array.isArray(data)) {
    console.warn("Data is not an array");
    return null;
  }

  return data.reduce((newObj, currentItem) => {
    const val = currentItem[key];
    if (!newObj[val]) {
      newObj[val] = [currentItem];
    } else {
      newObj[val].push(currentItem);
    }
    return newObj;
  }, {});
}


export function random() {
  const min = 1;
  const max = 100;
  return min + Math.random() * (max - min);
}

export function filterJson(data, key, value) {
  if (!Array.isArray(data)) {
    console.warn("Data is not an array");
    return null;
  }
  if (value == 0) return [];
  return data.filter((item) => item[key] === value);
}

export function sortArray(data, key) {
  if (!Array.isArray(data)) return [];

  if (data.length <= 1) return data;

  return data.sort((a, b) => {
    if (a[key] < b[key]) {
      return -1;
    } else if (a[key] > b[key]) {
      return 1;
    } else {
      return 0;
    }
  });
}

export function storeInSession(key, value) {
  sessionStorage.setItem(key, value);
}

export function getFromSession(key) {
  const data = sessionStorage.getItem(key);
  if (data === null || data === undefined) return null;
}

export function ChangeStyle(key, value) {
  document.documentElement.style.setProperty(key, value);
}

export function generateRandomNumber() {
  //generates 4 digit random number
  let num = Math.floor(Math.random() * 1000);
}

export function isPrime(num) {
  for (let i = 2, s = Math.sqrt(num); i <= s; i++) {
    if (num % i === 0) return false;
  }
  return num > 1;
}

export function FindDayofMonth() {
  const currentDate = new Date();
  return currentDate.getDate();
}

export function FindDayofYear() {
  const currentDate = new Date();
  const startOfYear = new Date(currentDate.getFullYear(), 0, 0);

  const diff = currentDate - startOfYear;
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  return dayOfYear;
}

const getPrimes = (min, max) => {
  const result = Array(max + 1)
    .fill(0)
    .map((_, i) => i);
  for (let i = 2; i <= Math.sqrt(max + 1); i++) {
    for (let j = i ** 2; j < max + 1; j += i) delete result[j];
  }
  return Object.values(result.slice(Math.max(min, 2)));
};

const getRandNum = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1) + min);
};

export const getRandPrime = (min, max) => {
  const primes = getPrimes(min, max);
  return primes[getRandNum(0, primes.length - 1)];
};

export function getStyle(key) {
  document.documentElement.style.getPropertyValue(key);
}

export const toCamelCase = (str) => {
  if (str == null || str == undefined || typeof str != "string") return str;
  return str
    .split(/[^a-zA-Z0-9]/)
    .map((word) => {
      return capitalize(word);
    })
    .join("");
};

export const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

export function convertToMultiLevel(data, uniqueKey, key) {
  //data should be array ,
  //uniquekey should be a value that is unique for whole json
  //key is the groupby key

  var dt = data;

  console.warn(key);
  const fMap = new Map();
  if (!Array.isArray(dt)) return null;
  dt.forEach((item) => {
    item.children = []; // static key for subLevels for easy identifications
    fMap.set(item[uniqueKey], item);
  });
  dt.forEach((item) => {
    const keyData = item[key];
    if (keyData !== null && keyData !== undefined && fMap.has(keyData)) {
      //matches with teh uniqueKey
      fMap.get(keyData).children.push(item);
    }
  });

  const topLevel = dt
    .filter((item) => item[key] === null || item[key] === undefined)
    .map((item) => fMap.get(item[uniqueKey]));
  return topLevel;
}
