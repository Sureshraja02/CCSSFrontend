import React from 'react';
import { getBezierPath, EdgeLabelRenderer, BaseEdge, } from 'reactflow';
// this is a little helper component to render the actual edge label
function StartEdgeLabel({ transform, label }) {
    return (React.createElement("div", {
        style: {
            position: 'absolute',
            background: 'transparent',
            padding: 25,
            color: '#ff5050',
            fontSize: 12,
            fontWeight: 700,
            transform,
        }, className: "nodrag nopan"
    }, label));
}

function EndEdgeLabel({ transform, label }) {
    return (React.createElement("div", {
        style: {
            position: 'absolute',
            background: 'transparent',
            padding: 20,
            color: '#ff5050',
            fontSize: 12,
            fontWeight: 700,
            transform,
        }, className: "nodrag nopan"
    }, label));
}

function EdgeLabel({ transform, label }) {
    return (React.createElement("div", {
        style: {
            position: 'absolute',
            background: 'white',
            padding: 5,
            fontSize: 12,
            fontWeight: 700,
            transform,
        }, className: "nodrag nopan"
    }, label));
}
const CustomEdge = ({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, data, label }) => {
    const [edgePath, labelX, labelY] = getBezierPath({
        sourceX,
        sourceY,
        sourcePosition,
        targetX,
        targetY,
        targetPosition,
    });
    return (React.createElement(React.Fragment, null,
        React.createElement(BaseEdge, { id: id, path: edgePath }),
        React.createElement(EdgeLabelRenderer, null,
            (data.label || label) && (React.createElement(EdgeLabel, { background: "white", color: "black", transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`, label: data.label || label })),
            data.startLabel && (React.createElement(StartEdgeLabel, { transform: `translate(-50%, 0%) translate(${sourceX}px,${sourceY}px)`, label: data.startLabel })),
            data.endLabel && (React.createElement(EndEdgeLabel, { transform: `translate(-50%, -100%) translate(${targetX}px,${targetY}px)`, label: data.endLabel })))));
};
export default CustomEdge;

