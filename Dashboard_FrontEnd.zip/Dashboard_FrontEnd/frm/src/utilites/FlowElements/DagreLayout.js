import Dagre from '@dagrejs/dagre';


const nodeWidth = 172;
const nodeHeight = 36;

export const getLayoutedElements = (nodes, edges, options) => {
    const g = new Dagre.graphlib.Graph().setDefaultEdgeLabel(() => ({}));
    g.setGraph({ ...options });

    edges.forEach((edge) => g.setEdge(edge.source, edge.target));
    nodes.forEach((node) =>
        g.setNode(node.id, {
            ...node,
            width: nodeWidth, height: nodeHeight
        }),
    );

    Dagre.layout(g);

    return {
        nodes: nodes.map((node) => {
            const position = g.node(node.id);
            // We are shifting the dagre node position (anchor=center center) to the top left
            // so it matches the React Flow node anchor point (top left).
            const x = position.x - nodeWidth / 2;
            const y = position.y - nodeHeight / 2;

            return { ...node, position: { x, y } };
        }),
        edges,
    };
};
