import React, {
  Children,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import ReactFlow, {
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  ReactFlowProvider,
  addEdge,
  Panel
} from "reactflow";
import CustomEdge from "./CustomEdge";

let id = 0;
const getId = () => `routing_id_${id++}`;

function Flow({ initialNodes, intialEdges, children, controls = true, onNodeClickCallback, panelChildren }) {
  const reactFlowWrapper = useRef(null);
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);

  const [graphHeight, setgraphHeight] = useState(500);
  const [graphWidth, setgraphWidth] = useState(100);

  const onConnect = useCallback((params) => {
    const { source, target } = params;

    console.warn("source data : " + source);

    setEdges((eds) => addEdge(params, eds));
  }, []);


  const onNodeClick = (event, node) => {
    if (onNodeClickCallback) {
      onNodeClickCallback(event, node);
    }
    console.log("Node clicked  : " + node);
  }

  useEffect(() => {
    console.warn(JSON.stringify(edges));
  }, [edges]);

  useEffect(() => {
    setNodes(initialNodes);

    setgraphHeight(Math.max(...initialNodes.map((n) => n.position.x)) + 300);
    setgraphWidth(Math.max(...initialNodes.map((n) => n.position.y)) + 300);


  }, [initialNodes]);

  useEffect(() => {
    setEdges(intialEdges);
  }, [intialEdges]);

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const edgeTypes = {
    custom: CustomEdge,
    'start-end': CustomEdge,
  };

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData("application/reactflow");

      // check if the dropped element is valid
      if (typeof type === "undefined" || !type) {
        return;
      }

      // reactFlowInstance.project was renamed to reactFlowInstance.screenToFlowPosition
      // and you don't need to subtract the reactFlowBounds.left/top anymore
      // details: https://reactflow.dev/whats-new/2023-11-10
      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      const newNode = {
        id: getId(),
        type: "default",
        position,
        data: { label: `${type} node`, db: "1235" },
        sourcePosition: "right",
        targetPosition: "left",
        animated: true,
        custom: "true",
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [reactFlowInstance]
  );

  return (
    <div className="dndflow">
      <ReactFlowProvider>
        <div
          className="reactflow-wrapper"
          style={{
            height: `${graphHeight}px`,
            width: "100%",
            overflow: "auto"
          }}
          ref={reactFlowWrapper}
        >
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            onConnect={onConnect}
            edgeTypes={edgeTypes}
            onInit={setReactFlowInstance}
            onDrop={onDrop}
            onDragOver={onDragOver}
            fitView
            panOnScroll
            zoomOnScroll
            panOnDrag
          >
            <Background />
            {controls && (<Controls />)}

            <Panel>
              {panelChildren}
            </Panel>
          </ReactFlow>
        </div>
        {children}
      </ReactFlowProvider>
    </div>
  );
}

export default Flow;
