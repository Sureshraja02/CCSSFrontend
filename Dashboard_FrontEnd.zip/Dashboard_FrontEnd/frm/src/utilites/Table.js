import React, { useEffect, useRef } from "react";
import Card from "../components/Card";
import { useState } from "react";
import Divider from "../components/Divider";
import { CaretDown, CaretUpFill } from "react-bootstrap-icons";
import { filterJson } from "./utils";
import moment from 'moment';
import { Spinner } from "react-bootstrap";

const Table = (props) => {
  const {
    title,
    subTitle,
    datas,
    headers,
    setSortData,
    tableData,
    selectKey,
    selectType,
    selectedRowCallback,
    customHeaderComponents,
    filterCallback,
    filterLabel,
    refreshCallback,
    deleteCallback,
    editCallback,
    newEntryCallback,
    suffix,
    createlabel,
    pageNoCallback,
    componentMap,
    isLoading = false
  } = props;
  const [tabledata, setTableData] = useState([]);
  const [headerData, setHeaderData] = useState({});
  const [sortkey, setSortKey] = useState(null);
  const [datalength, setDataLength] = useState(0);
  const [isfirst, SetIsFirst] = useState(true);
  const [islast, SetIsLast] = useState(false);
  const [sortData, storeSortData] = useState({});
  const [pageData, setPageData] = useState({});
  const [totalPages, setTotalPages] = useState(0);
  const [totaldatacount, setTotalDataCount] = useState(0);
  const [selectedKey, setSelectedKey] = useState([]);

  const [totalElements, settotalElements] = useState(0);

  const [pageSize, setpageSize] = useState(10);

  const [pageNo, setpageNo] = useState(1);




  const extractHeader = (content) => {
    //form header
    const whitelistedHeader = headers || [];
    const firstObj = content.length > 0 && content[0];

    //header format
    // {
    //   id: "userID",
    //   label: "userID",
    //   width: "200",
    //   type: "text",
    //   hidden: true,
    //   mandatory: true,
    // },

    var headerData = [];

    if (firstObj != undefined) {
      Object.keys(firstObj).map((key, index) => {
        //check header is customized

        var filteredarray = filterJson(whitelistedHeader, "id", key);
        console.log(filteredarray, whitelistedHeader);
        if (whitelistedHeader.length > 0) {
          if (filteredarray.length > 0) {
            filteredarray = filteredarray[0];
            headerData.push(filteredarray);
          }
        } else {
          headerData.push({
            id: key,
            label: key,
          });
        }
      });

      //map it to the headerstate
      setHeaderData(headerData);

      console.log(headerData);
    }
  };

  useEffect(() => {
    if (tableData != undefined && "content" in tableData) {
      const content = tableData["content"];
      const totalPages = tableData["totalPages"];
      const totalElements = tableData["totalElements"];
      const numberOfElements = tableData["numberOfElements"];
      const isLast = tableData["last"];
      const isempty = tableData["empty"];
      const isfirst = tableData["first"];
      const sortJson = tableData["sort"];
      const pageJson = tableData["pageable"];
      console.warn(tableData);
      setDataLength(content.length);
      setTableData(content);
      setPageData(pageJson);
      storeSortData(sortJson);
      SetIsFirst(isfirst);
      SetIsLast(isLast);
      setPageData(totalPages);
      setTotalDataCount(numberOfElements);
      extractHeader(content);
      settotalElements(totalElements);

    }
  }, [tableData]);

  const sortDataByKey = (id) => {
    setSortKey(id);
    if (setSortData) setSortData(id);
  };

  const selectAllRow = (e) => {
    let arr = [];
    if (e.target.checked) {
      tabledata.forEach((data) => {
        arr.push(data[selectKey]);
      });
    }

    setSelectedKey(arr);
  };

  const triggerSelectRow = (id) => {

    const index = selectedKey.indexOf(id);
    if (index > -1) {
      // only splice array when item is found
      const key = selectedKey.filter(function (item) {
        return item !== id;
      });
      setSelectedKey(key);
    } else {
      if (selectType === "checkbox") {
        setSelectedKey([...selectedKey, id]);
      } else {
        setSelectedKey([id]);
      }
    }
  };

  useEffect(() => {
    if (selectedRowCallback) selectedRowCallback(selectedKey);
  }, [selectedKey]);

  useEffect(() => { }, []);

  const HeaderButtons = (
    <>
      {deleteCallback && (
        <button
          type="button"
          className="btn btn-fis-danger ml-10 mr-10"
          onClick={() => deleteCallback(selectedKey)}
          disabled={selectedKey.length > 0 ? false : true}
        >
          Delete {suffix}
        </button>
      )}

      {editCallback && (
        <button
          type="button"
          className="btn btn-fis-secondary ml-10 mr-10"
          onClick={() => editCallback(selectedKey)}
          disabled={selectedKey.length === 1 ? false : true}
        >
          Edit {suffix}
        </button>
      )}

      {newEntryCallback && (
        <>
          <button
            type="button"
            className="btn btn-fis-primary ml-10 mr-10"
            onClick={() => newEntryCallback()}
          >

            {createlabel || 'Create ' + suffix}

          </button>
        </>
      )}
    </>
  );

  const mergedHeaders = (
    <>
      {HeaderButtons}
      {customHeaderComponents}
    </>
  );


  const pagingCallback = (page) => {
    setpageNo(page);
    if (pageNoCallback) {
      pageNoCallback(page);
    }
  };


  const renderComponent = (val, tdata, header) => {

    switch (header.type) {
      case "text":
        return <span>
          {val}
        </span>;
      case "date":
        return <span>{moment(val).format('DD/MM/YYYY hh:mm A')}</span>;
      case "link":
        return <span onClick={() => {
          if (header.callback) header.callback(val, tdata);
        }} className={`link fis-secondary cursor-pointer`}>{val}</span>;
      case 'custom':
        if (typeof header.component === "function") {
          return header.component({ id: val, key: val, values: tdata });
        } else if (header.component && componentMap[header.component]) {
          return React.createElement(componentMap[header.component], { id: val, values: tdata });
        }
        else return <></>;
      default:
        return <>
          {val}
        </>
    }


  }

  return (
    <>
      <div className="custom-datatable table-responsive table-card">
        <Card
          title={title}
          count={` ${selectedKey.length > 0
            ? selectedKey.length + " / " + totalElements
            : totalElements
            } `}
          className={``}
          subTitle={subTitle}
          customHeaderComponents={mergedHeaders}
          table={true}
          filterLabel={filterLabel}
          filterCallback={filterCallback}
          totalElements={pageData * pageSize}
          refreshCallback={refreshCallback}
          showPaging={totalElements > pageSize}
          pageSize={pageSize}
          currentElement={pageNo}
          pagingCallback={pagingCallback}
        >
          <div className="custom-card-datatable">
            <table
              className={`table text-nowrap mb-0 table-centered table-hover`}
            >
              <thead className={`table-light`}>
                <tr className="table-row header bs-border-bottom">
                  {selectKey && (
                    <th className="table-cell width-50 first-column  bs-border-right">
                      {selectKey && selectType === "checkbox" && (
                        <input
                          type="checkbox"
                          className="form-check-input"
                          onClick={(e) => selectAllRow(e)}
                        />
                      )}
                    </th>
                  )}
                  {headerData.length > 0 &&
                    headerData.map((header, index) => {
                      if ("hidden" in header && header.hidden) {
                        return <></>;
                      } else {
                        return (
                          <>
                            <th
                              key={index}
                              className="table-cell position-relative draggable"
                              style={{
                                width: `${header["width"]
                                  ? header["width"] + "px"
                                  : "100%"
                                  }`,
                              }}
                            >
                              <div className="flex justify-content-between">
                                <div className="content flex-start">
                                  {header["label"]}
                                </div>
                                {sortkey == header["id"] ? (
                                  <CaretUpFill
                                    size={15}
                                    onClick={() => sortDataByKey(header["id"])}
                                    className="flex-end sort-key align-center cursor-pointer"
                                  />
                                ) : (
                                  <CaretDown
                                    size={15}
                                    onClick={() => sortDataByKey(header["id"])}
                                    className="flex-end sort-key align-center cursor-pointer"
                                  ></CaretDown>
                                )}
                                {headerData.length - 1 != index && (
                                  <div className="draggable-border-right position-absolute r-10"></div>
                                )}
                              </div>
                            </th>
                          </>
                        );
                      }
                    })}
                </tr>
              </thead>


              {isLoading ? (<tbody>
                <tr>
                  <td className={`text-align-center`} colSpan={`${headerData.length}`}>
                    <Spinner className={`m-2`} animation="border" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </Spinner>
                  </td>

                </tr>
              </tbody>) : (


                <tbody>


                  {[...Array(totaldatacount)].map((row, index) => {
                    const tdata = tabledata[index];
                    return (
                      <>
                        <tr
                          key={index}
                          onClick={() => triggerSelectRow(tdata[selectKey])}
                          className={`table-row bs-border-bottom custom-table-${index} ${selectedKey.includes(tdata[selectKey]) ? "active" : ""
                            }`}
                        >

                          {selectKey && (

                            <td className="table-cell width-50 first-column">
                              <input
                                type={selectType}
                                key={totaldatacount + index}
                                className="form-check-input"
                                value={tdata[selectKey]}
                                readOnly={true}
                                checked={
                                  selectedKey.includes(tdata[selectKey])
                                    ? true
                                    : false
                                }
                              />
                            </td>
                          )}

                          {headerData.map((header, i) => {
                            const key = header["id"];
                            const width = header["width"];
                            const val = tdata[key];
                            if ("hidden" in header && header.hidden) {
                              return <></>;
                            } else {
                              return (
                                <td
                                  key={i}
                                  className="table-cell"
                                  style={{
                                    maxWidth: `${header["width"]
                                      ? header["width"] + "px"
                                      : "100%"
                                      }`,
                                  }}
                                >
                                  {renderComponent(
                                    props[key] ? props[key] : val, tdata,
                                    header,
                                  )}
                                </td>
                              );
                            }
                          })}
                        </tr>
                      </>
                    );
                  })}
                </tbody>
              )}
            </table>
          </div>
        </Card>
      </div>
    </>
  );
};

export default Table;
