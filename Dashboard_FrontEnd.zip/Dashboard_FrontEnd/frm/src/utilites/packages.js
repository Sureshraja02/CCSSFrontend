import * as React from "react";
import { useGlobalContext } from "./GlobalContext";
import { usePage } from "./PageContext";
import RenderForm from "./FormElements/RenderForm";
import BackButton from "./FormElements/BackButton";
import utils, {
  mergeJson,
  groupJsonByKey,
  filterJson,
  getRandomInt,
  reduceArray,
  mixColors,
} from "./utils";
import LoadingComponent from "../components/LoadingComponent";
import Model from "../components/Modal";
import DynamicComponent from "../components/DynamicComponent";
import { useNavigate } from "react-router";
import { TextInput } from "./FormElements/TextInput";
import { LabelComponent } from "./FormElements/LabelComponent";

import { Row, Col } from "react-bootstrap";
import Card from "../components/Card";
import Heading from "../components/Heading";
import { Steps } from "antd";
import CustomForm from "./FormElements/CustomForm";
import * as yup from "yup";
import { CheckBoxInput } from "./FormElements/CheckBoxInput";

import { SelectInput } from "./FormElements/SelectInput";
import * as reactIcons from "react-bootstrap-icons";
import Divider from "../components/Divider";

import TableOld from "./Table";
import RenderFlow from "./FlowElements/RenderFlow";
import CollapsibleText from "../components/CollapseableText";
import api from "../api/BackendAPI";
import axiosApi from "../api/baseAPI";
import newapi from "../api/BackendAPI";
import ListLayout from "../pages/layout/ListLayout";
import CurdLayout from "../pages/layout/CurdLayout";
import Tree from 'react-d3-tree';
import { Pie, Bar, Doughnut, Line, PolarArea } from 'react-chartjs-2';
import Chart from "chart.js/auto";
import { CategoryScale } from "chart.js";
import { Timeline } from "antd";
import { Table } from "antd";
import { message } from "antd";
import { hash } from "./crypto";
import { addNotification } from "../redux/notifySlice";
import { getLayoutedElements } from "./FlowElements/DagreLayout";
import Drawer from 'react-modern-drawer'

import * as Config from "../config";
import moment from "moment";


const Packages = {
  hash: () => hash,
  react: () => React,
  "react-bootstrap-icons": () => reactIcons,
  Row: () => Row,
  Col: () => Col,
  Steps: () => Steps,
  Divider: () => Divider,
  useGlobalContext: () => useGlobalContext,
  RenderForm: () => RenderForm,
  TextBox: () => TextInput,
  LabelBox: () => LabelComponent,
  CheckBox: () => CheckBoxInput,
  SelectBox: () => SelectInput,
  BackButton: () => BackButton,
  mergeJson: () => mergeJson,
  filterJson: () => filterJson,
  reduceArray: () => reduceArray,
  groupJsonByKey: () => groupJsonByKey,
  getRandomInt: () => getRandomInt,
  Loading: () => LoadingComponent,
  Modal: () => Model,
  DynamicComponent: () => DynamicComponent,
  useNavigate: () => useNavigate,
  usePageContext: () => usePage,
  loadComponent: () => axiosApi,
  loadData: () => api,
  sendData: () => api,
  newapi: () => newapi,
  Card: () => Card,
  CollapsibleText: () => CollapsibleText,
  Heading: () => Heading,
  CustomForm: () => CustomForm,
  yup: () => yup,
  Table: () => TableOld,
  NewTable: () => Table,
  message: () => message,
  RenderFlow: () => RenderFlow,
  ListLayout: () => ListLayout,
  CurdLayout: () => CurdLayout,
  Tree: () => Tree,
  PieChart: () => Pie,
  BarChart: () => Bar,
  LineChart: () => Line,
  DonutChart: () => Doughnut,
  PolarAreaChart: () => PolarArea,
  Chart: () => Chart,
  CategoryScale: () => CategoryScale,
  Timeline: () => Timeline,
  addNotification: () => addNotification,
  mixColors: () => mixColors,
  DagreLayout: () => getLayoutedElements,
  Drawer: () => Drawer,
  config: () => Config,
  Moment: () => moment
};

const fromPairs = (pairs) =>
  Object.assign({}, ...pairs.map(([k, v]) => ({ [k]: v })));
const AllPackages = fromPairs(
  Object.keys(Packages).map((k) => [k, () => ({ exports: Packages[k]() })])
);

export default AllPackages;
