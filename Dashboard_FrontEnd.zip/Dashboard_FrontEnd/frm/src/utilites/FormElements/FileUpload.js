import React, { useState } from 'react';
import FileUploadService from '../FileUploadService';
import 'bootstrap/dist/css/bootstrap.min.css';

const FileUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [message, setMessage] = useState('');
  const [uploadtype, setUploadtype] = useState('');

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const handleFileUpload = async (e) => {
if (uploadtype != null && uploadtype!='')  {
    
        try {

      const response = await FileUploadService.uploadFile(selectedFile,uploadtype);
      setMessage(response.data);
    } catch (error) {
     
      setMessage('File upload failed!');
    }
  }
  else{
    setMessage('Please select File Type');
  }
   

    e.preventDefault();
 
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">File Uploads</div>
            <div className="card-body">
              {message && <div className="alert alert-info">{message}</div>}
              <form onSubmit={handleFileUpload}>
                <div className="form-group">
                  <label>Choose file</label>
                  <input
                    type="file"
                    className="form-control"
                    onChange={handleFileChange}
                  />
                  <label>Upload File Type</label>
                   <select id="uploadtypeid" className="form-control" name="data"  onChange={(e) => setUploadtype(e.target.value)}>
                   <option id="Select">Select</option>
                  <option id="suspectregistory">Suspect Registory</option>				
				         
                </select>
                
                </div>
                <button
                  onClick={handleFileUpload}
                  type="button" className="btn btn-primary mt-3">Upload</button>


              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileUpload;
