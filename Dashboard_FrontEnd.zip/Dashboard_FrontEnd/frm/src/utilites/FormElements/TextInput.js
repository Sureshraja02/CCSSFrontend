import { useRef, useState } from "react";
import { Overlay, OverlayTrigger, tooltip } from "react-bootstrap";
import { InfoCircleFill, Info } from "react-bootstrap-icons";

export const TextInput = ({
  id,
  label,
  name,
  placeholder,
  value,
  onChange,
  tooltip,
  error,
  type,
  className,
  ...props
}) => {
  // useField() returns [formik.getFieldProps(), formik.getFieldMeta()]
  // which we can spread on <input>. We can use field meta to show an error
  // message if the field is invalid and it has been touched (i.e. visited)

  const [show, setShow] = useState(true);
  const target = useRef(null);

  const renderError = error ? (
    <>
      <span className="fis-danger capitalize"> {error} </span>
    </>
  ) : null;

  return (
    <>
      <div className="">
        <div className="flex">
          {label && (
            <>
              <label htmlFor={id} className="form-label">
                {label}
              </label>

              {tooltip && (
                <>
                  <span className={`form-control-tooltip`}>
                    <OverlayTrigger
                      key={id}
                      overlay={
                        <tooltip key={id} id="tooltip-top">
                          {tooltip}
                        </tooltip>
                      }
                    >
                      <span className="d-inline-block">
                        <Info
                          className="ml-4 fis-primary"
                          size={20}
                          onClick={() => setShow(!show)}
                          ref={target}
                        />
                      </span>
                    </OverlayTrigger>
                  </span>
                </>
              )}
            </>
          )}
        </div>
        <input
          className={`form-control form-control-md ${className}`}
          id={id}
          name={name}
          placeholder={placeholder}
          onChange={onChange}
          value={value}
          type={type}
          {...props}
        />
        {renderError}
      </div>
    </>
  );
};
