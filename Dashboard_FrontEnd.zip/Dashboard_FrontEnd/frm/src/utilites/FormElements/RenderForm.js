import { createYupSchema } from "../YupSchemaCreator";
import { TextInput } from "./TextInput";
import * as yup from "yup";
import { Formik } from "formik";
import { LabelComponent } from "./LabelComponent";
import { Row, Col } from "react-bootstrap";
import Card from "../../components/Card";
import { useState } from "react";
import { useEffect } from "react";
import { mergeJson } from "../utils";
import { CheckBoxInput } from "./CheckBoxInput";
import { SelectInput } from "./SelectInput";
import { useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { removeLastPage } from "../../redux/PageHistorySlice";
import { usePage } from "../PageContext";
import FileUpload from "./FileUpload";
import { filterProps } from "framer-motion";

function RenderForm({
  formFormat,
  formData,
  callback,
  cancel = true,
  buttonLabel,
  cancelCallback,
  layout,
  children,
  submit=true,
}) {
  //https://codesandbox.io/p/sandbox/clever-snyder-1u410?file=%2Fsrc%2Fform.js%3A9%2C2-30%2C8
  //https://formik.org/docs/tutorial

  const [intialValue, SetIntialValue] = useState(null);
  const [yupSchemas, setyupSchemas] = useState({});
  const [parentLayout, setParentLayout] = useState(1);
  const pageHistory = useSelector((state) => state.pageHistory);
  const { setCurrentPage } = usePage();
  const dispatch = useDispatch();

  const navigate = useNavigate();
  const goBackFlow = () => {
    if (cancelCallback != undefined) cancelCallback();
    else if (pageHistory.length > 1) {
      let lastElement = pageHistory[pageHistory.length - 2];
      console.warn(lastElement);
      dispatch(removeLastPage({}));
      setCurrentPage(lastElement);
    }
  };

  useEffect(() => {
    setParentLayout(12 / layout);
  }, [layout]);

  useEffect(() => {
    SetIntialValue(formData);
  }, [formData]);

  useEffect(() => {
    if (Array.isArray(formFormat)) {
      let initialValues = {};
      let yepSchemas = {};
      formFormat.forEach((items) => {
        if (Array.isArray(items["data"])) {
          items["data"].forEach((item) => {
            if (item.type != "label") {
              initialValues[item.name] = item.value || "";
              const yepSchema = items["data"].reduce(createYupSchema, {});
              yepSchemas = mergeJson(yepSchemas, yepSchema);
            }
          });
        }
      });
      if (!intialValue) {
        SetIntialValue(initialValues);
      }
      const validateSchema = yup.object().shape(yepSchemas);
      setyupSchemas(validateSchema);
    }
  }, []);

  const renderFormElements = (data, props, layout) =>
    data.map((item, index) => {
      const fieldMap = {
        text: TextInput,
        label: LabelComponent,
        password: TextInput,
        date: TextInput,
        number: TextInput,
        color: TextInput,
        checkbox: CheckBoxInput,
        radio: CheckBoxInput,
        select: SelectInput,
        file: FileUpload,
      };
      const Component = fieldMap[item.type];
      let error = props.errors.hasOwnProperty(item.id) && props.errors[item.id];
      if (item.type) {
        let dim = 12 / (layout ? layout : 1);
        if ("grid" in item) {
          dim = item["grid"];
        }

        const { value, ...filtereditem } = item;

        return (
          <Col lg={dim} md={dim} sm={dim} className={`p-2 ${item.className} ${item.hidden && 'display-none-custom-block'}`}>
            <Component
              key={index + item.label}
              label={item.label}
              name={item.name}
              placeholder={item.placeholder}
              value={props.values[item.name] || ""}
              onChange={props.handleChange}
              error={error}
              id={item.id}
              tooltip={item.tooltip}
              type={item.type}
              data={item.data}
              disabled={item.disabled ? item.disabled : false}
              {...filtereditem}
            />
          </Col>
        );
      }
      return "";
    });

  return (
    <div className="form">
      {console.warn(intialValue)}
      {intialValue && (
        <Formik
          validationSchema={yupSchemas}
          initialValues={intialValue}
          enableReinitialize={true}
          onSubmit={(values, actions) => {
            console.warn("values", values);
            console.warn("actions", actions);
            callback(values, actions);
          }}
        >
          {(props) => (
            <form onSubmit={props.handleSubmit}>
              <>
                {formFormat.map((obj, index) => {
                  let data = obj["data"];
                  let layout = obj["layout"] ? obj["layout"] : 1;

                  if (Array.isArray(data) && data.length > 0) {
                    if ("title" in obj) {
                      return (
                        <>
                          <div className={`p-4`}>
                            <Card key={index} {...obj}>
                              <Row className={`p-3`}>
                                <Col
                                  lg={parentLayout}
                                  md={parentLayout}
                                  sm={parentLayout}
                                >
                                  <Row>
                                    {renderFormElements(data, props, layout)}
                                  </Row>
                                </Col>
                              </Row>
                            </Card>
                          </div>
                        </>
                      );
                    } else {
                      return (
                        <div className={``}>
                          <Row className={`p-3`} key={index}>
                            <Col
                              lg={parentLayout}
                              md={parentLayout}
                              sm={parentLayout}
                            >
                              <Row>
                                {renderFormElements(data, props, layout)}
                              </Row>
                            </Col>
                          </Row>
                        </div>
                      );
                    }
                  }
                })}

                {children && (
                  <>
                    <>{children({ ...props })}</>
                  </>
                )}
                <div className="flex-end">
                  {cancel && (
                    <button
                      type="button"
                      onClick={() => goBackFlow()}
                      className="btn btn-outline"
                    >
                      Cancel
                    </button>
                  )}
                  {submit && (
                  <button type="submit" className="btn btn-fis-secondary">
                    {buttonLabel ? buttonLabel : "Submit"}
                  </button>
                  )}
                </div>
              </>
            </form>
          )}
        </Formik>
      )}
    </div>
  );
}

export default RenderForm;
