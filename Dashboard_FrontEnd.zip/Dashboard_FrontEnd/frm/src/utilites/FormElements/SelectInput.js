import { useEffect } from "react";
import { useRef, useState } from "react";
import { Overlay, OverlayTrigger, tooltip } from "react-bootstrap";
import { InfoCircleFill, Info } from "react-bootstrap-icons";
import api from "../../api/BackendAPI";

export const SelectInput = ({
  id,
  label,
  name,
  placeholder,
  value,
  onChange,
  tooltip,
  error,
  type,
  url,
  data,
  dataMap,
  className,
  ...props
}) => {
  // useField() returns [formik.getFieldProps(), formik.getFieldMeta()]
  // which we can spread on <input>. We can use field meta to show an error
  // message if the field is invalid and it has been touched (i.e. visited)

  const [show, setShow] = useState(true);
  const target = useRef(null);
  const [optionData, setData] = useState([
    {
      name: "",
      value: `Select a ${label}`
    }
  ]);

  useEffect(() => {
    setData([
      ...optionData,
      ...data]);
  }, [data]);


  useEffect(() => {
    console.log(value);
  }, [value]);

  useEffect(() => {
    if (url !== undefined) {

      api.get(url).then(res => {
        let options = [];
        if (res.length > 0) {
          res.map((d, i) => {
            if (dataMap) options.push({
              name: d[dataMap['name']],
              value: d[dataMap['value']]
            }); else options.push({
              name: d['name'],
              value: d['value']
            });
            setData([...optionData, ...options]);
          });
        }

      });
      //call api yet to implement;
    }
  }, [url]);

  const renderError = error ? (
    <>
      <span className="fis-danger capitalize"> {error} </span>
    </>
  ) : null;

  return (
    <>
      <div className="mb-3">
        <div className="flex">
          {label && (
            <>
              <label htmlFor={id} className="form-label">
                {label}
              </label>

              {tooltip && (
                <>
                  <span className={`form-control-tooltip`}>
                    <OverlayTrigger
                      key={id}
                      overlay={
                        <tooltip key={id} id="tooltip-top">
                          {tooltip}
                        </tooltip>
                      }
                    >
                      <span className="d-inline-block">
                        <Info
                          className="ml-4 fis-primary"
                          size={20}
                          onClick={() => setShow(!show)}
                          ref={target}
                        />
                      </span>
                    </OverlayTrigger>
                  </span>
                </>
              )}
            </>
          )}
        </div>
        <select
          className={`form-control form-control-md ${className ? className : ""
            }`}
          id={id}
          placeholder={placeholder}
          onChange={onChange}
          value={value}
          type={type}
          {...props}
        >
          {optionData &&
            optionData.map((dt, index) => {
              return (
                <option value={dt["name"]} key={index}>
                  {dt["value"]}
                </option>
              );
            })}
        </select>
        {renderError}
      </div>
    </>
  );
};
