import { useRef, useState } from "react";
import { Overlay, OverlayTrigger, tooltip } from "react-bootstrap";
import { InfoCircleFill, Info } from "react-bootstrap-icons";

export const CheckBoxInput = ({
  id,
  label,
  name,
  placeholder,
  value,
  onChange,
  tooltip,
  error,
  type,
  ...props
}) => {
  // useField() returns [formik.getFieldProps(), formik.getFieldMeta()]
  // which we can spread on <input>. We can use field meta to show an error
  // message if the field is invalid and it has been touched (i.e. visited)

  const [show, setShow] = useState(true);
  const target = useRef(null);

  const renderError = error ? (
    <>
      <span className="fis-danger capitalize"> {error} </span>
    </>
  ) : null;

  return (
    <>
      <div className="mb-3">
        <div className="flex">
          <div className="form-check">
            {tooltip && (
              <>
                <span className={`form-control-tooltip`}>
                  <OverlayTrigger
                    overlay={<tooltip id="tooltip-disabled">{tooltip}</tooltip>}
                  >
                    <span className="d-inline-block">
                      <Info
                        className="ml-4 fis-primary"
                        size={20}
                        onClick={() => setShow(!show)}
                        ref={target}
                      />
                    </span>
                  </OverlayTrigger>
                </span>
              </>
            )}
            <input
              className="form-check-input"
              id={id}
              placeholder={placeholder}
              onChange={onChange}
              value={value}
              type={type}
              {...props}
            />
            <label htmlFor={id} className="form-check-label">
              {label}
            </label>

            {renderError}
          </div>
        </div>
      </div>
    </>
  );
};
