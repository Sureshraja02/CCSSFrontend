import axios from 'axios';
import { BACKEND_URL as API_BASE_URL } from "../config";


// const API_BASE_URL = "http://192.168.127.180:9998/api/files";

class FileUploadService {
    uploadFile(file,uploadtype) {
        const data = {
            "filename": "venkat",
            "fileType": ".txt",
            "uploadtype":uploadtype

        }
        const formData = new FormData();
        formData.append("file", file);
        formData.append('request',
            new Blob([JSON.stringify(data)], {
                type: 'application/json'
            }));


        return axios.post(`${API_BASE_URL}/api/files/upload`, formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        });
    }
}

export default new FileUploadService();
