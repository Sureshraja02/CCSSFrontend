import { App } from "antd"

let message
let notification
let modal

export default () => {
  const fn = App.useApp()
  message = fn.message
  notification = fn.notification
  modal = fn.modal
  return null
}
export { message, notification, modal }
