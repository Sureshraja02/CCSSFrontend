import React, { Component, createContext, useContext, useState } from "react";
import { filterJson, findObject, reduceJson, sortArray } from "./utils";
import { useDispatch, useSelector } from "react-redux";
import { addPage } from "../redux/PageHistorySlice";

const PageContext = createContext();

export const usePage = () => {
  return useContext(PageContext);
};

export const PageProvider = ({ children }) => {
  const initalState = {
    currentPage: "login",
    rawMenu: [],
    convertedMenu: [],
    menuLevels: [],
    breadcrumbsData: [],
    activeMenus: ["a"],
  };

  //always maintain intial state in this file
  const [page, setPageState] = useState(initalState);
  const [currentPage, setcurrentPage] = useState("");
  const [currentMenu, setcurrentMenu] = useState([]);
  const [pageData, setPData] = useState({});
  const pageHistory = useSelector(state => state.pageHistory);
  const dispatch = useDispatch();


  const updatePage = (data) => {
    setPageState((prevState) => {
      const newState = { ...prevState };

      Object.keys(data).forEach((key, i) => {
        newState[key] = data[key];
      });
      return newState;
    });
  };

  const resetPage = () => {
    setPageState(initalState);
  };

  const setCurrentPage = (pg) => {
    dispatch(addPage(pg));
    setcurrentPage(pg);
    setPageState({
      ...page,
      currentPage: pg,
    });
  };

  const setCurrentMenu = (menu) => {
    setPageState({
      ...page,
      menuLevels: menu,
    });
    setcurrentMenu(menu);
  };

  const findMatchingObject = (tid) => {
    var jsonData = page.rawMenu;
    var resultData = [];
    jsonData.filter((obj, index, arr) => {
      if (typeof obj === "object") {
        if (obj["tid"] == tid) {
          return pushDataToArray(arr, obj, resultData);
          //   return result;
        }
      }
    });
    return resultData;
  };

  const pushDataToArray = (arr, obj, resultData) => {
    if (Array.isArray(obj) && obj.length === 1) obj = obj[0];
    resultData.push(obj);
    if (obj["parentTId"] !== undefined && obj["parentTId"] !== null) {
      pushDataToArray(
        arr,
        filterJson([...arr], "tid", obj["parentTId"]),
        resultData
      );
    }
    return resultData;
  };

  const setActiveMenu = (menu, tid) => {
    const currentPage = menu["path"];
    setCurrentPage(currentPage);
    setPageState({
      ...page,
      breadcrumbsData: sortArray(findMatchingObject(tid), "tid"),
      currentPage: currentPage,
    });
  };

  const setPageData = (data) => {
    setPData({ ...data });
  }

  return (
    <PageContext.Provider
      value={{
        currentPage,
        page,
        currentMenu,
        pageData,
        setCurrentMenu,
        updatePage,
        resetPage,
        setCurrentPage,
        setActiveMenu,
        setPageData
      }}
    >
      {children}
    </PageContext.Provider>
  );
};
