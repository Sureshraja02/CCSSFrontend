import React, { Component, createContext, useContext, useState } from "react";

const GlobalContext = createContext();

export const useGlobalContext = () => {
  return useContext(GlobalContext);
};

const initalState = {
  welcomeMsg: "Welcome,",
  firstTimeLogin: false,
  logo: "",
  loading: false,
  username: "Arun Pandian",
  email: "abc@demo.com",
  aMenu: "",
  module_menu: "0",
  sideMenu: true,
  appPrimaryColor: "",
  appSecondaryColor: "",
  timeline:"TODAY",
  timelineLable:"Today",
};

export const GlobalProvider = ({ children }) => {
  //always maintain intial state in this file
  const [globalState, setGlobalState] = useState(initalState);

  const updateGlobalState = (data) => {
    setGlobalState((prevState) => {
      const newState = { ...prevState };

      Object.keys(data).forEach((key, i) => {
        newState[key] = data[key];
      });
      return newState;
    });
  };

  const resetGlobalState = () => {
    setGlobalState(initalState);
  };

  return (
    <GlobalContext.Provider
      value={{ globalState, updateGlobalState, resetGlobalState }}
    >
      {children}
    </GlobalContext.Provider>
  );
};
