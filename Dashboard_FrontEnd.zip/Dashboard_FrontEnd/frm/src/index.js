import React from "react";
import ReactDOM from "react-dom/client";
import Navigations from "./router/Navigations";
import "reactflow/dist/style.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "./index.css";
import "./static/css/antdgrid.css";
import { Provider } from "react-redux";
import { persistor, store } from "./redux/store";

import { PageProvider } from "./utilites/PageContext";
import { injectStore } from "./api/BackendAPI";
import { PersistGate } from "redux-persist/integration/react";
import HOC from "./HOC";
import { ConfigProvider } from "antd";
import { GlobalProvider } from "./utilites/GlobalContext";
import AntWrapper from "./utilites/AntWrapper";
import "./App.css";
import "./static/css/custom.scss";
import 'react-modern-drawer/dist/index.css'

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.Fragment>
    <AntWrapper />
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <GlobalProvider>
          <PageProvider>
            <HOC>
              <Navigations />
            </HOC>
          </PageProvider>
        </GlobalProvider>
      </PersistGate>
    </Provider>
  </React.Fragment>
);

injectStore(store);
