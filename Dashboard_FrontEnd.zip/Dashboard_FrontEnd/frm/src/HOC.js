import "./App.css";
import { useEffect, useState } from "react";
import { useGlobalContext } from "./utilites/GlobalContext";
import Modal from "./components/Modal";
import LoadingComponent from "./components/LoadingComponent";
import { useDispatch, useSelector } from "react-redux";
import { removeNotification } from "./redux/notifySlice";
import { ConfigProvider, notification } from "antd";

function HOC({ children }) {
  const { globalState, updateGlobalState } = useGlobalContext();
  const [loading, setLoading] = useState(false);

  const notify = useSelector((state) => state.notify);
  const dispatch = useDispatch();
  useEffect(() => {
    updateGlobalState({
      page: "page",
      welcomeMsg: "welcome",
    });
  }, []);

  const onClose = (id) => {
    dispatch(removeNotification(id));
  };
  useEffect(() => {
    if (notify.length > 0) {
      notify.map((data, index) => {
        notification[data.type]({
          message: data.title,
          description: data.desc,
          onClose: onClose(data.id),
        });
      });
    }
  }, [notify]);

  useEffect(() => {
    setLoading(globalState.loading);
    console.warn(
      "runs everytime when a loading is set / unset status : " + loading
    );

    setTimeout(() => {
      updateGlobalState({
        loading: false,
      });
    }, 5000);
  }, [globalState.loading]);

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary:
            globalState.appPrimaryColor !== undefined &&
              globalState.appPrimaryColor !== null
              ? globalState.appPrimaryColor
              : "#8DC63F",
          colorSecondary:
            globalState.appSecondaryColor !== undefined &&
              globalState.appSecondaryColor != null
              ? globalState.appSecondaryColor
              : "#4bcd3e",
        },
      }}
    >
      <div className="App">
        <div className="full-layout">
          {loading ? (
            <>
              {" "}
              <LoadingComponent show={loading}>
                <img src={`${process.env.PUBLIC_URL}/logo.png?ts=${globalState.rand}`} style={{ height: "100px" }} />
                <div
                  className="spinner-grow text-success spinner-grow-sm"
                  role="status"
                >
                  <span className="visually-hidden"></span>
                </div>
                &nbsp;
                <div
                  className="spinner-grow fis-secondary spinner-grow-sm"
                  role="status"
                >
                  <span className="visually-hidden"></span>
                </div>
                &nbsp;
                <div
                  className="spinner-grow fis-primary spinner-grow-sm"
                  role="status"
                >
                  <span className="visually-hidden"></span>
                </div>
                <div>
                  &nbsp;
                  <span className="text-success"> Loading ... </span>
                </div>
              </LoadingComponent>
            </>
          ) : (
            <></>
          )}
          {children}
        </div>
      </div>
    </ConfigProvider>
  );
}

export default HOC;
