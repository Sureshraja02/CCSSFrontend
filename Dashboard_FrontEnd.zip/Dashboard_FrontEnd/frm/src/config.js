//no slash at the end of the url

// export const API_URL = process.env.NODE_ENV === "development" ? "http://localhost:8080" : "/ngpdev/ccss/plugins/"; //https://iasuat.fisglobal.com/ngpdev/rms/plugins http://10.192.48.213:8443/ngpdev/rms/plugins
// export const BACKEND_URL = process.env.NODE_ENV === "development" ? "http://localhost:9998" : "/ngpdev/ccss/backops";

//Jan 09
//export const API_URL = process.env.NODE_ENV === "development" ? "http://localhost:8080" : "/ngpdev/ccss/dev/plugins/"; //https://iasuat.fisglobal.com/ngpdev/rms/plugins http://10.192.48.213:8443/ngpdev/rms/plugins
//export const BACKEND_URL = process.env.NODE_ENV === "development" ? "http://localhost:9998" : "/ngpdev/ccss/backops";
//export const MNRL_BACKEND_URL = process.env.NODE_ENV === "development" ? "http://localhost:9888" : "/ngpdev/ccss/mnrlbackops";

export const API_URL = process.env.NODE_ENV === "development" ? "http://localhost:8080" : "/ngp/ccss/plugins/"; //https://iasuat.fisglobal.com/ngpdev/rms/plugins http://10.192.48.213:8443/ngpdev/rms/plugins
export const BACKEND_URL = process.env.NODE_ENV === "development" ? "http://localhost:9998" : "./backops";
export const MNRL_BACKEND_URL = process.env.NODE_ENV === "development" ? "http://localhost:9888" : "./mnrlbackops";


//export const CONTEXT_PATH = "/ngpdev/ccss/dev";
export const CONTEXT_PATH = "/ngp/ccss";
export const ENCRYPT_ON_TRANSIT = false;


export const HTTP_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Accept": "*/*"
    // add sub-headers in case of any.    
}
