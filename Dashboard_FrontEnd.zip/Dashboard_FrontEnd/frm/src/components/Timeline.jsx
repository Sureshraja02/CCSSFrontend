import React from 'react';

const TimelineItem = ({ title, date, description, alignLeft }) => (
    <div className={`timeline-item ${alignLeft ? 'align-left' : 'align-right'} row`}>
        <div className="col-md-6">
            <div className="timeline-content p-3">
                <h5 className="fw-bold">{title}</h5>
                <p className="text-muted">{date}</p>
                <p>{description}</p>
            </div>
        </div>
    </div>
);

const Timeline = () => (
    <div className="timeline-container">
        <TimelineItem
            title="Project Started"
            date="January 2023"
            description="Initiated the project with initial design and setup."
            alignLeft={true}
        />
        <TimelineItem
            title="Phase 1 Completed"
            date="March 2023"
            description="Completed the first phase with core functionalities."
            alignLeft={false}
        />
        <TimelineItem
            title="Beta Release"
            date="July 2023"
            description="Launched the beta version for testing and feedback."
            alignLeft={true}
        />
        {/* Add more TimelineItem components as needed */}
    </div>
);

export default Timeline;
