import { useState } from 'react';
import { Spinner } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function LoadingComponent({ show, children }) {


  return (
    <>

      <Modal
        show={show}
        // onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Body>
          {children ? children : (
            <div className={`flex`}>
              <Spinner className={`m-2`} animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
              </Spinner>
              <span className="flex-center">Loading...</span>
            </div>
          )}
        </Modal.Body>
      </Modal>
    </>
  );
}

export default LoadingComponent;
