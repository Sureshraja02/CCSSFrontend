import React from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

function Model({ isOpen, title, handleClose, children, close, className }) {
  if (!isOpen) return null;

  return (
    <>
      <div className=''>

        <Modal
          className={`custom-card ${className}`}
          show={isOpen}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >

          {title && (
            <Modal.Header closeButton={close} className={`card-header`}>
              <Modal.Title>{title}</Modal.Title>
            </Modal.Header>
          )}
          <Modal.Body className={`card-body`}>
            <div className="p-2">
              {children}
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </>


  );
};

export default Model;
