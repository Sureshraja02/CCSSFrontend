import * as IconMap from "react-bootstrap-icons";
import { capitalize, toCamelCase } from "../utilites/utils";




const IconWrapper = ({ iconName, size = 14, color = 'inherit', className = '' }) => {


    if (typeof (iconName) == "string" && iconName.includes("false")) return null;
    if (typeof (iconName) === "boolean" && !iconName) return null;
    const IconComponent = IconMap[toCamelCase(iconName)];
    if (!IconComponent) {
        console.warn(`Icon with name ${iconName} does not exists...`);
        return null;
    }

    return <IconComponent size={size} color={color} className={className} />
}

export default IconWrapper;
