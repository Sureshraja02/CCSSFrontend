function Divider({ className }) {
    return (<>
        <div className={`bs-border-bottom ${className ? className : ''}`} />
    </>);
}

export default Divider;
