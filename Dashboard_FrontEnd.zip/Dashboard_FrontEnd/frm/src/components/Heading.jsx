import { Row, Col } from 'react-bootstrap';

function Heading({ children, title, subHeading, subTitle }) {
    return (<>

        <div className="pg-heading pt-1">
            <Row>
                <Col>
                    <h3>{title}</h3>
                </Col>
            </Row>
            <Row>
                {(subHeading || subTitle) && (
                    <Col>
                        <div className="pg-sub-heading">
                            <h6>{subHeading || subTitle}</h6>
                        </div>
                    </Col>
                )}
            </Row>

        </div >

    </>);
}

export default Heading;
