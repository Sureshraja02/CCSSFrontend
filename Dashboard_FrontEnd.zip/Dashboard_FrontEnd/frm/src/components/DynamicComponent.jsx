import React, { useMemo, Suspense } from 'react';
import { fetchComponent } from '../api/RemoteComponentAPI';
import LoadingComponent from './LoadingComponent';


const DynamicComponent = ({ __id, data, children, ...props }) => {
    const Component = useMemo(() => {
        return React.lazy(async () => fetchComponent(__id))
    }, [__id]);

    return (
        <Suspense fallback={<LoadingComponent />}>
            <Component {...data} {...props}>{children}</Component>
        </Suspense>
    )
};

export default React.memo(DynamicComponent);
