import { useEffect, useState } from "react";
import Heading from "./Heading";
import { CaretRightFill, CaretDownFill, ArrowClockwise } from "react-bootstrap-icons";
import { Row, Col } from "react-bootstrap";
import { TextInput } from "../utilites/FormElements/TextInput";
import PopOver from "./PopOver";
import { Pagination } from "antd";

function Card({ children, title, collapsible, isCollapsed, className, cardBodyClassName, subTitle, count, customHeaderComponents, table, filterCallback, filterLabel, refreshCallback, currentElement,
    pagingCallback,
    pageSize,
    showPaging,
    totalElements,
    inline
}) {


    const [isOpened, SetOpened] = useState(true);


    useEffect(() => {
        SetOpened(!isCollapsed);
    }, [isCollapsed]);


    return (<>
        <div className={`row custom-card ${className ? className : ''}`}>
            <Col>
                <div className="card">

                    <div className="card-header position-relative">
                        {title && (
                            <Row>
                                <Col className="flex-center col" lg={`${customHeaderComponents ? 6 : 12}`} md={`${customHeaderComponents ? 6 : 12}`}>
                                    <div
                                        onClick={() => collapsible && SetOpened(!isOpened)}
                                        className={`${collapsible ? 'flex-center pr-10 cursor-pointer' : ''}`}>
                                        <>{collapsible ?
                                            !isOpened ? (
                                                <CaretRightFill className={``} size={16} />
                                            ) : (
                                                <CaretDownFill className={``} size={16} />
                                            )

                                            : <></>}</>


                                        <div className="flex-direction-row flex-1">

                                            <div className="flex-direction-row flex flex-1">

                                                <h4 className="heading">
                                                    {title}
                                                </h4>
                                                {count && <><span className={`mx-2`}>( {count} )</span></>}
                                            </div>
                                            {subTitle && (

                                                <p className="sub-heading text-align-justify">
                                                    {subTitle}
                                                </p>
                                            )}
                                        </div>
                                    </div>

                                </Col>
                                <Col className={`col`} lg={6} md={6}>

                                    {customHeaderComponents && (
                                        <>
                                            <div className="flex-end pt-1 card-header-button-location">
                                                {refreshCallback && (

                                                    <button className={`custom-reload-button btn btn-outline`} onClick={refreshCallback}>
                                                        <ArrowClockwise size={20} />
                                                    </button>
                                                )}
                                                {customHeaderComponents}
                                            </div>
                                        </>
                                    )}
                                </Col>
                            </Row>

                        )}

                        {table && (<>
                            <Row className={`p-2`}>
                                <Col lg={6} md={6} className="mt-2 align-items-sm-stretch ">
                                    {
                                        filterCallback && (<>
                                            <TextInput type={"text"} placeholder={`Filter by ${filterLabel ? filterLabel
                                                : ""}`} className={`inner-box-shadow`}
                                                onChange={filterCallback}
                                            />
                                        </>
                                        )
                                    }
                                </Col>


                                <Col lg={6} md={6} className="mt-2 flex-end align-center justify-content-sm-end ">
                                    <div>
                                        {showPaging && (
                                            <Pagination
                                                current={currentElement}
                                                onChange={pagingCallback}
                                                total={totalElements}
                                                showLessItems
                                            />
                                        )}
                                    </div>
                                    {/* <div className="flex">
                                            <div className="me-3">
                                                <PopOver size={20} show={false}>Hello world</PopOver>
                                            </div>
                                        </div> */}
                                </Col>
                            </Row>
                        </>
                        )}
                    </div>

                    {
                        (isOpened && children) && (

                            <div className={`${table | 'card-body'}  ${cardBodyClassName ? cardBodyClassName : ''}`}>
                                <div className="">
                                    {children}
                                </div>
                            </div>
                        )
                    }

                </div>
            </Col>
        </div>

    </>);
}

export default Card;
