import { useState, useEffect } from "react";
import { ChevronRight, ChevronDown, MenuApp } from "react-bootstrap-icons";
import { Navbar } from "react-bootstrap";
import Dropdown from "react-multilevel-dropdown";
import { usePage } from "../utilites/PageContext";
import { useGlobalContext } from "../utilites/GlobalContext";
import { Col, Row, Nav } from "react-bootstrap";

const TopMenu = ({ menus }) => {
  const { page, updatePage, setActiveMenu } = usePage();
  const { globalState, updateGlobalState } = useGlobalContext();
  const [menu, setMenus] = useState([]);
  const [activeMenu, storeActiveMenu] = useState([]);

  useEffect(() => {
    storeActiveMenu(page.breadcrumbsData);
  }, [page.breadcrumbsData]);

  const handleMenuClick = (data, dept) => {
    if (data["children"].length === 0) {
      setActiveMenu(data, data["tid"]);
    }
  };

  const backgroundImage = `URL(${ChevronDown}) no-repeat right 50%`;

  const DropdownListItem = ({
    dept,
    data,
    hasSubMenu,
    menuName,
    menuIndex,
  }) => {
    return data.map((menu, index) => {
      return (
        <>
          <div
            //        className={`menu-border-class ${activeMenus.includes(data) ? "active" : "activeElement"}`}
            dept={dept}
            key={index}
            onClick={() => handleMenuClick(menu, dept)}
          >
            <Dropdown.Item
              key={index}
              className={`dropdown-item-class 
              
              ${
                activeMenu !== undefined && activeMenu.includes(menu)
                  ? "active"
                  : ""
              }`}
            >
              <Row className={``}>
                <Col lg={8} md={8} sm={10}>
                  <span>{menu.label}</span>
                </Col>
                <Col className={"justify-center align-self-center"}>
                  {menu.children.length > 0 && <ChevronRight />}
                </Col>
              </Row>

              {menu.children.length > 0 && (
                <>
                  <SubMenu
                    dept={dept}
                    data={menu.children}
                    menuIndex={menuIndex}
                  />
                </>
              )}
            </Dropdown.Item>
          </div>
        </>
      );
    });
  };

  const ListMenu = ({ dept, data, hasSubMenu, menuName, menuIndex }) => {
    dept = dept + 1;
    data["dept"] = dept;
    console.warn(activeMenu);
    console.warn(data);
    console.warn(activeMenu.includes(data));
    return (
      <div
        //        className={`menu-border-class ${activeMenus.includes(data) ? "active" : "activeElement"}`}
        dept={dept}
        key={menuIndex}
        onClick={() => handleMenuClick(data, dept)}
      >
        <Dropdown.Item
          className={`dropdown-item-class ${
            activeMenu !== undefined && activeMenu.includes(data)
              ? "active"
              : ""
          }`}
        >
          <Row className={``}>
            <Col lg={8} md={8} sm={10}>
              <span>{data.label}</span>
            </Col>
            <Col className={"justify-center align-self-center"}>
              {hasSubMenu && <ChevronRight />}
            </Col>
          </Row>

          {hasSubMenu && (
            <>
              <SubMenu dept={dept} data={data.children} menuIndex={menuIndex} />
            </>
          )}
        </Dropdown.Item>
      </div>
    );
  };

  const SubMenu = ({ dept, data, menuIndex }) => {
    return (
      <Dropdown.Submenu position="right">
        {data.map((menu, index) => {
          const menuName = `sidebar-submenu-${dept}-${menuIndex}-${index}`;
          dept = dept + 1;
          menu["dept"] = dept;

          return (
            <ListMenu
              dept={dept}
              data={menu}
              hasSubMenu={menu.children.length > 0}
              menuName={menuName}
              key={menuName}
              menuIndex={index}
            ></ListMenu>
          );
        })}
      </Dropdown.Submenu>
    );
  };

  return (
    <>
      {menus !== undefined &&
        menus !== null &&
        menus.map((menu, index) => {
          const dept = 1;
          const menuName = `sidebar-menu-${dept}-${index}`;
          menu["dept"] = dept;

          if (menu.children.length > 0) {
            return (
              <Dropdown
                key={index}
                isOpen={false}
                toggle={false}
                style={{
                  background: `${backgroundImage}`,
                }}
                isActive={menu.hasOwnProperty("active") && menu.active}
                buttonClassName={`header-outline      ${
                  activeMenu !== undefined && activeMenu.includes(menu)
                    ? "activeTop"
                    : ""
                }
                } ${menuName}`}
                title={menu.label}
                //       onClick={() => handleMenuClick(menu, dept)}
                position="right"
              >
                <DropdownListItem
                  dept={dept}
                  data={menu.children}
                  hasSubMenu={menu.children.length > 0}
                  menuName={menuName}
                  key={menuName}
                  menuIndex={index}
                />
              </Dropdown>
            );
          } else {
            return (
              <>
                <Nav.Link
                  onClick={() => handleMenuClick(menu, dept)}
                  className={`header-menu-link ${
                    activeMenu !== undefined && activeMenu.includes(menu)
                      ? "activeTop"
                      : ""
                  }`}
                  href="#"
                >
                  {menu.label}
                </Nav.Link>
              </>
            );
          }
        })}
    </>
  );
};

export default TopMenu;
