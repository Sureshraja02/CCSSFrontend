import "./header.css";
import Row from "react-bootstrap/esm/Row";
import Col from "react-bootstrap/esm/Col";
import { useGlobalContext } from "../utilites/GlobalContext";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { mergeJson } from "../utilites/utils";
import { BoxArrowRight, Power, Gear } from "react-bootstrap-icons";
import ChangePassword from "../pages/ChangePassword";
import TopMenu from "./TopMenu";
import { usePage } from "../utilites/PageContext";
import PopOver from "../components/PopOver";

function Header({ menudatas, headerMenu, saveSelect, setMenu, currentPage, valueSelect, minimizeMenu }) {
  const { globalState } = useGlobalContext();
  const { updatePage } = usePage();
  const navigate = useNavigate();


  const logout = () => {
    //logout functionalities
    navigate("/login");
  }


  useEffect(() => {

    if (menudatas.length > 0) {
      setMenu(menudatas[0]);
      updatePage({
        menuLevels: menudatas,
      });
    }
  }, [menudatas]);




  return (
    <>
      <div className={`topbar-wrapper ${globalState.sideMenu ? 'side-menu-layout' : 'top-menu-layout'}`}>
        <div className="max-width-100">
          <div className="bb-10">
            <Row className="min-height-50">
              <Col lg="5" >
                {!globalState.sideMenu && (
                  <img
                    src={globalState.logo}
                    className="header-logo"
                    alt="app logo"
                  />

                )}
              </Col>
              <Col lg="7" className="justify-center flex-end">
                <div className="display-flex menu-location">
                  <span className="welcome justify-center capitalize">
                    {globalState.welcomeMsg}, {globalState.username}{" "}
                  </span>{" "}
                  &nbsp; <span className="justify-center">|</span> &nbsp;
                  <span onClick={() => (navigate("/change-password"))} className="justify-center cursor-pointer capitalize">Change Password</span> &nbsp; <span className="justify-center">|</span> &nbsp;

                  {/* <span className="justify-center kjustify-center">|</span> &nbsp; */}
                  <span onClick={() => logout()} className="justify-center cursor-pointer capitalize">logout &nbsp; <Power size={16} className="justify-center align-self-center" /> </span> &nbsp;

                </div>
              </Col>
            </Row>
          </div>

          <nav className="navbar navbar-expand-lg sticky-header navbar-light nav-bg">
            <div className="container-fluid">
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className={`collapse navbar-collapse ${minimizeMenu ? 'pl-40' : ''}`} id="navbarNav">
                <ul className="nav" id="fisCustomMenu">
                  {
                    !globalState.sideMenu ? (
                      <TopMenu menus={menudatas} />
                    ) : (<>

                      {/* {Object.keys(headerMenu).map((key, i) => {
                        return (
                          <>
                            <Nav.Link
                              onClick={() => valueSelect(key)}
                              className={`header-menu-link ${globalState.module_key !== undefined && globalState.module_key === key
                                ? "activeTop"
                                : ""
                                }`}
                              href="#"
                            >
                              {headerMenu[key]}
                            </Nav.Link>
                          </>
                        )

                      })} */}



                    </>)
                  }
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}

export default Header;
