import {
  ChevronRight,
  ChevronDown,
  XLg,
  List,
  HouseExclamation,
} from "react-bootstrap-icons";
import { usePage } from "../utilites/PageContext";
import { useEffect, useState } from "react";
import { mixColors, reduceJson } from "../utilites/utils";
import { useGlobalContext } from "../utilites/GlobalContext";
import tinycolor from "tinycolor2";
import { Row, Col } from "react-bootstrap";
import { StrictMode } from "react";
import { CircleFill } from "react-bootstrap-icons";
import IconWrapper from "../components/IconWrapper";

const SideMenu = ({ menus, isMenuMiniized }) => {
  const { page, updatePage, setActiveMenu } = usePage();
  const { globalState, updateGlobalState } = useGlobalContext();
  const [activeMenus, setActiveMenus] = useState([]);

  useEffect(() => {
    setActiveMenus(page.breadcrumbsData);
  }, [page.breadcrumbsData]);

  const handleMenuClick = (data, dept) => {
    data["dept"] = dept;
    if (activeMenus.includes(data)) {
      var index = activeMenus.indexOf(data);
      if (index > -1) {
        activeMenus.splice(index, 1);
      }
    } else {
      activeMenus.push(data);
    }

    updatePage({
      activeMenus: activeMenus,
    });

    if (data["children"].length === 0) {
      setActiveMenu(data, data["tid"]);
    }
  };

  const ListMenu = ({ dept, data, hasSubMenu, menuName, menuIndex }) => {
    switch (dept) {
      case 1:
        return (
          <div>
            <li className={menuName} key={dept + menuIndex}>
              {data.path != null && data.path != undefined ? (
                <div
                  className={`menu-border-class ${
                    activeMenus.includes(data) ? "active" : "activeElement"
                  }`}
                  dept={dept}
                  key={dept}
                  onClick={() => handleMenuClick(data, dept)}
                >
                  <Row className={`flex-1`}>
                    <Col lg={1} sm={1} md={1} className={`align-center me-2`}>
                      <IconWrapper iconName={data.icon != null && data.icon} />
                    </Col>
                    <Col lg={10} md={10} sm={10} key={menuIndex}>
                      <a className="capitalize">{data.label}</a>
                    </Col>
                  </Row>
                </div>
              ) : (
                <Row>
                  <div className={`sideMenu-heading no-clickable`}>
                    <Col lg={8} md={8} sm={8} key={dept + menuIndex}>
                      <span className="uppercase">{data.label}</span>
                    </Col>
                  </div>
                </Row>
              )}
            </li>
            {hasSubMenu && (
              <SubMenu
                dept={dept}
                key={menuIndex}
                data={data.children}
                menuIndex={menuIndex}
              />
            )}
          </div>
        );
      case 2:
        return (
          <li className="" key={menuIndex}>
            <Row
              className={``}
              key={menuIndex}
              // style={{
              //   paddingLeft: "5" * dept,
              // }}
            >
              <div
                className={`menu-border-class ${
                  activeMenus.includes(data) ? "active" : "activeElement"
                }`}
                dept={dept}
                key={dept}
                onClick={() => handleMenuClick(data, dept)}
              >
                <div className={`display-flex align-center align-self-center`}>
                  <IconWrapper
                    className={`flex me-2`}
                    iconName={data.icon != null && data.icon}
                  />

                  <a className={`capitalize display-flex flex`}>{data.label}</a>
                </div>
                {hasSubMenu && (
                  <>
                    <div className={`flex-1 flex-end`}>
                      {activeMenus.includes(data) ? (
                        <ChevronDown
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      ) : (
                        <ChevronRight
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      )}
                    </div>
                  </>
                )}

                {/* <Row className={`flex-1`}>
                  <Col lg={1} sm={1} md={1} className={`align-center`}>
                    <IconWrapper
                      size={20}
                      iconName={data.icon != null && data.icon}
                    />
                  </Col>
                  <Col lg={10} md={10} sm={10} key={menuIndex}>
                    <a className="capitalize">{data.label}</a>
                  </Col>
                </Row> */}
                {/* <Col className={"flex-end"} key={menuIndex + menuName}>
                  {hasSubMenu && (
                    <>
                      {activeMenus.includes(data) ? (
                        <ChevronDown
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      ) : (
                        <ChevronRight
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      )}
                    </>
                  )}
                </Col> */}
              </div>
            </Row>
            {hasSubMenu && activeMenus.includes(data) && (
              <SubMenu
                dept={dept}
                key={menuIndex}
                data={data.children}
                menuIndex={menuIndex}
              />
            )}
          </li>
        );
      default:
        return (
          <li className="" key={menuIndex}>
            <Row
              className={``}
              key={menuIndex}
              // style={{
              //   paddingLeft: "5" * dept,
              // }}
            >
              <div
                className={`menu-border-class ${
                  activeMenus.includes(data) ? "active" : "activeElement"
                }`}
                dept={dept}
                key={dept}
                onClick={() => handleMenuClick(data, dept)}
              >
                <Col lg={8} md={8} sm={10} key={menuIndex}>
                  <Row className={`sub-menu`}>
                    <Col className={`align-center`} key={2} sm={2}>
                      <CircleFill className={`sub-menu-icon`} size={3} />
                    </Col>
                    <Col sm={10}>
                      <a className="capitalize">{data.label}</a>
                    </Col>
                  </Row>
                </Col>
                <Col className={"flex-end"} key={menuIndex + menuName}>
                  {hasSubMenu && (
                    <>
                      {activeMenus.includes(data) ? (
                        <ChevronDown
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      ) : (
                        <ChevronRight
                          key={menuIndex}
                          onClick={() => handleMenuClick(data, dept)}
                        />
                      )}
                    </>
                  )}
                </Col>
              </div>
            </Row>
            {hasSubMenu && activeMenus.includes(data) && (
              <SubMenu
                dept={dept}
                key={menuIndex}
                data={data.children}
                menuIndex={menuIndex}
              />
            )}
          </li>
        );
    }
  };
  const SubMenu = ({ dept, data, menuIndex }) => {
    dept = dept + 1;
    data["dept"] = dept;
    return (
      <ul
        className={`${
          activeMenus.includes(data) ? "display-block" : "display-none"
        } timeline`}
      >
        {data.map((menu, index) => {
          const menuName = `sub-menu sidebar-submenu-${dept}-${menuIndex}-${index}`;
          return (
            <div key={index}>
              <ListMenu
                dept={dept}
                data={menu}
                hasSubMenu={menu.children.length > 0}
                menuName={menuName}
                key={menuName}
                menuIndex={index}
              ></ListMenu>
            </div>
          );
        })}
      </ul>
    );
  };

  return (
    <>
      <StrictMode>
        <ul key={menus.length}>
          {menus.map((menu, index) => {
            const dept = 1;
            const menuName = dept + index;
            menu["dept"] = dept;

            return (
              <>
                <ListMenu
                  dept={dept}
                  data={menu}
                  hasSubMenu={menu.children.length > 0}
                  menuName={menuName}
                  key={menuName}
                  menuIndex={index}
                />
              </>
            );
          })}
        </ul>

        <div className="pd-50" key={menus.length} />
      </StrictMode>
    </>
  );
};

export default SideMenu;
