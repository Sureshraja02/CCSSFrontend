import Modal from "../components/Modal";
import Layout from "../main";
import RenderForm from "../utilites/FormElements/RenderForm";
import registerForm from '../json/changePassword.json';
import { useNavigate } from "react-router";
import { Button } from "react-bootstrap";
import BackButton from "../utilites/FormElements/BackButton";
import Heading from "../components/Heading";
import { CommonAPI } from "../api/backendAPI/CommonAPI";
import { useGlobalContext } from "../utilites/GlobalContext";

function ChangePassword() {

    const navigate = useNavigate();

    const { globalState, updateGlobalState } = useGlobalContext();


    const callback = (values, actions) => {

     
        CommonAPI.changePassword(globalState.email, values.newPassword, values.oldPassword).then((res) => {

            var dt = res;

            console.warn(dt);

        });

        navigate("/home");
    }

    return (<>

        <Modal isOpen={true}>
            <div className="flex-center">

                <BackButton callback={() => (navigate(-1))} label="Back" />
                <Heading title="Change Password"></Heading>
            </div>

            <RenderForm formFormat={registerForm}
                callback={(values, actions) => callback(values, actions)}
            />


        </Modal>
    </>);
}

export default ChangePassword;
