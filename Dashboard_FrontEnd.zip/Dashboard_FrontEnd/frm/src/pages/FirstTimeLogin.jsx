import Modal from "../components/Modal";
import Layout from "../main";
import RenderForm from "../utilites/FormElements/RenderForm";
import registerForm from '../json/firstTimeLogin.json';
import { useNavigate } from "react-router";
import { hash } from "../utilites/crypto";
import { CommonAPI } from "../api/backendAPI/CommonAPI";

function FirstTimeLogin() {

    const navigate = useNavigate();

    const callback = (values, actions) => {
        CommonAPI.changePassword("Super Admin", values.confirmPassword, values.oldPassword).then((res) => {
            navigate("/home");
        });

    }

    return (<>

        <Modal isOpen={true}>

            <h4>Password Expired</h4>
            <h6>Please use the below form to update your password</h6>
            <RenderForm formData={registerForm} cancelCallback={() => alert("clicked")} cancel={false}
                buttonLabel={"Submit"}
                callback={(values, actions) => callback(values, actions)}
            />


        </Modal>
    </>);
}

export default FirstTimeLogin;
