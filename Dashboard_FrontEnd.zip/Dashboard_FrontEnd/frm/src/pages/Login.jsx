import loginBg from "../static/i4cpng.png";
import logo from "../static/fislogo.png";

import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { CommonAPI } from "../api/backendAPI/CommonAPI";
import { useGlobalContext } from "../utilites/GlobalContext";
import { ChangeStyle, arrayToJson, convertToMultiLevel, findTextColor, groupJsonByKey, isColorDark, random } from "../utilites/utils";
import { usePage } from "../utilites/PageContext";
import tinycolor from "tinycolor2";
import { GenerateSecretKey, generateSnowFlakeID } from "../utilites/crypto";
import { Alert, Row, Col, Timeline } from "antd";
import { useDispatch } from "react-redux";
import { addNotification } from "../redux/notifySlice";

import LoginResponse from "../json/login_response.json";
import { addAuth, reset } from "../redux/authSlice";


function Login() {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const { globalstate, updateGlobalState, resetGlobalState } = useGlobalContext();
  const navigate = useNavigate();
  const { currentPage, setCurrentPage, updatePage, page } = usePage();

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(reset());
  }, []);


  const doLogin = (event) => {
    CommonAPI.Login(email, password).then((res) => {
      var dt = res;






      if (res.data !== undefined) dt = res.data;
      // if (process.env.NODE_ENV === "development") {
      //   dt['menu'] = LoginResponse['menu'];
      // }


      if ("userDetails" in dt) {

        var activeColor = dt['userDetails']['appPrimaryColor'] || "#8DC63F";
        var SecondaryColor = dt['userDetails']['appSecondaryColor'] || "#4bcd3e";

        //update global settings
        updateGlobalState({
          "userDetails": dt['userDetails'],
          "firstTimeLogin": false,
          "username": dt['userDetails']['userName'],
          "email": email,
          "auth": '111111',
          "rand": random(),
          "logo": `${process.env.PUBLIC_URL}/logo.png?ts=${random()}`,
          "moduleKeyList": arrayToJson(dt['modules']),
          "appPrimaryColor": activeColor,
          "appSecondaryColor": SecondaryColor,
          "sideMenu": true,
          "initApp": true
        });


        //dispatch(addAuth(dt.authToken));

        //update page related settings like menu , menu data , breadcrumbs , current page etc.,
        updatePage({
          rawMenu: dt['menu'],
          convertedMenu: groupJsonByKey(dt['menu'], "module"),
        });



        if (activeColor != null & SecondaryColor != null) {
          console.log(activeColor);
          ChangeStyle('--fis-primary', activeColor);
          ChangeStyle('--fis-secondary', SecondaryColor);
          ChangeStyle('--fis-info', "#" + ("00A4B6"));
          ChangeStyle('--fis-warning', "#" + ("F5AD2A"));
          ChangeStyle('--fis-success', "#" + ("077e8b"));
          ChangeStyle('--fis-danger', "#" + ("FF7512"));


          //convert styles to match the header,fontcolor , hover and active classes

          var PrimaryTextColor = findTextColor("#" + activeColor);
          var secondaryTextColor = findTextColor("#" + SecondaryColor);
          var calculatedActiveColor = tinycolor("#" + activeColor).lighten(40).toHexString();


          ChangeStyle('--fis-primary-dark', tinycolor("#" + activeColor).darken(10).toHexString());
          ChangeStyle('--fis-secondary-dark', tinycolor("#" + SecondaryColor).darken(10).toHexString());


          ChangeStyle('--fis-active-color', calculatedActiveColor);
          ChangeStyle('--fis-header-secondary-text-color', secondaryTextColor);
          ChangeStyle('--fis-header-primary-text-color', PrimaryTextColor);
          //  ChangeStyle('--fis-header-secondary-text-color',secondaryTextColor);

        }

        if (false) {
          navigate("/firstTimeLogin")
        } else {
          navigate("/home");
        }

      } else {
        console.warn("error processing");
      }


    });
  };


  return (
    <>


      <div className="p-10">
        <div className="">

        </div>

        {/* 
        <Row>
          <Col sm={12} md={12} lg={12}>
            <Timeline
              mode={'left'}
              items={[
                {
                  label: '2015-09-01',
                  children: <b>hello</b>,
                },
                {
                  label: '2015-09-01 09:12:11',
                  children: 'Solve initial network problems',
                },
                {
                  children: 'Technical testing',
                },
                {
                  label: '2015-09-01 09:12:11',
                  children: 'Network problems being solved',
                },
              ]}
            />
          </Col>
        </Row> */}

        <Row>
          <Col span={12} offset={6}>
            <div className="card">
              <div className="">
                <Row>

                  <Col flex={1} className="hidden-sm align-content-center" >
                    <div
                      className="login-bg"
                      style={{
                        background: "url(" + loginBg + ") no-repeat",

                        "-webkit-background-size": "cover",
                        "-moz-background-size": "cover",
                        "-o-background-size": "cover",
                        "background-size": "cover",
                      }}
                    ></div>
                  </Col>

                  <Col>
                    <div className="container">
                      <img src={logo} className="header-logo" alt="app logo" />
                      <h3 className="pl-20 fis-secondary">Login</h3>
                      <Row gutter={16} wrap={true} >
                        <Col flex={1}>


                          <>
                            <div className="mb-3">
                              <label htmlFor="exampleInputEmail1" className="form-label">
                                Email address
                              </label>
                              <input
                                type="email"
                                className="form-control"
                                id="exampleInputEmail1"
                                aria-describedby="emailHelp"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                              />
                              <div id="emailHelp" className="form-text">
                                We'll never share your email with anyone else.
                              </div>
                            </div>
                            <div className="mb-3">
                              <label htmlFor="exampleInputPassword1" className="form-label">
                                Password
                              </label>
                              <input
                                type="password"
                                className="form-control"
                                id="exampleInputPassword1"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                              />
                            </div>
                            <div className="login-button p-10">
                              <button
                                type="button"
                                onClick={doLogin}
                                className="btn btn-outline btn-fis-primary width-100"
                              >
                                LOGIN
                              </button>
                            </div>
                          </>
                        </Col>
                      </Row>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Col>
        </Row>
      </div >
    </>
  );
}

export default Login;
