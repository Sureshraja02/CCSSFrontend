import Layout from "../main";

function Home() {
  return (
    <>
      <Layout>
      </Layout>
    </>
  );
}

export default Home;
