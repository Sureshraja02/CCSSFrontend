import axios from "axios";
import { API_URL, BACKEND_URL,MNRL_BACKEND_URL, ENCRYPT_ON_TRANSIT, HTTP_HEADERS } from "../config";
import {
  GenerateSecretKey,
  decodeSnowFlakeID,
  decrypt,
  encrypt,
  generateHmac,
  generateSnowFlakeID,
} from "../utilites/crypto";
import { addNotification } from "../redux/notifySlice";

let store;
export const injectStore = (_store) => {
  store = _store;
};

var BackendAPI = axios.create({
  headers: {
    requestid: crypto.randomUUID(),
    "Access-Control-Expose-Headers": "requestid,authorization",
    ...HTTP_HEADERS,
  },
  baseURL: BACKEND_URL,
  timeout: 50000,
});

var MnrlBackendAPI = axios.create({
  headers: {
    requestid: crypto.randomUUID(),
    "Access-Control-Expose-Headers": "requestid,authorization",
    ...HTTP_HEADERS,
  },
  baseURL: MNRL_BACKEND_URL,
  timeout: 50000,
});

BackendAPI.interceptors.request.use(
  async function (config) {
    // in case need to do any modifications in the request data.
    if (config.data === undefined) config.data = {};


    const authToken = store.getState().auth.authToken;
    if (authToken != "" && authToken != undefined)
      config.headers["Authorization"] = 'Bearer ' + authToken;


    if (ENCRYPT_ON_TRANSIT) {
      //handle encryption

      const [p, g, ka] = GenerateSecretKey();

      const [id, salt] = generateSnowFlakeID(p, g);

      config.headers["requestid"] = id;


      console.debug(config);
      console.debug(p, g, ka, id, salt);
      //yet to work.
      const encryptedString = await encrypt(config.data, ka, salt);

      if (encryptedString != null && encryptedString != undefined) {
        //form a standard bean
        var data = {
          request: encryptedString,
          hmac: await generateHmac(encryptedString, ka),
        };

        config.data = data;
      }
    }

    // console.warn(store.getState());

    return config;
  },
  function (error) {
    console.warn("Error in request" + error);
    return Promise.reject(error);
  }
);

MnrlBackendAPI.interceptors.response.use(
  async function (response) {
    // incase need to decrpt or do any alterations in response data
    //decryption process have to find salt and p to get ka

    if (ENCRYPT_ON_TRANSIT) {

      const data = response.data;

      const requestId = response.headers.requestid;

      const [P, salt] = decodeSnowFlakeID(requestId);

      const [p, g, ka] = GenerateSecretKey(P);

      const hmac = await generateHmac(data.response, ka);
      if (hmac === data.hmac) {
        const decrypted = await decrypt(data.response, ka, salt);
        var responsedata = {};
        if (typeof decrypted === "string" || decrypted instanceof String) {
          responsedata = JSON.parse(decrypted);
        } else {
          responsedata = decrypted;
        }
        console.debug(responsedata);
        response.data = responsedata;
      }
    }
    return response;
  },
  function (err) {
    console.warn("error" + err);
    switch (err.response.status) {
      case 503:
        break;
      default:
        break;
    }

    return Promise.reject(err);
  }
);


MnrlBackendAPI.interceptors.request.use(
  async function (config) {
    // in case need to do any modifications in the request data.
    if (config.data === undefined) config.data = {};


    const authToken = store.getState().auth.authToken;
    if (authToken != "" && authToken != undefined)
      config.headers["Authorization"] = 'Bearer ' + authToken;


    if (ENCRYPT_ON_TRANSIT) {
      //handle encryption

      const [p, g, ka] = GenerateSecretKey();

      const [id, salt] = generateSnowFlakeID(p, g);

      config.headers["requestid"] = id;


      console.debug(config);
      console.debug(p, g, ka, id, salt);
      //yet to work.
      const encryptedString = await encrypt(config.data, ka, salt);

      if (encryptedString != null && encryptedString != undefined) {
        //form a standard bean
        var data = {
          request: encryptedString,
          hmac: await generateHmac(encryptedString, ka),
        };

        config.data = data;
      }
    }

    // console.warn(store.getState());

    return config;
  },
  function (error) {
    console.warn("Error in request" + error);
    return Promise.reject(error);
  }
);

MnrlBackendAPI.interceptors.response.use(
  async function (response) {
    // incase need to decrpt or do any alterations in response data
    //decryption process have to find salt and p to get ka

    if (ENCRYPT_ON_TRANSIT) {

      const data = response.data;

      const requestId = response.headers.requestid;

      const [P, salt] = decodeSnowFlakeID(requestId);

      const [p, g, ka] = GenerateSecretKey(P);

      const hmac = await generateHmac(data.response, ka);
      if (hmac === data.hmac) {
        const decrypted = await decrypt(data.response, ka, salt);
        var responsedata = {};
        if (typeof decrypted === "string" || decrypted instanceof String) {
          responsedata = JSON.parse(decrypted);
        } else {
          responsedata = decrypted;
        }
        console.debug(responsedata);
        response.data = responsedata;
      }
    }
    return response;
  },
  function (err) {
    console.warn("error" + err);
    switch (err.response.status) {
      case 503:
        break;
      default:
        break;
    }

    return Promise.reject(err);
  }
);


const api = {
  get: async (url, params) => {
    try {
      const response = await BackendAPI.get(url.trim(), { params });
      console.debug(response.data);
      if (typeof (response.data) == 'object') {
        if ("error" in response.data) {
          console.warn("got error in api");
          store.dispatch(
            addNotification({
              id: Math.random(),
              type: "error",
              title: response.data.error,
              desc: response.data.cause,
            })
          );
          throw new Error(response.data.error);
        } else {
          return response.data;
        }
      } if (typeof (response.data) == 'string') {

        return response;

      }
      else {

        store.dispatch(
          addNotification({
            id: Math.random(),
            type: "error",
            title: "CODE 001",
            desc: "Error Receving response please contact administrator",
          })
        );

        throw new Error('Error');
      }
    } catch (error) {
      console.error("GET Request Failed:" + error);
      throw error;
    }
  },
  post: async (url, data) => {
    try {
      const response = await BackendAPI.post(url.trim(), JSON.stringify(data));

      if (typeof (response.data) == 'object') {
        if ("error" in response.data) {
          console.warn("got error in api");
          store.dispatch(
            addNotification({
              id: Math.random(),
              type: "error",
              title: response.data.error,
              desc: response.data.cause,
            })
          );
          throw new Error(response.data.error);
        } else {
          return response.data;
        }
      } if (typeof (response.data) == 'string') {

        return response;

      } else {

        store.dispatch(
          addNotification({
            id: Math.random(),
            type: "error",
            title: "CODE 001",
            desc: "Error Receving response please contact administrator",
          })
        );
        throw new Error('Error');
      }
    } catch (error) {
      console.error("Post Request failed :" + error);
      throw error;
    }
  },
  newapi: async (url, params) => {
    try {
      const response = await BackendAPI.get(url.trim(), { params });
      console.debug("-Newapi-" + response);
      return response.data;

    } catch (error) {
      console.error("GET Request Failed:" + error);
      throw error;
    }
  },
   getmnrl: async (url, params) => {
    try {
      const response = await MnrlBackendAPI.get(url.trim(), { params });
      console.debug(response.data);
      if (typeof (response.data) == 'object') {
        if ("error" in response.data) {
          console.warn("got error in api");
          store.dispatch(
            addNotification({
              id: Math.random(),
              type: "error",
              title: response.data.error,
              desc: response.data.cause,
            })
          );
          throw new Error(response.data.error);
        } else {
          return response.data;
        }
      } if (typeof (response.data) == 'string') {

        return response;

      }
      else {

        store.dispatch(
          addNotification({
            id: Math.random(),
            type: "error",
            title: "CODE 001",
            desc: "Error Receving response please contact administrator",
          })
        );

        throw new Error('Error');
      }
    } catch (error) {
      console.error("GET Request Failed:" + error);
      throw error;
    }
  },
};
export default api;
