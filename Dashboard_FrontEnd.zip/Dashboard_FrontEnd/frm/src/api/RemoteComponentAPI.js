import React from "react";
import packages from "../utilites/packages";
import { API_URL, HTTP_HEADERS } from "../config";
import axios from "axios";

function getParsedModule(code, moduleName, packages) {
  const _this = Object.create(packages);
  function require(name) {
    if (!(name in _this) && moduleName === name) {
      let module = { exports: {} };
      _this[name] = () => module;
      let wrapper = Function("require, exports, module", code);
      wrapper(require, module.exports, module);
    } else if (!(name in _this)) {
      throw `Module '${name}' not found`;
    }
    return _this[name]().exports;
  }

  return require(moduleName);
}

export async function fetchComponent(id) {
  console.log(id);
  try {
    const text = await axios({
      method: "GET",
      url: `${API_URL}/${id}.js?time=${Date.now()}`,
    }).then((a) => {
      if (!a.status == 200) {
        throw new Error("Network response was not ok");
      }
      return a.data;
    });
    return { default: getParsedModule(text, id, packages) };
  } catch (error) {

    console.warn(error);
    return {
      default() {
        return <div>Failed to Render</div>;
      },
    };
  }
}

export async function fetchJson(id) {
  try {
    const text = await axios({
      method: "GET",
      url: `${API_URL}/${id}.json?time=${Date.now()}`,
    }).then((a) => {
      if (!a.status == 200) {
        throw new Error("Network response was not ok");
      }
      return a;
    });
  } catch (error) {
    console.warn(error);
    return {
      default() {
        return <div>Failed to download json</div>;
      },
    };
  }
}
