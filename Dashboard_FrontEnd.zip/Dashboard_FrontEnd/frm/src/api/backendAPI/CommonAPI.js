import { hash } from "../../utilites/crypto";
import api from "../BackendAPI";
import axiosApi from "../baseAPI";

const CommonAPI = {
  Login(username, password) {
    return api.get(
      "/app/rest/v1.0/service/login/" + username + "/" + hash(password),
      {}
    );

    // return axiosApi({
    //   method: "get",
    //   url: `/LoginResponse.json`,
    // })
  },

  changePassword(username, newpassword, oldpassword) {
    return api.post("/app/rest/v1.0/service/changepassword", {
      newpassword: hash(newpassword),
      oldpassword: hash(oldpassword),
      userId: username,
    });
  },
};

export { CommonAPI };
