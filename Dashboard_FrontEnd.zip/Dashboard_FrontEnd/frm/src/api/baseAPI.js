import axios from "axios";
import { API_URL, HTTP_HEADERS } from "../config";

var axiosApi = axios.create({
  headers: {
    Authorization: sessionStorage.getItem("sessionToken"),
    ...HTTP_HEADERS,
  },
  baseURL: API_URL,
});

axiosApi.interceptors.request.use(
  function (config) {
    // in case need to do any modifications in the request data.
    config.headers = HTTP_HEADERS;
    //    config.withCredentials = true;
    return config;
  },
  function (error) {
    console.warn("Error in request" + error);
    return Promise.reject(error);
  }
);

axiosApi.interceptors.response.use(
  function (response) {
    // incase need to decrpt or do any alterations in response data
    return response;
  },
  function (err) {
    console.warn("error" + err);
    switch (err.response.status) {
      case 503:
        break;
      default:
        break;
    }

    return Promise.reject(err);
  }
);

export default axiosApi;
