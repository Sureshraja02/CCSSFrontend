module.exports = {
devtool : '#eval-source-map',
publicPath: '/ngpdev/rms',
}
