/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_COMPLAINTS_DETAILS")
@Entity
public class Ccss_Complaint_Details {

	@Column(name = "CREATE_DATE_TIME")
	private LocalDateTime createDateTime;

	@Id
	@Column(name = "ID")
	private String Id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Column(name = "SUB_CATEGORY")
	private String subCategory;

	@Column(name = "USER_ID")
	private String userId;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "FREEZED_ACCOUNT")
	private String freezedAccount;

	@Column(name = "UPDATE_DATE_TIME")
	private LocalDateTime updateDateTime;

	@Column(name = "REMARKS")
	private String remarks;

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFreezedAccount() {
		return freezedAccount;
	}

	public void setFreezedAccount(String freezedAccount) {
		this.freezedAccount = freezedAccount;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}
