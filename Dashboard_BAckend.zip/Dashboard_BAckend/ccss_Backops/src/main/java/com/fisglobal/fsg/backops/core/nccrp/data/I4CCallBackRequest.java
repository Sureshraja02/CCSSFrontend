/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.math.BigDecimal;

/**
 * @author e5745290
 *
 */
public class I4CCallBackRequest {
	
	private Integer sNo;

	private String acctNo;

	private String mobileNo;

	private String transactionId;

	private String acknowledgementNo;

	private String jobId;

	private String fromDate;

	private String toDate;

	private String isdCode;

	private String transactionType;

	private String status;

	private BigDecimal amount;

	private String remarks;

	private String validDate;

	private String txnRefNo;

	private String channel;

	private String MerchantId;

	private String terminalId;

	private String atmId;

	private String tranId;

	private String beneName;

	private String BeneRemiAcctNum;

	private String BeneRemiIfsc;

	private String BeneRemiBank;

	private String TransactionTimeHH24MI;

	private String atmPlace;

	private String atmBranch;

	private String fraud_Fg;

	private String fraudStatus;

	private BigDecimal fraudAmountBalance;

	private BigDecimal remainingDisputeBalance;

	private BigDecimal disputeBalance;

	private String complaintRrn;

	private String txnType;

	private String txn_Type_Id;

	private String beneBankCode;
	
	private String complaintDate;

	/**
	 * @return the acctNo
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * @param acctNo the acctNo to set
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}

	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the isdCode
	 */
	public String getIsdCode() {
		return isdCode;
	}

	/**
	 * @param isdCode the isdCode to set
	 */
	public void setIsdCode(String isdCode) {
		this.isdCode = isdCode;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the validDate
	 */
	public String getValidDate() {
		return validDate;
	}

	/**
	 * @param validDate the validDate to set
	 */
	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}

	/**
	 * @return the txnRefNo
	 */
	public String getTxnRefNo() {
		return txnRefNo;
	}

	/**
	 * @param txnRefNo the txnRefNo to set
	 */
	public void setTxnRefNo(String txnRefNo) {
		this.txnRefNo = txnRefNo;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the merchantId
	 */
	public String getMerchantId() {
		return MerchantId;
	}

	/**
	 * @param merchantId the merchantId to set
	 */
	public void setMerchantId(String merchantId) {
		MerchantId = merchantId;
	}

	/**
	 * @return the terminalId
	 */
	public String getTerminalId() {
		return terminalId;
	}

	/**
	 * @param terminalId the terminalId to set
	 */
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	/**
	 * @return the atmId
	 */
	public String getAtmId() {
		return atmId;
	}

	/**
	 * @param atmId the atmId to set
	 */
	public void setAtmId(String atmId) {
		this.atmId = atmId;
	}

	/**
	 * @return the tranId
	 */
	public String getTranId() {
		return tranId;
	}

	/**
	 * @param tranId the tranId to set
	 */
	public void setTranId(String tranId) {
		this.tranId = tranId;
	}

	/**
	 * @return the beneName
	 */
	public String getBeneName() {
		return beneName;
	}

	/**
	 * @param beneName the beneName to set
	 */
	public void setBeneName(String beneName) {
		this.beneName = beneName;
	}

	/**
	 * @return the beneRemiAcctNum
	 */
	public String getBeneRemiAcctNum() {
		return BeneRemiAcctNum;
	}

	/**
	 * @param beneRemiAcctNum the beneRemiAcctNum to set
	 */
	public void setBeneRemiAcctNum(String beneRemiAcctNum) {
		BeneRemiAcctNum = beneRemiAcctNum;
	}

	/**
	 * @return the beneRemiIfsc
	 */
	public String getBeneRemiIfsc() {
		return BeneRemiIfsc;
	}

	/**
	 * @param beneRemiIfsc the beneRemiIfsc to set
	 */
	public void setBeneRemiIfsc(String beneRemiIfsc) {
		BeneRemiIfsc = beneRemiIfsc;
	}

	/**
	 * @return the beneRemiBank
	 */
	public String getBeneRemiBank() {
		return BeneRemiBank;
	}

	/**
	 * @param beneRemiBank the beneRemiBank to set
	 */
	public void setBeneRemiBank(String beneRemiBank) {
		BeneRemiBank = beneRemiBank;
	}

	/**
	 * @return the transactionTimeHH24MI
	 */
	public String getTransactionTimeHH24MI() {
		return TransactionTimeHH24MI;
	}

	/**
	 * @param transactionTimeHH24MI the transactionTimeHH24MI to set
	 */
	public void setTransactionTimeHH24MI(String transactionTimeHH24MI) {
		TransactionTimeHH24MI = transactionTimeHH24MI;
	}

	/**
	 * @return the atmPlace
	 */
	public String getAtmPlace() {
		return atmPlace;
	}

	/**
	 * @param atmPlace the atmPlace to set
	 */
	public void setAtmPlace(String atmPlace) {
		this.atmPlace = atmPlace;
	}

	/**
	 * @return the atmBranch
	 */
	public String getAtmBranch() {
		return atmBranch;
	}

	/**
	 * @param atmBranch the atmBranch to set
	 */
	public void setAtmBranch(String atmBranch) {
		this.atmBranch = atmBranch;
	}

	/**
	 * @return the fraud_Fg
	 */
	public String getFraud_Fg() {
		return fraud_Fg;
	}

	/**
	 * @param fraud_Fg the fraud_Fg to set
	 */
	public void setFraud_Fg(String fraud_Fg) {
		this.fraud_Fg = fraud_Fg;
	}

	/**
	 * @return the fraudStatus
	 */
	public String getFraudStatus() {
		return fraudStatus;
	}

	/**
	 * @param fraudStatus the fraudStatus to set
	 */
	public void setFraudStatus(String fraudStatus) {
		this.fraudStatus = fraudStatus;
	}

	/**
	 * @return the fraudAmountBalance
	 */
	public BigDecimal getFraudAmountBalance() {
		return fraudAmountBalance;
	}

	/**
	 * @param fraudAmountBalance the fraudAmountBalance to set
	 */
	public void setFraudAmountBalance(BigDecimal fraudAmountBalance) {
		this.fraudAmountBalance = fraudAmountBalance;
	}

	/**
	 * @return the remainingDisputeBalance
	 */
	public BigDecimal getRemainingDisputeBalance() {
		return remainingDisputeBalance;
	}

	/**
	 * @param remainingDisputeBalance the remainingDisputeBalance to set
	 */
	public void setRemainingDisputeBalance(BigDecimal remainingDisputeBalance) {
		this.remainingDisputeBalance = remainingDisputeBalance;
	}

	/**
	 * @return the disputeBalance
	 */
	public BigDecimal getDisputeBalance() {
		return disputeBalance;
	}

	/**
	 * @param disputeBalance the disputeBalance to set
	 */
	public void setDisputeBalance(BigDecimal disputeBalance) {
		this.disputeBalance = disputeBalance;
	}

	/**
	 * @return the complaintRrn
	 */
	public String getComplaintRrn() {
		return complaintRrn;
	}

	/**
	 * @param complaintRrn the complaintRrn to set
	 */
	public void setComplaintRrn(String complaintRrn) {
		this.complaintRrn = complaintRrn;
	}

	/**
	 * @return the txnType
	 */
	public String getTxnType() {
		return txnType;
	}

	/**
	 * @param txnType the txnType to set
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return the txn_Type_Id
	 */
	public String getTxn_Type_Id() {
		return txn_Type_Id;
	}

	/**
	 * @param txn_Type_Id the txn_Type_Id to set
	 */
	public void setTxn_Type_Id(String txn_Type_Id) {
		this.txn_Type_Id = txn_Type_Id;
	}

	/**
	 * @return the beneBankCode
	 */
	public String getBeneBankCode() {
		return beneBankCode;
	}

	/**
	 * @param beneBankCode the beneBankCode to set
	 */
	public void setBeneBankCode(String beneBankCode) {
		this.beneBankCode = beneBankCode;
	}

	/**
	 * @return the sNo
	 */
	public Integer getsNo() {
		return sNo;
	}

	/**
	 * @param sNo the sNo to set
	 */
	public void setsNo(Integer sNo) {
		this.sNo = sNo;
	}

	/**
	 * @return the complaintDate
	 */
	public String getComplaintDate() {
		return complaintDate;
	}

	/**
	 * @param complaintDate the complaintDate to set
	 */
	public void setComplaintDate(String complaintDate) {
		this.complaintDate = complaintDate;
	}
	
	

}
