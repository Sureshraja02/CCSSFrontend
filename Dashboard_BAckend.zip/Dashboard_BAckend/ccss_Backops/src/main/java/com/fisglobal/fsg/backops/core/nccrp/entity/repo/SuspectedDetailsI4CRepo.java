package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.SuspectDetails_I4C_DAO;

public interface SuspectedDetailsI4CRepo extends JpaRepository<SuspectDetails_I4C_DAO, String> {

	
}
