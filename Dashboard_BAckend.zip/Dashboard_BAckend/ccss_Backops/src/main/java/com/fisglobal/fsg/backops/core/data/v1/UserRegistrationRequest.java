package com.fisglobal.fsg.backops.core.data.v1;

import org.springframework.stereotype.Component;

@Component
public class UserRegistrationRequest {

	private String userID;
	private String userName; 
}
