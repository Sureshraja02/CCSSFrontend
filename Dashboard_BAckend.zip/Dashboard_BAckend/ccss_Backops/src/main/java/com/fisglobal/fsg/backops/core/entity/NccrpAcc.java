package com.fisglobal.fsg.backops.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "NCCRPACC")
@Entity

public class NccrpAcc {

	@Column(name = "ACCOUTTYPE")
	private String accountType;

	@Id
	@Column(name = "ACCOUNTNO")
	private String accountNo;

	@Column(name = "CURRENTAMOUNT")
	private String currentAmt;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "ACCOUNTSTATUS")
	private String accstatus;

	public String getAccstatus() {
		return accstatus;
	}

	public void setAccstatus(String accstatus) {
		this.accstatus = accstatus;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getCurrentAmt() {
		return currentAmt;
	}

	public void setCurrentAmt(String currentAmt) {
		this.currentAmt = currentAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
