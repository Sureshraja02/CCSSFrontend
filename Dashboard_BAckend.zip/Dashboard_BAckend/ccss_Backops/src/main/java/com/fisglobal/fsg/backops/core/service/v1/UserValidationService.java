package com.fisglobal.fsg.backops.core.service.v1;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.Error;
import com.fisglobal.fsg.backops.core.common.ErrorDetails;
import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.data.v1.InstitutionData;
import com.fisglobal.fsg.backops.core.data.v1.UserRequest;
import com.fisglobal.fsg.backops.core.entity.repo.RMSErrorRepo;

@Service
public class UserValidationService {

	@Inject
	private RMSErrorRepo errorRepo;

	public ErrorDetails validateData(UserRequest request) {
		ErrorDetails errorDetails = new ErrorDetails();
		List<Error> errorList = new ArrayList<Error>();

		if (StringUtils.isBlank(request.getEmail())) {
			errorList.add(
					new Error(RMSConstants.emailCode, errorRepo.findById(RMSConstants.emailCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(request.getGroupId())) {

			
//			errorList.add(new Error(RMSConstants.groupIdCode,
//					errorRepo.findById(RMSConstants.groupIdCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(request.getMobileNo())) {
			errorList.add(new Error(RMSConstants.mobileNoCode,
					errorRepo.findById(RMSConstants.mobileNoCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(request.getPassword())) {
			errorList.add(new Error(RMSConstants.passwordCode,
					errorRepo.findById(RMSConstants.passwordCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(request.getUserName())) {
			errorList.add(new Error(RMSConstants.userNameCode,
					errorRepo.findById(RMSConstants.userNameCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(request.getUserType())) {
			errorList.add(new Error(RMSConstants.userTypeCode,
					errorRepo.findById(RMSConstants.userTypeCode).get().getErrorDesc()));
		}
		
		if (StringUtils.isBlank(request.getInstid())) {
			errorList.add(new Error(RMSConstants.instidCode,
					errorRepo.findById(RMSConstants.instidCode).get().getErrorDesc()));
		}

		errorDetails.setErrorList(errorList);

		return errorDetails;

	}

}
