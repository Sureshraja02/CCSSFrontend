package com.fisglobal.fsg.backops.core.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.JwtService;
import com.fisglobal.fsg.backops.core.service.v1.UserAuthService;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(JwtAuthFilter.class);

	@Autowired
	private JwtService jwtService;

	@Autowired
	UserAuthService us;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		LOGGER.info("URL[{}] AuthToken[{}] Method[{}]", ((HttpServletRequest) request).getRequestURL().toString(),request.getHeader("Authorization"),request.getMethod());
		String url = ((HttpServletRequest) request).getRequestURL().toString();

		if (url.contains("login")) {
			filterChain.doFilter(request, response);
		} else if (url.contains("swagger")) {
			filterChain.doFilter(request, response);
		}else if (url.contains("api-docs")) {
			filterChain.doFilter(request, response);
		}else if("OPTIONS".equals(request.getMethod())) {
			filterChain.doFilter(request, response);
			
		}else if (url.contains("dashboard")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpsuspectedChain")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpTransactionHistory")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpAccountDetails")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpdemographicView")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpdemographicAccountInfo")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("nccrpComplaintHistory")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("fetch")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("app/rest")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("/api/files/upload")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("/app/rest/v1.0/preparedownloadfile")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("/app/rest/v1.0/download")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("/app/rest/v1.0/ifsccodesearch")) {
			filterChain.doFilter(request, response);
			
		}
		else if (url.contains("/app/rest/v1.0")) {
			filterChain.doFilter(request, response);
			
		}
		
		
		
		
		
		
		
		else {

			String authHeader = request.getHeader("Authorization");
			String token = null;
			String userid = null;
			if (authHeader != null && authHeader.startsWith("Bearer ")) {
				token = authHeader.substring(7);
				try {
					userid = jwtService.extractUsername(token);
				}catch(Exception e) {
					LOGGER.info("Unable to Extract Token");
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					response.setContentType("message/http");
					response.getWriter().println("Authentication Required.");
					response.getWriter().flush();
				}
				
				LOGGER.info("UserId[{}] Token[{}]",userid,SecurityContextHolder.getContext().getAuthentication());
				
				//if (userid != null && SecurityContextHolder.getContext().getAuthentication() == null) {
				if (userid != null) {
					UserDetails userDetails = us.loadUserById(userid);
					LOGGER.info("UserID[{}] DBID[{}]",userid,userDetails.getUsername());
					if (jwtService.validateToken(token, userDetails)) {
						UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
								userDetails, null, userDetails.getAuthorities());
						authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
						SecurityContextHolder.getContext().setAuthentication(authenticationToken);
						LOGGER.info("SecurityContextHolder [{}]",SecurityContextHolder.getContext().getAuthentication());
						filterChain.doFilter(request, response);
					}else {
						LOGGER.info("Authentication Required [{}] [{}]",userid,SecurityContextHolder.getContext().getAuthentication());
						response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						response.setContentType("message/http");
						response.getWriter().println("Authentication Required.");
						response.getWriter().flush();
						return;
					}

				}
			} else {
				LOGGER.info("Unauthorized Access");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.setContentType("message/http");
				response.getWriter().println("Unauthorized Access");
				response.getWriter().flush();
				return;
			}

		}

	}

	public boolean isValidToken(String jwtToken) {

		String token = null;
		String userid = null;
		if (jwtToken != null && jwtToken.startsWith("Bearer ")) {
			token = jwtToken.substring(7);
			userid = jwtService.extractUsername(token);
		} else {
			return false;
		}

		if (userid != null) {
			UserDetails userDetails = us.loadUserById(userid);
			if (jwtService.validateToken(token, userDetails)) {
				return true;
			}

		}
		return false;

	}

	public String getUserNamefromToken(String jwtToken) {
		String token = null;
		if (jwtToken != null && jwtToken.startsWith("Bearer ")) {
			token = jwtToken.substring(7);
		} else {
			token = jwtToken;
		}

		return token != null ? jwtService.extractUsername(token) : null;

	}
}
