package com.fisglobal.fsg.backops.core.common;

import java.util.List;

public class GrpRequestList {

	private String groupName;

	private String groupId;

	private List<GroupBean> grpList;

	public List<GroupBean> getGrpList() {
		return grpList;
	}

	public void setGrpList(List<GroupBean> grpList) {
		this.grpList = grpList;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	@Override
	public String toString() {
		return "GrpRequestList [groupName=" + groupName + ", groupId=" + groupId + ", grpList=" + grpList.toString() + "]";
	}

}
