package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.RMS_Rule;
import com.fisglobal.fsg.backops.core.entity.User_Master;

public interface RMS_Rule_Repo extends PagingAndSortingRepository<RMS_Rule,String> {
	
	@Query(value = "SELECT * FROM RMS_RULE_TABLE WHERE EVENTDATA =?1 and EVENTTYPE=?2", nativeQuery = true)
	List<RMS_Rule> getRuleData(String eventName,String eventType);
	
	@Query(value = "UPDATE RMS_RULE_TABLE SET ENVIROMENT=?2 WHERE RULE_ID=?1", nativeQuery = true)
	RMS_Rule updateEnviroment(String ruleId,String enviroment);

}
