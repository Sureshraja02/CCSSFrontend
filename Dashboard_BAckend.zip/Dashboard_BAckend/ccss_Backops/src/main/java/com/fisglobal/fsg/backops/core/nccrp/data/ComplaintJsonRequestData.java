/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class ComplaintJsonRequestData {

	private String i4CRequestJsonRequest;

	/**
	 * @return the i4CRequestJsonRequest
	 */
	public String getI4CRequestJsonRequest() {
		return i4CRequestJsonRequest;
	}

	/**
	 * @param i4cRequestJsonRequest the i4CRequestJsonRequest to set
	 */
	public void setI4CRequestJsonRequest(String i4cRequestJsonRequest) {
		i4CRequestJsonRequest = i4cRequestJsonRequest;
	}

	
	
	
	
	
}
