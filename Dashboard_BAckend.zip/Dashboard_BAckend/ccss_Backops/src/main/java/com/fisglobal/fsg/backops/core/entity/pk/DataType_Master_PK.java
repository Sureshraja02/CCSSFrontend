package com.fisglobal.fsg.backops.core.entity.pk;

import java.io.Serializable;

import javax.persistence.Basic;

public class DataType_Master_PK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Basic
	private String idx;

	@Basic
	private String dataTypeCode;

	@Basic
	private String allowedCondition;

	public String getIdx() {
		return idx;
	}

	public void setIdx(String idx) {
		this.idx = idx;
	}

	public String getDataTypeCode() {
		return dataTypeCode;
	}

	public void setDataTypeCode(String dataTypeCode) {
		this.dataTypeCode = dataTypeCode;
	}

	public String getAllowedCondition() {
		return allowedCondition;
	}

	public void setAllowedCondition(String allowedCondition) {
		this.allowedCondition = allowedCondition;
	}

}
