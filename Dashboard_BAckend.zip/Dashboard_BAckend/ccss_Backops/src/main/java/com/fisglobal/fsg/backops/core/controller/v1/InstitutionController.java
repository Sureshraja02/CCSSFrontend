package com.fisglobal.fsg.backops.core.controller.v1;

import java.lang.reflect.InvocationTargetException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.ErrorDetails;
import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.data.v1.InstitutionData;
import com.fisglobal.fsg.backops.core.entity.Instid_Master;
import com.fisglobal.fsg.backops.core.entity.repo.InstitutionRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.AuthTokenService;
import com.fisglobal.fsg.backops.core.service.v1.CustomUserDetails;
import com.fisglobal.fsg.backops.core.service.v1.InstitutionValidationService;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;

import io.swagger.annotations.Api;

@Api(tags = "Institution Registration", description = "Provides Institution Addition, Modify Functionality")
@RestController
@RequestMapping(value = "/app/rest/v1.0/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class InstitutionController {

	private static final Logger LOGGER = LoggerFactory.getLogger(InstitutionController.class);

	@Inject
	private PaginationService paginationService;

	@Inject
	private InstitutionRepo institutionRepo;

	@Inject
	private InstitutionValidationService validationService;

	@Inject
	private AuthTokenService tokenService;

	@RequestMapping(value = "fetch/instlist", method = RequestMethod.GET)
	public ResponseEntity<?> getinstList(@RequestHeader(value = "requestid") String reqId) throws Exception {
		return new ResponseEntity<>(institutionRepo.findAll(), HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/instlist/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getinstitutionList(@RequestHeader(value = "requestid") String reqId,
			@PathVariable int pageSize, @PathVariable int page) throws Exception {

		Page<Instid_Master> pageResult = paginationService.getInstitutionList(pageSize, page);

		if (!pageResult.hasContent()) {
			throw new RMSException(RMSConstants.INVALID_REQUEST_CODE, RMSConstants.INVALID_REQUEST_MSG);
		}

		return new ResponseEntity<>(pageResult, HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/institution/{institutionId}", method = RequestMethod.GET)
	public ResponseEntity<?> getinstitutionDetails(@RequestHeader(value = "requestid") String reqId,
			@PathVariable Long institutionId) throws Exception {

		Optional<Instid_Master> institution = institutionRepo.findById(institutionId);

		if (!institution.isPresent()) {
			throw new RMSException(RMSConstants.INVALID_REQUEST_CODE, RMSConstants.INVALID_REQUEST_MSG);
		}

		return new ResponseEntity<>(institution.get(), HttpStatus.OK);
	}

	@RequestMapping(value = "save/instid", method = RequestMethod.POST)
	public ResponseEntity<?> getinstitutionDetails(@RequestHeader(value = "requestid") String reqId,
			@RequestBody InstitutionData instRequest, Principal principal)
			throws IllegalAccessException, InvocationTargetException, RMSException {
		RMSResponse response = new RMSResponse();

		LOGGER.info("Request Data [{}]", instRequest.toString());

		ErrorDetails erroDetails = validationService.validateInstitutionData(instRequest);

		if (erroDetails.getErrorList().size() > 0) {
			return new ResponseEntity<>(erroDetails, HttpStatus.OK);
		}

		LOGGER.info("UserName [{}]", SecurityContextHolder.getContext().getAuthentication());

		String userId = tokenService.getUserName();

		if (StringUtils.isBlank(userId)) {
			throw new RMSException(RMSConstants.INVALID_REQUEST_CODE, RMSConstants.INVALID_REQUEST_MSG);
		}

		Optional<Instid_Master> institution = institutionRepo.findById(instRequest.getOrgID());

		if (institution.isPresent()) {
			institution.get().setAppDangerColor(instRequest.getAppDangerColor());
			institution.get().setAppInfoColor(instRequest.getAppInfoColor());
			institution.get().setAppSuccessColor(instRequest.getAppSuccessColor());
			institution.get().setAppWarningColor(instRequest.getAppWarningColor());
			institution.get().setCreatedUserID(userId);
			institution.get().setModifiedDT(LocalDateTime.now());
			// institution.get().setOrgLogo(instRequest.getOrgLogo());
			institution.get().setOrgName(instRequest.getOrgName());
			institution.get().setOrgPrimaryColor(instRequest.getOrgPrimaryColor());
			institution.get().setOrgSecondaryColor(instRequest.getOrgSecondaryColor());

			institutionRepo.save(institution.get());

		} else {

			instRequest.setCreatedUserID(userId);
			Instid_Master instMaster = new Instid_Master();
			BeanUtils.copyProperties(instMaster, instRequest);
			instMaster.setInsertedDT(LocalDateTime.now());
			instMaster.setModifiedDT(LocalDateTime.now());

			institutionRepo.save(instMaster);
		}

		response.setErrorCode(RMSConstants.SUCCESS_CODE);
		response.setStatus(RMSConstants.SUCCESS_MSG);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
