/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.data.DashboardInterface;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;

/**
 * @author e5745290
 *
 */
public interface Ccss_CftdRepo extends JpaRepository<Ccss_Cftd_Details, String> {

	boolean existsByRrn(String rrn);

	Ccss_Cftd_Details findByRrn(String rrn);
	
	
	Ccss_Cftd_Details findTopByOrderByEntryDateDesc();

	Page<Ccss_Cftd_Details> findByAcknowledgementNoContaining(String acknowledgementNo,
			org.springframework.data.domain.Pageable paging);

	@Query(value = "select * from CCSS_CFTD", nativeQuery = true)
	List<Ccss_Cftd_Details> allDetails();

	@Query(value = "select * from ccss_cftd where COMPLAINT_DATE >= ?1 and COMPLAINT_DATE <= ?2 and RECORD_TYPE=?3", nativeQuery = true)
	List<Ccss_Cftd_Details> getCftd_DetailsByFromandToDate(String fromDate, String toDate, String downloadType,
			String status);
	
	@Query(value = "select ACCOUNT_NO AS accountNo,HOLD_VALUE AS holdValue,DISPUTED_AMOUNT AS disputedAmount from ccss_acc_amt_hold_status where HOLD_DATE  >?1 and  HOLD_DATE <= ?2", nativeQuery = true)
	List<DashboardInterface> getTransactionHold(Date startDate, Date endDate);
	
	@Query(value = "select ACCOUNT_NO AS accountNo,MOBILE_NUMBER AS mobileNo,ACKNOWLEDGEMENT_NO AS acknowlegementNo,COMPLAINT_RRN AS complaintRrn from CCSS_CIF_DIGITAL_CHNL_BLOCK where ENTRYDATE  >?1 and  ENTRYDATE <= ?2", nativeQuery = true)
	List<DashboardInterface> getDigitalBlock(Date startDate, Date endDate);
	
	@Query(value = "select ACCOUNT_NO AS accountNo,MOBILE_NUMBER AS mobileNo,ACKNOWLEDGEMENT_NO AS acknowlegementNo,COMPLAINT_RRN AS complaintRrn from CCSS_CIF_DIGITAL_CHNL_BLOCK where ENTRYDATE  >?1 and  ENTRYDATE <= ?2 and RESP_CODE='200' and RESP_MSG='ERR 4945 00 CUSTOMER ALREADY BLOCKED'", nativeQuery = true)
	List<DashboardInterface> getError(Date startDate, Date endDate);
	
	@Query(value = "SELECT \r\n" + 

			"    TRUNC(entry_date) AS Complaint_date,\r\n" + 

			"    COUNT(1) AS total_ack,\r\n" + 

			"    SUM(CASE WHEN status IS NOT NULL AND FULLY_SUCCESS = 1 AND status = '00' THEN 1 ELSE 0 END) AS fully_success,\r\n" + 

			"    SUM(CASE WHEN PARTIAL_SUCCESS = 1 THEN 1 ELSE 0 END) AS partial_success,\r\n" + 

			"    SUM(CASE WHEN FULLY_FAILED = 1 THEN 1 ELSE 0 END) AS fully_failed\r\n" + 

			"FROM CCSS_REQ_AUDIT\r\n" + 

			"WHERE status != '15'\r\n" + 

			"  AND ENTRY_DATE >?1 and ENTRY_DATE <= ?2 \r\n" + 

			"GROUP BY TRUNC(entry_date)\r\n" + 

			"ORDER BY TRUNC(entry_date)", nativeQuery = true)

	List<DashboardInterface> getOverallcount(Date startDate, Date endDate);
 

	@Query(value = "select * from ccss_cftd where ACKNOWLEDGEMENT_NO = ?1 or PAYER_ACCOUNT_NUMBER=?2 or RRN=?3", nativeQuery = true)
	List<Ccss_Cftd_Details> getCftd_Details(String ackNo, String AccountNo, String rrn);

	@Query(value = "select * from CCSS_CFTD where ACKNOWLEDGEMENT_NO=?1 and RRN=?2", nativeQuery = true)
	Ccss_Cftd_Details getAckNoDetailsrrnAndAck(String ackNo, String rrn);

	@Query(value = "select * from CCSS_CFTD where ACKNOWLEDGEMENT_NO=?1 and JOBID=?2", nativeQuery = true)
	Ccss_Cftd_Details getAckNoAndJobIdDetails(String ackNo, String jobId);

	List<Ccss_Cftd_Details> findByEntryDateBetween(Date startDate, Date endDate);

	@Query(value = "SELECT count(acknowledgement_no) as ackNo from (\r\n"
			+ "select acknowledgement_no,sum(SUCCESS) as SUCCESS,sum(BENE_NOT_FOUND) as FAILED from (\r\n"
			+ "select \r\n" + "acknowledgement_no, \r\n"
			+ "case when FRAUD_STATUS='00' then 1 else 0 end as success, \r\n"
			+ "case when FRAUD_STATUS!='00' then 1 else 0 end as BENE_NOT_FOUND\r\n"
			+ "from ccss_cbs_trans_fraud_details where update_date > ?1 and update_date <= ?2 )x group by acknowledgement_no\r\n"
			+ "\r\n" + ")  ackno where ackno.SUCCESS > 0 and ackno.FAILED = 0", nativeQuery = true)
	Long readSuccessTxnCount(Date startDate, Date endDate);

	@Query(value = "SELECT count(acknowledgement_no) as ackNo from (\r\n"
			+ "select acknowledgement_no,sum(SUCCESS) as SUCCESS, sum(BENE_NOT_FOUND) as FAILED from (\r\n"
			+ "select \r\n" + "acknowledgement_no, \r\n"
			+ "case when FRAUD_STATUS='00' then 1 else 0 end as success, \r\n"
			+ "case when FRAUD_STATUS!='00' then 1 else 0 end as BENE_NOT_FOUND\r\n"
			+ "from ccss_cbs_trans_fraud_details where update_date > ?1 and update_date <= ?2 )x group by acknowledgement_no\r\n"
			+ "\r\n" + ")  ackno where ackno.SUCCESS = 0 and ackno.FAILED > 0", nativeQuery = true)
	Long readFailedTxnCount(Date startDate, Date endDate);

	@Query(value = "SELECT count(acknowledgement_no) as ackNo from (\r\n"
			+ "select acknowledgement_no,sum(SUCCESS) as SUCCESS, sum(BENE_NOT_FOUND) as FAILED from (\r\n"
			+ "select \r\n" + "acknowledgement_no, \r\n"
			+ "case when FRAUD_STATUS='00' then 1 else 0 end as success, \r\n"
			+ "case when FRAUD_STATUS!='00' then 1 else 0 end as BENE_NOT_FOUND\r\n"
			+ "from ccss_cbs_trans_fraud_details where update_date > ?1 and update_date <= ?2 )x group by acknowledgement_no\r\n"
			+ "\r\n" + ")  ackno where ackno.SUCCESS > 0 and ackno.FAILED > 0", nativeQuery = true)
	Long readPartialTxnCount(Date startDate, Date endDate);

	@Query(countQuery = "SELECT count(acknowledgement_no) from ccss_cbs_trans_fraud_details where acknowledgement_no like %?1% group by acknowledgement_no", value = "select 1,acknowledgement_no,sum(SUCCESS) as SUCCESS, sum(BENE_NOT_FOUND) as BENE_NOT_FOUND, sum(INVALID_RRN) as INVALID_RRN\r\n"
			+ ", sum(INVALID_INPUT_PRAM) as INVALID_INPUT_PRAM, sum(INVALID_LENGTH) as INVALID_LENGTH, sum(API_FAILED) as API_FAILED from (\r\n"
			+ "select \r\n" + "acknowledgement_no, \r\n"
			+ "case when FRAUD_STATUS='00' then 1 else 0 end as success, \r\n"
			+ "case when FRAUD_STATUS='01' then 1 else 0 end as BENE_NOT_FOUND, \r\n"
			+ "case when FRAUD_STATUS='02' then 1 else 0 end as INVALID_RRN, \r\n"
			+ "case when FRAUD_STATUS='14' then 1 else 0 end as INVALID_INPUT_PRAM, \r\n"
			+ "case when FRAUD_STATUS='32' then 1 else 0 end as INVALID_LENGTH, \r\n"
			+ "case when FRAUD_STATUS='99' then 1 else 0 end as API_FAILED\r\n"
			+ "from ccss_cbs_trans_fraud_details where acknowledgement_no like %?1% )x group by acknowledgement_no", nativeQuery = true)
	Page<HashMap<String, Object>> getTxnStatusbypagingwithLike(String ackNo,
			org.springframework.data.domain.Pageable paging);

	@Query(countQuery = "SELECT count(acknowledgement_no) from ccss_cbs_trans_fraud_details group by acknowledgement_no", value = "select 1,acknowledgement_no,sum(SUCCESS) as SUCCESS, sum(BENE_NOT_FOUND) as BENE_NOT_FOUND, sum(INVALID_RRN) as INVALID_RRN\r\n"
			+ ", sum(INVALID_INPUT_PRAM) as INVALID_INPUT_PRAM, sum(INVALID_LENGTH) as INVALID_LENGTH, sum(API_FAILED) as API_FAILED from (\r\n"
			+ "select \r\n" + "acknowledgement_no, \r\n"
			+ "case when FRAUD_STATUS='00' then 1 else 0 end as success, \r\n"
			+ "case when FRAUD_STATUS='01' then 1 else 0 end as BENE_NOT_FOUND, \r\n"
			+ "case when FRAUD_STATUS='02' then 1 else 0 end as INVALID_RRN, \r\n"
			+ "case when FRAUD_STATUS='14' then 1 else 0 end as INVALID_INPUT_PRAM, \r\n"
			+ "case when FRAUD_STATUS='32' then 1 else 0 end as INVALID_LENGTH, \r\n"
			+ "case when FRAUD_STATUS='99' then 1 else 0 end as API_FAILED\r\n"
			+ "from ccss_cbs_trans_fraud_details )x group by acknowledgement_no", nativeQuery = true)
	Page<HashMap<String, Object>> getTxnStatusbypaging(org.springframework.data.domain.Pageable paging);

	
	@Query(value = "select sum(fully_procees) as fully_procees,sum(partial_processed) as partial_processed,sum(fully_failed) as fully_failed from (\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO, COMPLIANT_RRN, ACCOUNT_NO,\r\n" + 
			"case when (sum(success)>=0 and sum(failure)=0) then 1 else 0 end as fully_procees, \r\n" + 
			"case when ((sum(success)>0)  and sum(failure)>0) then 1 else 0 end as partial_processed, \r\n" + 
			"case when ((sum(success)=0)  and sum(failure)>=0) then 1 else 0 end as fully_failed \r\n" + 
			"from(\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN, ACCOUNT_NO,\r\n" + 
			"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
			"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
			"from ccss_cbs_trans_fraud_details where update_date >?1 and update_date <= ?2)x group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN, ACCOUNT_NO )y \r\n" + 
			"", nativeQuery = true)
	DashboardInterface readTotalFraudRecord(Date startDate, Date endDate);
	
	
	
	@Query(value = "select count(1) as recordNoFound from ccss_cftd\r\n" + 
			"where\r\n" + 
			"ENTRY_DATE   > ?1 and ENTRY_DATE <= ?2 \r\n" + 
			"and\r\n" + 
			"rrn not in(select COMPLIANT_RRN from ccss_cbs_trans_fraud_details where CREATED_TIME  > ?1 and CREATED_TIME <= ?2 )\r\n" + 
			"", nativeQuery = true)
	DashboardInterface readTotalrecordNoTFound(Date startDate, Date endDate);
	
	
	@Query(countQuery = "select count(ACKNOWLEDGEMENT_NO) from (\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
			"case when (sum(success)>0 and sum(failure)=0) then 1 else 0 end as fully_procees\r\n" + 
			"from(\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
			"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
			"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
			"from ccss_cbs_trans_fraud_details where CREATED_TIME  > '24-MAR-25 12.00.00.000000 AM' and CREATED_TIME <= '25-MAR-25 12.00.00.000000 AM')x  group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO)y where fully_procees>0\r\n" + 
			"", value = "select ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO from (\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
			"case when (sum(success)>0 and sum(failure)=0) then 1 else 0 end as fully_procees\r\n" + 
			"from(\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
			"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
			"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
			"from ccss_cbs_trans_fraud_details where CREATED_TIME  > ?1 and CREATED_TIME <= ?2)x  group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO)y where fully_procees>0\r\n" + 
			"", nativeQuery = true)
	Page<HashMap<String, Object>> getFullyProcessedRecord(Date startDate, Date endDate,org.springframework.data.domain.Pageable paging);



	@Query(countQuery = "select count(ACKNOWLEDGEMENT_NO) from (\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
			"case when ((sum(success)>0)  and sum(failure)>0) then 1 else 0 end as partial_processed\r\n" + 
			"from(\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
			"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
			"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
			"from ccss_cbs_trans_fraud_details where  CREATED_TIME  > ?1 and CREATED_TIME <= ?2)x group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO )y where partial_processed>0\r\n" + 
			"\r\n" + 
			"", value = "select ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO from (\r\n" + 
					"select \r\n" + 
					"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
					"case when ((sum(success)>0)  and sum(failure)>0) then 1 else 0 end as partial_processed\r\n" + 
					"from(\r\n" + 
					"select \r\n" + 
					"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
					"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
					"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
					"from ccss_cbs_trans_fraud_details where  CREATED_TIME  > ?1 and CREATED_TIME <= ?2)x group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO )y where partial_processed>0\r\n" + 
					"\r\n" + 
					"", nativeQuery = true)
	Page<HashMap<String, Object>> getPartiallyProcessedRecord(Date startDate, Date endDate,org.springframework.data.domain.Pageable paging);

	
	@Query(countQuery = "select count(ACKNOWLEDGEMENT_NO) from (\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
			"case when ((sum(success)>0)  and sum(failure)>0) then 1 else 0 end as partial_processed\r\n" + 
			"from(\r\n" + 
			"select \r\n" + 
			"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
			"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
			"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
			"from ccss_cbs_trans_fraud_details where  CREATED_TIME  > ?1 and CREATED_TIME <= ?2)x group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO )y where partial_processed>0\r\n" + 
			"\r\n" + 
			"", value = "select ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO from (\r\n" + 
					"select \r\n" + 
					"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO, \r\n" + 
					"case when ((sum(success)=0)  and sum(failure)>0) then 1 else 0 end as fully_failed \r\n" + 
					"from(\r\n" + 
					"select \r\n" + 
					"ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO,\r\n" + 
					"case when FRAUD_STATUS ='00' then 1 else 0 END as success,\r\n" + 
					"case when FRAUD_STATUS <> '00' then 1 else 0 END as failure\r\n" + 
					"from ccss_cbs_trans_fraud_details where CREATED_TIME  > ?1 and CREATED_TIME <= ?2)x group by ACKNOWLEDGEMENT_NO,COMPLIANT_RRN,ACCOUNT_NO)y  where fully_failed>0\r\n" + 
					"\r\n" + 
					"", nativeQuery = true)
	Page<HashMap<String, Object>> getFullyFailedRecord(Date startDate, Date endDate,org.springframework.data.domain.Pageable paging);

	
	@Query(value = "select sum(count(1)) as totalAsk from ccss_cftd where ENTRY_DATE >?1 and ENTRY_DATE <= ?2 group by ACKNOWLEDGEMENT_NO,PAYER_ACCOUNT_NUMBER,rrn", nativeQuery = true)
	Long getTotalAckReceived(Date startDate, Date endDate);
	
	@Query(value = "select ENTRY_DATE from CCSS_CFTD   order by ENTRY_DATE desc FETCH FIRST 1 ROWS ONLY", nativeQuery = true)
	Date getLastTxnDate();
	
	

			@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as ackNumber, PAYER_ACCOUNT_NUMBER as accountNo,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as txnDate,TRANSACTION_TIME as txnTime ,status as status,STATUS_REASON as reason from CCSS_REQ_AUDIT where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('60001','60002','60003') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
			List<DashboardInterface> fileDownloadFullyFailedTechnicalAll(Date startDate, Date endDate);
	
			@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as ackNumber, PAYER_ACCOUNT_NUMBER as accountNo,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as txnDate,TRANSACTION_TIME as txnTime ,status as status,STATUS_REASON as reason from CCSS_REQ_AUDIT where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('40001','50003','50006','70008','70009','2') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
			List<DashboardInterface> fileDownloadFullyFailedBusinessAll(Date startDate, Date endDate);
	
			
			@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as ackNumber, PAYER_ACCOUNT_NUMBER as accountNo,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as txnDate,TRANSACTION_TIME as txnTime ,status as status,STATUS_REASON as reason from CCSS_REQ_AUDIT where (PARTIAL_SUCCESS=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('60001','60002','60003') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
			List<DashboardInterface> fileDownloadPartialSuccessTechnicalAll(Date startDate, Date endDate);
	
			
			@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as ackNumber, PAYER_ACCOUNT_NUMBER as accountNo,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as txnDate,TRANSACTION_TIME as txnTime ,status as status,STATUS_REASON as reason from CCSS_REQ_AUDIT where (PARTIAL_SUCCESS=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('40001','50003','50006','70008','70009','2') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
			List<DashboardInterface> fileDownloadPartialSucessBusinessAll(Date startDate, Date endDate);
	
			@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as ackNumber, PAYER_ACCOUNT_NUMBER as accountNo,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as txnDate,TRANSACTION_TIME as txnTime ,status as status,STATUS_REASON as reason from CCSS_REQ_AUDIT where (FULLY_SUCCESS=1 and status ='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2   order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
			List<DashboardInterface> fileDownloadSuccessAll(Date startDate, Date endDate);
	

}
