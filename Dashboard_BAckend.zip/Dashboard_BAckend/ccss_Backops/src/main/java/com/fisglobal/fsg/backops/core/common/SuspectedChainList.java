package com.fisglobal.fsg.backops.core.common;

import java.util.List;

public class SuspectedChainList {

	private List<SuspectedChain> chain;

	public List<SuspectedChain> getChain() {
		return chain;
	}

	public void setChain(List<SuspectedChain> chain) {
		this.chain = chain;
	}

}
