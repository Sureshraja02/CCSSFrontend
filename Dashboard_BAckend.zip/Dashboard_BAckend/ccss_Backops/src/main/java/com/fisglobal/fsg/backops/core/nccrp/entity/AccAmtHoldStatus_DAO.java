package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_ACC_AMT_HOLD_STATUS")
@Entity
@DynamicUpdate
public class AccAmtHoldStatus_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "IDHOLDSEQ", sequenceName = "IDHOLDSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACCOUNT_NO")
	private String accountNo;
	@Column(name = "HOLD_REASON")
	private String holdReason;
	@Column(name = "HOLD_VALUE")
	private BigDecimal holdValue;
	@Column(name = "PROMO_NO")
	private String promoNo;
	@Column(name = "ROLL_OVER_TO_OVERDUE")
	private String rollOverToOverDue;
	@Column(name = "STATUS_CODE")
	private String statusCode;
	@Column(name = "STATUS_DESC")
	private String statusDesc;
	@Column(name = "JOURNAL_NUMBER")
	private String journalNumber;
	@Column(name = "HOLD_SET_DATE")
	private String holdSetDate;
	@Column(name = "EXCEP_CODE")
	private String excepCode;
	@Column(name = "EXCEP_TEXT")
	private String excepText;
	@Column(name = "EXCEP_META_DATA")
	private String excepMetaData;
	@Column(name = "ENTRY_DATE")
	private LocalDateTime entryDate;
	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "HOLD_DATE", columnDefinition = "TIMESTAMP")
	private Date holdDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getHoldReason() {
		return holdReason;
	}

	public void setHoldReason(String holdReason) {
		this.holdReason = holdReason;
	}

	public BigDecimal getHoldValue() {
		return holdValue;
	}

	public void setHoldValue(BigDecimal holdValue) {
		this.holdValue = holdValue;
	}

	public String getPromoNo() {
		return promoNo;
	}

	public void setPromoNo(String promoNo) {
		this.promoNo = promoNo;
	}

	public String getRollOverToOverDue() {
		return rollOverToOverDue;
	}

	public void setRollOverToOverDue(String rollOverToOverDue) {
		this.rollOverToOverDue = rollOverToOverDue;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getJournalNumber() {
		return journalNumber;
	}

	public void setJournalNumber(String journalNumber) {
		this.journalNumber = journalNumber;
	}

	public String getHoldSetDate() {
		return holdSetDate;
	}

	public void setHoldSetDate(String holdSetDate) {
		this.holdSetDate = holdSetDate;
	}

	public String getExcepCode() {
		return excepCode;
	}

	public void setExcepCode(String excepCode) {
		this.excepCode = excepCode;
	}

	public String getExcepText() {
		return excepText;
	}

	public void setExcepText(String excepText) {
		this.excepText = excepText;
	}

	public String getExcepMetaData() {
		return excepMetaData;
	}

	public void setExcepMetaData(String excepMetaData) {
		this.excepMetaData = excepMetaData;
	}

	public LocalDateTime getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(LocalDateTime entryDate) {
		this.entryDate = entryDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public Date getHoldDate() {
		return holdDate;
	}

	public void setHoldDate(Date holdDate) {
		this.holdDate = holdDate;
	}

}
