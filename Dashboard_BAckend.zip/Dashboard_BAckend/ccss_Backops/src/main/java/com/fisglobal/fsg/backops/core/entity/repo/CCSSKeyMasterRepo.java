package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.entity.CCSSKeyMaster_DAO;

public interface CCSSKeyMasterRepo extends JpaRepository<CCSSKeyMaster_DAO, String> {
}
