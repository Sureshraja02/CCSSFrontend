/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.fileupload;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.BeneficiaryData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadRequestData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadResponseData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.service.FileDownloadService;
/**
 * @author e5745290
 *
 */

@RestController
@RequestMapping("/app/rest/v1.0")
@CrossOrigin
public class FileDownloadController {

	 private final Path fileStorageLocation = Paths.get("download").toAbsolutePath().normalize();
	 
	 private final Path fileStorageLocation_report = Paths.get("download").toAbsolutePath().normalize();
	 
	 private static final Logger LOGGER = LoggerFactory.getLogger(FileDownloadController.class);
	

	 
	 @Autowired
	 FileDownloadService fileDownloadService;
	
	@RequestMapping(value = "/preparedownloadfile", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DownloadResponseData> preparedownloadfile(@RequestBody DownloadRequestData request)
			throws InvalidFormatException, IOException, ParseException {

			
			HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	        DownloadResponseData responseData =new DownloadResponseData();
	       if(request.getDownloadType()!=null && ("FILE".equals(request.getDownloadType()) || "API".equals(request.getDownloadType()))  )
	       {
	    	    responseData = fileDownloadService.fileDownload(request);  
	       }
	       else if(request.getDownloadType()!=null &&  "OVERALL".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadOverAll(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "TRANSACTION".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadTransaction(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "DIGITAL".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadDigital(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "ERROR".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadError(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "FAILED_TECH".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadFullyFailedTechnicalAll(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "FAILED_BUS".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadFullyFailedBusinessAll(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "PARTIAL_TECH".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadPartialSuccessTechnicalAll(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "PARTIAL_BUS".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadPartialSucessBusinessAll(request); 
	       }
	       else if(request.getDownloadType()!=null &&  "SUCCESS".equals(request.getDownloadType()))  
	       {
	    	    responseData = fileDownloadService.fileDownloadFullySuccessAll(request); 
	       }
	       
	       
	      
	        return new ResponseEntity<>(responseData, HttpStatus.OK);
	}
	 
	   @GetMapping("/download/{fileName}")
	 public ResponseEntity<Resource> download(@PathVariable String fileName) throws IOException {

		 Resource resource = loadFileAsResource(fileName);

	        return ResponseEntity.ok()
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
	                .body(resource);
	 }
	 
	 
	 public Resource loadFileAsResource(String fileName) {
	        try {
	            Path filePath = this.fileStorageLocation_report.resolve(fileName).normalize();
	            Resource resource = new UrlResource(filePath.toUri());
	            if (resource.exists()) {
	                return resource;
	            } else {
	                throw new RuntimeException("File not found " + fileName);
	            }
	        } catch (Exception ex) {
	            throw new RuntimeException("File not found " + fileName, ex);
	        }
	    }
			}


