/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

import com.fisglobal.fsg.backops.core.nccrp.entity.CcssCBSTransactionFraudDetails_DAO;

public class SuspectedChainResponseData {

	private List<SuspectedInterface> suspectedInterface;

	private List<CcssCBSTransactionFraudDetails_DAO> fraudDetails;

	private CcssCBSTransactionFraudDetails_DAO fraudDetail;

	/**
	 * @return the suspectedInterface
	 */
	public List<SuspectedInterface> getSuspectedInterface() {
		return suspectedInterface;
	}

	/**
	 * @param suspectedInterface the suspectedInterface to set
	 */
	public void setSuspectedInterface(List<SuspectedInterface> suspectedInterface) {
		this.suspectedInterface = suspectedInterface;
	}

	public List<CcssCBSTransactionFraudDetails_DAO> getFraudDetails() {
		return fraudDetails;
	}

	public void setFraudDetails(List<CcssCBSTransactionFraudDetails_DAO> fraudDetails) {
		this.fraudDetails = fraudDetails;
	}

	public CcssCBSTransactionFraudDetails_DAO getFraudDetail() {
		return fraudDetail;
	}

	public void setFraudDetail(CcssCBSTransactionFraudDetails_DAO fraudDetail) {
		this.fraudDetail = fraudDetail;
	}

}
