package com.fisglobal.fsg.backops.core.common;

public class RMSEvent {

	private String eventName;
	private String eventType;

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

}
