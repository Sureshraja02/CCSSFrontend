package com.fisglobal.fsg.backops.core.nccrp.service;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.StatusCount;
import com.fisglobal.fsg.backops.core.nccrp.data.DashBoardData;
import com.fisglobal.fsg.backops.core.nccrp.data.DashboardInterface;
import com.fisglobal.fsg.backops.core.nccrp.data.IfscCodeBankDetails;
import com.fisglobal.fsg.backops.core.nccrp.entity.AccAmtHoldStatus_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.CCSS_CIF_DigitalChannelBlock_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_BankCodes_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Callback_Ack_Resp_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.AccAmtHoldStatusRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CCSSBankCodesRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CCSSReqAuditRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssCallbackAckRespDetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_CIF_DigitalChannelBlock_DAORepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_CftdRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_Complaint_StatusRepo;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.service.FileDownloadService;

@Service
public class NccrpDashboardService {

	@Inject
	private Ccss_Complaint_StatusRepo ccss_Complaint_StatusRepo;

	@Inject
	private Ccss_CftdRepo ccss_CftdRepo;

	@Inject
	private CcssCallbackAckRespDetailsRepo ccssCallbackAckRespDetailsRepo;

	@Autowired
	AccAmtHoldStatusRepo amountHoldRepo;

	@Autowired
	Ccss_CIF_DigitalChannelBlock_DAORepo digitalChannelRepo;

	@Autowired
	CCSSReqAuditRepo cCSSReqAuditRepo;

	@Autowired
	FileDownloadService fileDownloadService;
	
	@Autowired
	CCSSBankCodesRepo cCSSBankCodesRepo;

	private final Path fileStorageLocation = Paths.get("Report_Download").toAbsolutePath().normalize();

	@SuppressWarnings("removal")
	public DashBoardData getDashboardDetails(String timeline) {

		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());

		DashBoardData dashBoardData = new DashBoardData();
		StatusCount statusCount = new StatusCount();

		Long readFullySuccessCount = cCSSReqAuditRepo.readFullySuccessCount(sd.getTime(), ed.getTime());

		Long readFullyFailedCount = cCSSReqAuditRepo.readFullyFailedCount(sd.getTime(), ed.getTime());

		Long readPartialSuccessCount = cCSSReqAuditRepo.readPartialSuccessCount(sd.getTime(), ed.getTime());

		// DashboardInterface readTotalFraudRecord=
		// ccss_CftdRepo.readTotalFraudRecord(sd.getTime(), ed.getTime());

		if (readFullySuccessCount != null) {
			dashBoardData.setNoOfackSucceeded(readFullySuccessCount);
		}
		if (readPartialSuccessCount != null) {

			dashBoardData.setNoOfackPartiallyCompleted(readPartialSuccessCount);
		}
		if (readFullyFailedCount != null) {

			dashBoardData.setNoOfackFailed(readFullyFailedCount);

		}

		List<Ccss_Cftd_Details> rList = ccss_CftdRepo.findByEntryDateBetween(sd.getTime(), ed.getTime());

		//Long noOfAck = rList.stream().map(Ccss_Cftd_Details::getAcknowledgementNo).distinct().count();

		// Long noOfAck=ccss_CftdRepo.getTotalAckReceived(sd.getTime(), ed.getTime());

		//Long noofTrans = rList.stream().map(Ccss_Cftd_Details::getAcknowledgementNo).count();

		Long noofHoldMade = rList.stream()
				.filter(cftd -> cftd.getHoldStatus() != null && cftd.getHoldStatus().equals("Y"))
				.map(Ccss_Cftd_Details::getPayerAccountNumber).distinct().count();

		BigDecimal sumamtDisputedAmt = rList.stream()
				// .filter(cftd -> cftd.getHoldStatus() != null &&
				// cftd.getHoldStatus().equals("Y"))
				.map(Ccss_Cftd_Details::getDisputedAmount).reduce(BigDecimal.ZERO, BigDecimal::add);

		/*List<Ccss_Callback_Ack_Resp_DAO> ackReponseList = ccssCallbackAckRespDetailsRepo
				.findByEntryDateTimeBetween(sd.getTime(), ed.getTime());

		Long noOfackProcessed = ackReponseList.stream()
				.filter(ack -> ack.getAckType() != null && ack.getAckType().equals("BANK"))
				.map(Ccss_Callback_Ack_Resp_DAO::getAcknowledgementNo).distinct().count();

		Long noOfackfullyProcessed = ackReponseList.stream()
				.filter(ack -> ack.getAckType() != null && ack.getAckType().equals("BANK")
						&& ack.getRespCode().equals("00"))
				.map(Ccss_Callback_Ack_Resp_DAO::getAcknowledgementNo).distinct().count();

		Long noOftxnProceeded = ackReponseList.stream()
				.filter(ack -> ack.getAckType() != null && ack.getAckType().equals("I4C"))
				.map(Ccss_Callback_Ack_Resp_DAO::getAcknowledgementNo).count();

*/
		List<AccAmtHoldStatus_DAO> amountList = amountHoldRepo.findByHoldDateBetween(sd.getTime(), ed.getTime());
		Long noOfAccountsHolded = amountList.stream().filter(hv -> hv.getAccountNo() != null)
				.map(AccAmtHoldStatus_DAO::getAccountNo).distinct().count();

		BigDecimal sumofHoldAmt = amountList.stream().filter(hv -> hv.getHoldValue() != null)
				.map(AccAmtHoldStatus_DAO::getHoldValue).reduce(BigDecimal.ZERO, BigDecimal::add);

		Map<String, Long> layersGroup = rList.stream()
				.collect(Collectors.groupingBy(Ccss_Cftd_Details::getLayer, Collectors.counting()));

		Map<String, Long> channelMap = rList.stream()
				.collect(Collectors.groupingBy(Ccss_Cftd_Details::getChannel, Collectors.counting()));

		List<CCSS_CIF_DigitalChannelBlock_DAO> digitalChannelList = digitalChannelRepo
				.findByEntryDateBetween(sd.getTime(), ed.getTime());

		Long digitalChannelCount = digitalChannelList.stream().map(CCSS_CIF_DigitalChannelBlock_DAO::getComplaintRRN)
				.count();

		//Long noOfackSuccess = ccss_CftdRepo.readSuccessTxnCount(sd.getTime(), ed.getTime());

		//Long noOfackFailed = ccss_CftdRepo.readFailedTxnCount(sd.getTime(), ed.getTime());

		//Long noofackPartiallyfailed = ccss_CftdRepo.readPartialTxnCount(sd.getTime(), ed.getTime());

		Long readTotalAckReceived = cCSSReqAuditRepo.readTotalAckReceived(sd.getTime(), ed.getTime());

		Long readTotalAckProcessed = cCSSReqAuditRepo.readTotalAckProcessed(sd.getTime(), ed.getTime());

		dashBoardData.setAmtOfHoldMade(sumofHoldAmt);
		dashBoardData.setNoOfAck(readTotalAckReceived);
		dashBoardData.setNoOfAckProcessed(readTotalAckProcessed);
		dashBoardData.setNoOfHoldMade(noofHoldMade);

		Long readTotalRRNCount = cCSSReqAuditRepo.readTotalRRNCount(sd.getTime(), ed.getTime());

		Long readTotalRRNProceedCount = cCSSReqAuditRepo.readTotalRRNProceedCount(sd.getTime(), ed.getTime());

		dashBoardData.setNoOftxn(readTotalRRNCount);
		dashBoardData.setNoOftxnProcessed(readTotalRRNProceedCount);
		/*
		 * dashBoardData.setNoOfackSucceeded(noOfackSuccess);
		 * dashBoardData.setNoOfackFailed(noOfackFailed);
		 * dashBoardData.setNoOfackPartiallyCompleted(noofackPartiallyfailed);
		 */
		dashBoardData.setAmtofDisputeMade(sumamtDisputedAmt);
		dashBoardData.setLayersMap(layersGroup);
		dashBoardData.setChannelMap(channelMap);
		dashBoardData.setNoOfAccountsHolded(noOfAccountsHolded);
		dashBoardData.setLastTxnDt(ccss_CftdRepo.findTopByOrderByEntryDateDesc().getEntryDate());
		//dashBoardData.setLastTxnDtAsString(ccss_CftdRepo.getLastTxnDate());
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
		String strDate = dateFormat.format(ccss_CftdRepo.getLastTxnDate());
		dashBoardData.setLastTxnDtAsString(strDate);
		dashBoardData.setDigitalBlockCount(digitalChannelCount);

//
//			float successPer = Math.round((ccss_CftdRepo.readSuccessTxnCount(sd.getTime(), ed.getTime())) * 100
//					/ (noOfackProcessed > 0 ? noOfackProcessed : 1));
//			float failPer = Math.round((ccss_CftdRepo.readFailedTxnCount(sd.getTime(), ed.getTime())) * 100
//					/ (noOfackProcessed > 0 ? noOfackProcessed : 1));
//			float challengePer = Math.round((ccss_CftdRepo.readPartialTxnCount(sd.getTime(), ed.getTime())) * 100
//					/ (noOfackProcessed > 0 ? noOfackProcessed : 1));
//

		double total = ((readFullySuccessCount != null && readFullySuccessCount > 0) ? readFullySuccessCount : 0)
				+ ((readFullyFailedCount != null && readFullyFailedCount > 0) ? readFullyFailedCount : 0)
				+ ((readPartialSuccessCount != null && readPartialSuccessCount > 0)  ? readPartialSuccessCount : 0);
		if (total > 0) {

			Long successCount = 0L;
			if(readFullySuccessCount != null && readFullySuccessCount > 0)
			{
				successCount = Math.round((readFullySuccessCount / total) * 100);
	
			}
			
			
			Long partiallyfailed =0L;
			if(readPartialSuccessCount != null && readPartialSuccessCount > 0)
			{
				 partiallyfailed = Math.round(((readPartialSuccessCount / total) * 100));
	
			}
			
			Long failed =0L;
			if(readFullyFailedCount != null && readFullyFailedCount > 0)
			{
				failed = Math.round(((readFullyFailedCount / total) * 100));
	
			}
			
			
			

			
				
			
			 

			statusCount.setSuccess(successCount);
			statusCount.setFailure(failed);
			statusCount.setPartialyCompleted(partiallyfailed);
			dashBoardData.setStatusCount(statusCount);
		}

		return dashBoardData;
	}

	public List<String> monthCalculation(List<Ccss_Cftd_Details> ccss_Cftd_Details, String year) {
		List<String> monthlyTxnCount = new ArrayList<String>();
		List<String> monthlyTxnDate = new ArrayList<String>();

		monthlyTxnDate.add("01");
		monthlyTxnDate.add("02");
		monthlyTxnDate.add("03");
		monthlyTxnDate.add("04");
		monthlyTxnDate.add("05");
		monthlyTxnDate.add("06");
		monthlyTxnDate.add("07");
		monthlyTxnDate.add("08");
		monthlyTxnDate.add("09");
		monthlyTxnDate.add("10");
		monthlyTxnDate.add("11");
		monthlyTxnDate.add("12");

		Long month1 = 0l;
		Long month2 = 0l;
		Long month3 = 0l;
		Long month4 = 0l;
		Long month5 = 0l;
		Long month6 = 0l;
		Long month7 = 0l;
		Long month8 = 0l;
		Long month9 = 0l;
		Long month10 = 0l;
		Long month11 = 0l;
		Long month12 = 0l;

		for (Ccss_Cftd_Details data : ccss_Cftd_Details) {
			if (data.getTransactionDate() != null) {
				String s = data.getTransactionDate();

				// taking small limit
				String[] arr = s.split("-");
				if (arr[0].equals(year)) {

					if ("01".equals(arr[1])) {
						month1 += 1L;
					} else if ("02".equals(arr[1])) {
						month2 += 1L;
					} else if ("03".equals(arr[1])) {
						month3 += 1L;
					} else if ("04".equals(arr[1])) {
						month4 += 1L;
					} else if ("05".equals(arr[1])) {
						month5 += 1L;
					} else if ("06".equals(arr[1])) {
						month6 += 1L;
					} else if ("07".equals(arr[1])) {
						month7 += 1L;
					} else if ("08".equals(arr[1])) {
						month8 += 1L;
					} else if ("09".equals(arr[1])) {
						month9 += 1L;
					} else if ("10".equals(arr[1])) {
						month10 += 1L;
					} else if ("11".equals(arr[1])) {
						month11 += 1L;
					} else if ("12".equals(arr[1])) {
						month12 += 1L;
					}
				}
			}
		}

		monthlyTxnCount.add(String.valueOf(month1));
		monthlyTxnCount.add(String.valueOf(month2));
		monthlyTxnCount.add(String.valueOf(month3));
		monthlyTxnCount.add(String.valueOf(month4));
		monthlyTxnCount.add(String.valueOf(month5));
		monthlyTxnCount.add(String.valueOf(month6));
		monthlyTxnCount.add(String.valueOf(month7));
		monthlyTxnCount.add(String.valueOf(month8));
		monthlyTxnCount.add(String.valueOf(month9));
		monthlyTxnCount.add(String.valueOf(month10));
		monthlyTxnCount.add(String.valueOf(month11));
		monthlyTxnCount.add(String.valueOf(month12));

		return monthlyTxnCount;
	}

	public String insertIfscCode(
			IfscCodeBankDetails requestData) {
		Ccss_BankCodes_DAO data=new Ccss_BankCodes_DAO();
		data.setBankCode(requestData.getBankCode());
		data.setBankIfscCode(requestData.getIfscCode());
		data.setBankName(requestData.getBankName());
		data.setBankType(requestData.getBankType());
		data.setUdapeDateTime(new Date(System.currentTimeMillis()));
		cCSSBankCodesRepo.save(data);
				return "Success";
	}
}
