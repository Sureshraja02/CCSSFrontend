package com.fisglobal.fsg.backops.core.controller.v1;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSEvent;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.common.RMSRuleCondition;
import com.fisglobal.fsg.backops.core.common.RMSRuleRequest;
import com.fisglobal.fsg.backops.core.common.RuleExpression;
import com.fisglobal.fsg.backops.core.entity.RMS_Rule;
import com.fisglobal.fsg.backops.core.entity.repo.RMS_Rule_Repo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;

import io.swagger.annotations.Api;

@Api(tags="Rule Management",description = "Provides Rules Addition, Modify Functionality")

@RestController
@RequestMapping("/api/rulewhiz/v1/")
public class RuleWhizController {

	@Inject
	private RMS_Rule_Repo ruleRepo;

	@Inject
	private PaginationService pageService;
	
	@RequestMapping(value = "rule/change/{enviroment}/{ruleid}", method = RequestMethod.GET)
	public ResponseEntity<?> changeRuleEnviroment(
			@RequestHeader(value = "requestid") String reqId,
			@PathVariable String ruleid,
			@PathVariable String enviroment) throws RMSException {
		
		
		RMS_Rule ruleDetails = ruleRepo.updateEnviroment(ruleid, enviroment);
		
		return new ResponseEntity<>(ruleDetails, HttpStatus.OK);
	}


	@RequestMapping(value = "list/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> listAllEvent(
			@RequestHeader(value = "requestid") String reqId,
			@PathVariable String pageSize, 
			@PathVariable String page) throws RMSException {
		Page<RMS_Rule> ruleList = pageService.getRuleList(Integer.parseInt(pageSize), Integer.parseInt(page));

		if (!ruleList.hasContent()) {
			throw new RMSException(RMSConstants.INVALID_CONFIG_CODE, RMSConstants.INVALID_CONFIG_MSG);
		}

		return new ResponseEntity<>(ruleList, HttpStatus.OK);
	}
	
	@GetMapping("listevent/{eventname}/{eventtype}")
	public ResponseEntity<?> listEvent(
			@PathVariable String eventname, 
			@PathVariable String eventtype) throws RMSException {
		
		List<RMS_Rule> ruleList = ruleRepo.getRuleData(eventname, eventtype);
		
		RMSRuleRequest request = new RMSRuleRequest();
		List<RMSEvent> eventlist = new ArrayList<RMSEvent>();
		
		for(int i=0;i<ruleList.size();i++) {
			RMSEvent event = new RMSEvent();
			event.setEventName(ruleList.get(i).getEventName());
			event.setEventType(ruleList.get(i).getEventType());
			eventlist.add(event);
		}
		
		List<RMSRuleCondition> ruleCondition = new ArrayList<RMSRuleCondition>();
		List<RuleExpression> ruleExpression = new ArrayList<RuleExpression>();
		
		request.setRuleName(ruleList.get(0).getDesc());
		
		return new ResponseEntity<>(ruleList, HttpStatus.OK);
	}

	@PostMapping("add")
	public ResponseEntity<?> postEvent(@RequestBody RMSRuleRequest request) {
		RMSResponse result = new RMSResponse();
		StringBuffer sb = new StringBuffer();
		int conditionSize = request.getRuleCondition().size();
		for (RMSRuleCondition rmsRuleCondition : request.getRuleCondition()) {
			int expressionSize = rmsRuleCondition.getRuleExpression().size();
			for (RuleExpression ruleExpression : rmsRuleCondition.getRuleExpression()) {
				if (ruleExpression.getRuleData1().startsWith("#")) {
					sb.append("$(RMS." + ruleExpression.getRuleData1().substring(1) + ")");
					sb.append(" ");
					sb.append(getOperationSymbol(ruleExpression.getOperation()));
					sb.append(" ");
					sb.append(ruleExpression.getValue());
				} else {
					sb.append("input." + ruleExpression.getRuleData1());
					sb.append(" ");
					sb.append(getOperationSymbol(ruleExpression.getOperation()));
					sb.append(" ");
					sb.append(ruleExpression.getValue());
				}

				if (expressionSize > 1) {
					sb.append(" ");
					sb.append(getOperationSymbol(ruleExpression.getJoinExpression()));
					sb.append(" ");
				}
			}
		}
		sb.setLength(sb.length() - 4);
		// System.out.println(sb.toString());

		for (int i = 0; i < request.getEvent().size(); i++) {
			RMS_Rule rule = new RMS_Rule();
			rule.setEventType(request.getEvent().get(i).getEventType());
			rule.setEventName(request.getEvent().get(i).getEventName());
			rule.setCondition(sb.toString());
			rule.setDesc(request.getRuleName());
			rule.setAction(request.getRuleAction());
			ruleRepo.save(rule);
		}

		// DecisionResult result = (DecisionResult)
		// ruleService.executeRules(decisionEngine, request, "IMPS");
		result.setErrorCode("00");
		result.setStatus("success");
		return ResponseEntity.ok(result);
	}

	private String getOperationSymbol(String operation) {
		String retVal = "";
		if ("GreaterThan or EqualTo".equals(operation)) {
			retVal = ">=";
		} else if ("AND".equals(operation)) {
			retVal = "&&";
		} else if ("OR".equals(operation)) {
			retVal = "||";
		} else if ("EqualTo".equals(operation)) {
			retVal = "==";
		} else if ("Greater Than".equals(operation)) {
			retVal = ">";
		}

		return retVal;
	}
}
