/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Trans_Details;

/**
 * @author e5745290
 *
 */
public class TransactionHistoryResponseData extends BaseResponseData{

	public List<Ccss_Trans_Details> ccss_Trans_Details;

	/**
	 * @return the ccss_Trans_Details
	 */
	public List<Ccss_Trans_Details> getCcss_Trans_Details() {
		return ccss_Trans_Details;
	}

	/**
	 * @param ccss_Trans_Details the ccss_Trans_Details to set
	 */
	public void setCcss_Trans_Details(List<Ccss_Trans_Details> ccss_Trans_Details) {
		this.ccss_Trans_Details = ccss_Trans_Details;
	}
	
	
	
	
}
