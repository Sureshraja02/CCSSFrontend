package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_SUSPECTED_REGISTRY")
@Entity
@DynamicUpdate
public class SuspectrRegistryDetails_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "SUSPTREGIDSEQ", sequenceName = "SUSPTREGIDSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACCOUNT_NUMBER")
	private String accountNo;
	@Column(name = "IFSC_CODE")
	private String ifscCode;
	@Column(name = "PCIN_NUMBER")
	private String cinNumber;
	@Column(name = "ACCOUNT_HOLDER_NAME")
	private String accountHolderName;
	
	@Column(name = "PAN_NUMBER_OF_COMPANY")
	private String panNoOfCompany;
	@Column(name = "PAN_NUMBER_OF_INDIVIDUAL")
	private String panNoOfIndividual;
	@Column(name = "EMAIL_ADDRESS_OF_SUSPECT")
	private String emailOfSuspect;
	@Column(name = "PHONE_NUMBER_OF_SUSPECT")
	private String phoneNoOfSuspect;
	@Column(name = "GST_NUMBER")
	private String gstNo;
	@Column(name = "UPI_HANDLE")
	private String upiHandle;
	@Column(name = "WEBSITE")
	private String website;
	@Column(name = "SOURCE")
	private String source;
	
	
	@Column(name = "SUSPECT_ADDRESS")
	private String suspectAddress;
	@Column(name = "DLNUMBER")
	private String dlNumber;
	@Column(name = "PASSPORT_NUMBER")
	private String passportNumber;
	@Column(name = "VOTER_ID")
	private String voterId;
	@Column(name = "NREGA_CARD_NO")
	private String nregaCardNo;
	@Column(name = "UPDATED_TIME")
	private Date updateTime;
	@Column(name = "OTHER_DOC_NUMBER")
	private String otherDocNumber;
	
	@Column(name = "OTHER_DOC_TYPE")
	private String otherDicType;
	@Column(name = "IPADDRESS")
	private String ipAddress;
	@Column(name = "PRESENT_DIRECTOR")
	private String presentDirector;
	@Column(name = "COUNTRY_CODE")
	private String countryCode;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ENTRYDATETIME", columnDefinition = "TIMESTAMP")
	private Date entryDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getCinNumber() {
		return cinNumber;
	}

	public void setCinNumber(String cinNumber) {
		this.cinNumber = cinNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getPanNoOfCompany() {
		return panNoOfCompany;
	}

	public void setPanNoOfCompany(String panNoOfCompany) {
		this.panNoOfCompany = panNoOfCompany;
	}

	public String getPanNoOfIndividual() {
		return panNoOfIndividual;
	}

	public void setPanNoOfIndividual(String panNoOfIndividual) {
		this.panNoOfIndividual = panNoOfIndividual;
	}

	public String getEmailOfSuspect() {
		return emailOfSuspect;
	}

	public void setEmailOfSuspect(String emailOfSuspect) {
		this.emailOfSuspect = emailOfSuspect;
	}

	public String getPhoneNoOfSuspect() {
		return phoneNoOfSuspect;
	}

	public void setPhoneNoOfSuspect(String phoneNoOfSuspect) {
		this.phoneNoOfSuspect = phoneNoOfSuspect;
	}

	public String getGstNo() {
		return gstNo;
	}

	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

	public String getUpiHandle() {
		return upiHandle;
	}

	public void setUpiHandle(String upiHandle) {
		this.upiHandle = upiHandle;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSuspectAddress() {
		return suspectAddress;
	}

	public void setSuspectAddress(String suspectAddress) {
		this.suspectAddress = suspectAddress;
	}

	public String getDlNumber() {
		return dlNumber;
	}

	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getVoterId() {
		return voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}

	public String getNregaCardNo() {
		return nregaCardNo;
	}

	public void setNregaCardNo(String nregaCardNo) {
		this.nregaCardNo = nregaCardNo;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getOtherDocNumber() {
		return otherDocNumber;
	}

	public void setOtherDocNumber(String otherDocNumber) {
		this.otherDocNumber = otherDocNumber;
	}

	public String getOtherDicType() {
		return otherDicType;
	}

	public void setOtherDicType(String otherDicType) {
		this.otherDicType = otherDicType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPresentDirector() {
		return presentDirector;
	}

	public void setPresentDirector(String presentDirector) {
		this.presentDirector = presentDirector;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	

}
