package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "CCSS_BANK_CODES")
@Entity
public class Ccss_BankCodes_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "BNKIDSEQ", sequenceName = "BNKIDSEQ", allocationSize = 1)
	private  String id;

	@Column(name = "BANK_CODE")
	public  String bankCode;

	@Column(name = "BANK_NAME_DESC")
	public  String bankName;

	@Column(name = "BANK_TYPE")
	public  String bankType;


	@Column(name = "BANK_IFSC_CODE")
	public String bankIfscCode;
	
	@Column(name = "UPDATE_DATE_TIME")
	public  Date udapeDateTime;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	

	public Date getUdapeDateTime() {
		return udapeDateTime;
	}

	public void setUdapeDateTime(Date udapeDateTime) {
		this.udapeDateTime = udapeDateTime;
	}

	public String getBankIfscCode() {
		return bankIfscCode;
	}

	public void setBankIfscCode(String bankIfscCode) {
		this.bankIfscCode = bankIfscCode;
	}
}
