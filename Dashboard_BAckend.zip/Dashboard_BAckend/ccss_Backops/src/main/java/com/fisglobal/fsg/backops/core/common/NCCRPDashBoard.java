
package com.fisglobal.fsg.backops.core.common;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CompliantsReceived",
    "FreezedAccounts",
    "TotalTxns",
    "TotalSuspeciousTxns",
    "TxnsCount",
    "statusCount",
    "Atm",
    "POS",
    "IB",
    "MB",
    "channelPercentage",
    "title",
    "values"
})
@Generated("jsonschema2pojo")
public class NCCRPDashBoard {

    @JsonProperty("CompliantsReceived")
    private String compliantsReceived;
    @JsonProperty("FreezedAccounts")
    private String freezedAccounts;
    @JsonProperty("TotalTxns")
    private String totalTxns;
    @JsonProperty("TotalSuspeciousTxns")
    private String totalSuspeciousTxns;
    @JsonProperty("TxnsCount")
    private TxnsCount txnsCount;
    @JsonProperty("statusCount")
    private StatusCount statusCount;
    @JsonProperty("Atm")
    private Atm atm;
    @JsonProperty("POS")
    private Pos pos;
    @JsonProperty("IB")
    private Ib ib;
    @JsonProperty("MB")
    private Mb mb;
    @JsonProperty("channelPercentage")
    private String channelPercentage;
    @JsonProperty("title")
    private String title;
    @JsonProperty("values")
    private Values values;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("CompliantsReceived")
    public String getCompliantsReceived() {
        return compliantsReceived;
    }

    @JsonProperty("CompliantsReceived")
    public void setCompliantsReceived(String compliantsReceived) {
        this.compliantsReceived = compliantsReceived;
    }

    @JsonProperty("FreezedAccounts")
    public String getFreezedAccounts() {
        return freezedAccounts;
    }

    @JsonProperty("FreezedAccounts")
    public void setFreezedAccounts(String freezedAccounts) {
        this.freezedAccounts = freezedAccounts;
    }

    @JsonProperty("TotalTxns")
    public String getTotalTxns() {
        return totalTxns;
    }

    @JsonProperty("TotalTxns")
    public void setTotalTxns(String totalTxns) {
        this.totalTxns = totalTxns;
    }

    @JsonProperty("TotalSuspeciousTxns")
    public String getTotalSuspeciousTxns() {
        return totalSuspeciousTxns;
    }

    @JsonProperty("TotalSuspeciousTxns")
    public void setTotalSuspeciousTxns(String totalSuspeciousTxns) {
        this.totalSuspeciousTxns = totalSuspeciousTxns;
    }

    @JsonProperty("TxnsCount")
    public TxnsCount getTxnsCount() {
        return txnsCount;
    }

    @JsonProperty("TxnsCount")
    public void setTxnsCount(TxnsCount txnsCount) {
        this.txnsCount = txnsCount;
    }

    @JsonProperty("statusCount")
    public StatusCount getStatusCount() {
        return statusCount;
    }

    @JsonProperty("statusCount")
    public void setStatusCount(StatusCount statusCount) {
        this.statusCount = statusCount;
    }

    @JsonProperty("Atm")
    public Atm getAtm() {
        return atm;
    }

    @JsonProperty("Atm")
    public void setAtm(Atm atm) {
        this.atm = atm;
    }

    @JsonProperty("POS")
    public Pos getPos() {
        return pos;
    }

    @JsonProperty("POS")
    public void setPos(Pos pos) {
        this.pos = pos;
    }

    @JsonProperty("IB")
    public Ib getIb() {
        return ib;
    }

    @JsonProperty("IB")
    public void setIb(Ib ib) {
        this.ib = ib;
    }

    @JsonProperty("MB")
    public Mb getMb() {
        return mb;
    }

    @JsonProperty("MB")
    public void setMb(Mb mb) {
        this.mb = mb;
    }

    @JsonProperty("channelPercentage")
    public String getChannelPercentage() {
        return channelPercentage;
    }

    @JsonProperty("channelPercentage")
    public void setChannelPercentage(String channelPercentage) {
        this.channelPercentage = channelPercentage;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("values")
    public Values getValues() {
        return values;
    }

    @JsonProperty("values")
    public void setValues(Values values) {
        this.values = values;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
