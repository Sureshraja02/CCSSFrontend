package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.entity.NccrpRegistration;

public interface NccrpRegRepo extends JpaRepository<NccrpRegistration, String> {

}
