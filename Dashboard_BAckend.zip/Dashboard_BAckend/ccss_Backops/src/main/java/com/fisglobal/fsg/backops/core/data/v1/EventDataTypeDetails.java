package com.fisglobal.fsg.backops.core.data.v1;

public class EventDataTypeDetails {

	private String dataTypeCode;

	private String dataTypeDesc;

	private String allowedCondition;

	public String getDataTypeCode() {
		return dataTypeCode;
	}

	public void setDataTypeCode(String dataTypeCode) {
		this.dataTypeCode = dataTypeCode;
	}

	public String getDataTypeDesc() {
		return dataTypeDesc;
	}

	public void setDataTypeDesc(String dataTypeDesc) {
		this.dataTypeDesc = dataTypeDesc;
	}

	public String getAllowedCondition() {
		return allowedCondition;
	}

	public void setAllowedCondition(String allowedCondition) {
		this.allowedCondition = allowedCondition;
	}

}
