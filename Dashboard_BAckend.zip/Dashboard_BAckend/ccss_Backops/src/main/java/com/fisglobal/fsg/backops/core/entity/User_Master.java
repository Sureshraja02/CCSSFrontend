package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

@Table(name = "USER_MASTER")
@Entity
@DynamicUpdate
public class User_Master implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "userseq")
	@SequenceGenerator(name = "userseq", sequenceName = "USERSEQ", allocationSize = 1)
	@Column(name = "USERID")
	private Long userID;

	@Column(name = "USERNAME")
	private String userName;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "USERTYPE")
	private String userType;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "PASSWORDDATE", columnDefinition = "TIMESTAMP")
	private LocalDateTime passwordDate;

	@Column(name = "GROUPID")
	private String groupID;

	@Column(name = "GROUPNAME")
	private String groupName;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "INSTID")
	private String instID;

	@Column(name = "MOBILENO")
	private String mobileNo;

	@Column(name = "CREATEUSERID")
	private String createUserID;

	@Column(name = "INSERTEDDATE")
	private LocalDateTime insertDate;

	@Column(name = "MODIFIEDDATE")
	private LocalDateTime modifiedDate;

	@Column(name = "FIRSTTIMELOGIN")
	private String isFirstTimeLogin;
	
	@Column(name = "LOGIN_TYPE")
	private String loginType;

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getPasswordDate() {
		return passwordDate;
	}

	public void setPasswordDate(LocalDateTime passwordDate) {
		this.passwordDate = passwordDate;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getInstID() {
		return instID;
	}

	public void setInstID(String instID) {
		this.instID = instID;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCreateUserID() {
		return createUserID;
	}

	public void setCreateUserID(String createUserID) {
		this.createUserID = createUserID;
	}

	public LocalDateTime getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(LocalDateTime insertDate) {
		this.insertDate = insertDate;
	}

	public LocalDateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getIsFirstTimeLogin() {
		return isFirstTimeLogin;
	}

	public void setIsFirstTimeLogin(String isFirstTimeLogin) {
		this.isFirstTimeLogin = isFirstTimeLogin;
	}

}
