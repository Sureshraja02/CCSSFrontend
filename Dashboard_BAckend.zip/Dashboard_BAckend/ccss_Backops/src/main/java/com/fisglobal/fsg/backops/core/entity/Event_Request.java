package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fisglobal.fsg.backops.core.entity.pk.Event_Request_PK;


@Table(name = "EVENT_REQUEST")
@Entity
@IdClass(Event_Request_PK.class)
public class Event_Request implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "EVENT_TYPE")
	private String eventType;

	@Column(name = "EVENT_NAME")
	private String eventName;
	
	@Id
	@Column(name = "PROPERTY_NAME")
	private String propertyName;

	@Id
	@Column(name = "PROPERTY_VALUE")
	private String propertyValue;

	@Column(name = "INSERTEDDATE")
	private LocalDateTime insertedDt;

	@Column(name = "MODIFIEDDATE")
	private LocalDateTime modifiedDt;

	@Column(name = "ISMANDATE")
	private String isMandate;

	@Column(name = "ISACTIVE")
	private String isActive;

	@Column(name = "PARENTTAGNAME")
	private String parentTagName;

	@Column(name = "DATATYPE")
	private String dataType;

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	public LocalDateTime getInsertedDt() {
		return insertedDt;
	}

	public void setInsertedDt(LocalDateTime insertedDt) {
		this.insertedDt = insertedDt;
	}

	public LocalDateTime getModifiedDt() {
		return modifiedDt;
	}

	public void setModifiedDt(LocalDateTime modifiedDt) {
		this.modifiedDt = modifiedDt;
	}

	public String getIsMandate() {
		return isMandate;
	}

	public void setIsMandate(String isMandate) {
		this.isMandate = isMandate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getParentTagName() {
		return parentTagName;
	}

	public void setParentTagName(String parentTagName) {
		this.parentTagName = parentTagName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

}
