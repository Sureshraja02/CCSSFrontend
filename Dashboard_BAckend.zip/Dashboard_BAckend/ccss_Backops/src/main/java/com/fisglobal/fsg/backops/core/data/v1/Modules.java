package com.fisglobal.fsg.backops.core.data.v1;

public class Modules {

	private String case_manager;
	private String back_office;
	private String reports;
	private String monitoring;

	public String getCase_manager() {
		return case_manager;
	}

	public void setCase_manager(String case_manager) {
		this.case_manager = case_manager;
	}

	public String getBack_office() {
		return back_office;
	}

	public void setBack_office(String back_office) {
		this.back_office = back_office;
	}

	public String getReports() {
		return reports;
	}

	public void setReports(String reports) {
		this.reports = reports;
	}

	public String getMonitoring() {
		return monitoring;
	}

	public void setMonitoring(String monitoring) {
		this.monitoring = monitoring;
	}

}
