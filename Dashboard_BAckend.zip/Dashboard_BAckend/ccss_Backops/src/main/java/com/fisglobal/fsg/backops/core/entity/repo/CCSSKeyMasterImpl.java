package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.fisglobal.fsg.backops.core.entity.CCSSKeyMaster_DAO;

@Repository
public class CCSSKeyMasterImpl {

	@PersistenceContext
	EntityManager em;
	
	public CCSSKeyMaster_DAO getEncKeyDataDAO(String paramStatus, String id) {
		CriteriaBuilder cb = null;
		CriteriaQuery<CCSSKeyMaster_DAO> cq =null;
		List<Predicate> predicates = null;
		Root<CCSSKeyMaster_DAO> rootBk = null;
		try {
			cb = em.getCriteriaBuilder();
			cq = cb.createQuery(CCSSKeyMaster_DAO.class);
			predicates = new ArrayList<Predicate>();
			
			rootBk = cq.from(CCSSKeyMaster_DAO.class);
			predicates.add(cb.equal(rootBk.get("id"), id));
			//predicates.add(cb.equal(rootBk.get("keyAlias"), paramKeyAlias));
			predicates.add(cb.equal(rootBk.get("status"), paramStatus));
			cq.where(predicates.toArray(new Predicate[] {}));
			TypedQuery<CCSSKeyMaster_DAO> query = em.createQuery(cq);
			return query.getSingleResult();

		} catch(Exception e) {
			return null;
		} finally {
			cb = null; cq = null;predicates = null;rootBk=null;
		}
	}
}
