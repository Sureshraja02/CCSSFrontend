package com.fisglobal.fsg.backops.core.common;

public class RuleExpression {

	private String ruleData1;

	private String ruleData2;

	private String operation;

	private String value;

	private String joinExpression;

	public String getRuleData1() {
		return ruleData1;
	}

	public void setRuleData1(String ruleData1) {
		this.ruleData1 = ruleData1;
	}

	public String getRuleData2() {
		return ruleData2;
	}

	public void setRuleData2(String ruleData2) {
		this.ruleData2 = ruleData2;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getJoinExpression() {
		return joinExpression;
	}

	public void setJoinExpression(String joinExpression) {
		this.joinExpression = joinExpression;
	}

}

