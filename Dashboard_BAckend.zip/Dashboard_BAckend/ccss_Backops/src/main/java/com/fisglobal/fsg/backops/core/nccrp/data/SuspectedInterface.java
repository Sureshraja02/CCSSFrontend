package com.fisglobal.fsg.backops.core.nccrp.data;

public interface SuspectedInterface {

	String getPayer();
	
	String getPayee();
	
	String getAcctNo();
	
	String getCustomerNo();
	
	String getShortName();
	
	String getbalance();
	
	String getCurrency();
	
	String getAcctType();
	
	String getStatus();
	
	String getOpenDate();
	
	String getBranchCode();
	
	String getPan();
	
	String getName();
	
	String getAddress();
	
	String getMobileNo();
	
	String getEmailAddress();
	
	String getIncome();
	
	String getAmount();
	
	String getRootAccountNumber();
	
	String getPayeeAcctNumber();
	
	String getTxnType();
	
	String getAadharNo();
}
