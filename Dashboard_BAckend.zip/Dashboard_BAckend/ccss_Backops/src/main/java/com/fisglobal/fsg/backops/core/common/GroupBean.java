package com.fisglobal.fsg.backops.core.common;

public class GroupBean {

	private String tId;

	public String gettId() {
		return tId;
	}

	public void settId(String tId) {
		this.tId = tId;
	}

	@Override
	public String toString() {
		return "GroupBean [tId=" + tId + "]";
	}

}
