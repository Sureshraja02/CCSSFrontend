package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.Menu_Master;

public interface MenuRepo extends PagingAndSortingRepository<Menu_Master, String> {
	
	@Query(value = "select * from MENU_MASTER order by MENU_ID", nativeQuery = true)	
	List<Menu_Master> getMenulist();
	
	@Query(value = "select * from MENU_MASTER where parent_menu_id=?1 order by MENU_ID", nativeQuery = true)
	List<Menu_Master> getChildMenu(String menuId);

	@Query(value = "select * from MENU_MASTER where parent_menu_id=?1 and sub_menu='true' order by MENU_ID", nativeQuery = true)
	List<Menu_Master> getSideMenuList(String menuId);
	

}
