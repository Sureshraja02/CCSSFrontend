package com.fisglobal.fsg.backops.core.config;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.ResourceAccessException;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.crypto.CommonEncUtils;
import com.fisglobal.fsg.backops.core.entity.CCSSKeyMaster_DAO;
import com.fisglobal.fsg.backops.core.entity.CCSSKeyRotationMaster_DAO;
import com.fisglobal.fsg.backops.core.entity.repo.CCSSKeyMasterImpl;
import com.fisglobal.fsg.backops.core.entity.repo.CCSSKeyMasterRepo;
import com.fisglobal.fsg.backops.core.entity.repo.CCSSKeyRotationMasterImpl;
import com.fisglobal.fsg.backops.core.entity.repo.CCSSKeyRotationMasterRepo;
import com.fisglobal.fsg.backops.core.utils.CommonUtils;



@Configuration
@EnableScheduling
@EnableAsync

@Order(Ordered.LOWEST_PRECEDENCE)
public class RouterMQConfiguration {
	private final static Logger log = LoggerFactory.getLogger(RouterMQConfiguration.class);
	@Inject
	Environment env;
	/*
	 * static Properties prop = new Properties(); static { String value =
	 * System.getProperty("propertyName"); log.info("FIle Name : {}", value);
	 * FileReader reader; try { if (value != null) { reader = new FileReader(value);
	 * prop.load(reader); } } catch (Exception e) { e.printStackTrace(); } }
	 */

	
	@Autowired
	CCSSKeyMasterImpl cCSSKeyMasterImpl;
	
	 
	@Autowired
	CCSSKeyMasterRepo cCSSKeyMasterRepo;
	
	@Autowired
	CCSSKeyRotationMasterRepo cCSSKeyRotationMasterRepo;
	
	@Autowired
	CCSSKeyRotationMasterImpl cCSSKeyRotationMasterImpl;
	
	@Autowired
	CommonEncUtils commonEncUtils;
	
	@Autowired
	CommonUtils commonUtils;
	
	
	public static Map<String, String> bankCodeMap = new HashMap<String, String>();
	public static List<String> backNameLst = new ArrayList<>();
	public static Map<String, Map> propertyMap = new HashMap<String, Map>();
	public static CCSSKeyRotationMaster_DAO rotationkeyMstrDaoPub = null;

	


	
	
	@Bean(name = RMSConstants.I4C_KEYMSTR)
	public void loadCommonKeyMstrTable() {
		try {
			CCSSKeyRotationMaster_DAO rotationMstObj = cCSSKeyRotationMasterImpl.getRotationMasterDataDAO("0", "1");
			if (rotationMstObj != null) {
				if (StringUtils.isNotBlank(rotationMstObj.getEncKey())) {
					rotationkeyMstrDaoPub = rotationMstObj;
				} else {
					toInsertKeyRotationMst();
				}
			} else {
				toInsertKeyRotationMst();
			}
		} catch (Exception e) {
			System.out.println("Exception e ::::::::::::::"+e);
		}
		
		String Encsampledata= commonUtils.toEncryptData("73428621836218", "ENC");
		System.out.println("ENcrypted Sample--------------------------> : [{"+Encsampledata+"}]");
		String Decsampledata= commonUtils.toEncryptData(Encsampledata, "DEC");
		System.out.println("Decsampledata Sample : [{"+Decsampledata+"}]");

	}

	void toInsertKeyRotationMst() {
		try {
			CCSSKeyMaster_DAO kymstrObj = cCSSKeyMasterImpl.getEncKeyDataDAO("0", "1");
			if (kymstrObj != null) {
				String encKey = commonEncUtils.keyDigest(kymstrObj.getKey1(), kymstrObj.getKey2());
				CCSSKeyRotationMaster_DAO rotationMstDao = new CCSSKeyRotationMaster_DAO();
				rotationMstDao.setEncKey(encKey);
				rotationMstDao.setKeyMasterId(Integer.parseInt(kymstrObj.getId()));
				rotationMstDao.setStatus(0);
				rotationMstDao.setSaltKey(kymstrObj.getSaltKey());
				rotationMstDao.setRolloverDate(new Date());
				rotationMstDao.setCreatedDate(new Date());
				rotationMstDao = cCSSKeyRotationMasterRepo.save(rotationMstDao);
				rotationkeyMstrDaoPub = rotationMstDao;
			}
		} catch (Exception e) {
			System.out.println("Exception e1 ::::::::::::::"+e);
		}
	}

	

	public <T> T getEnvValue(String key, Class<T> type) {
		T t = env.getProperty(key, type);
		if (t == null)
			throw new ResourceAccessException(key);
		return t;
	}

	public String getEnvValue(String key) {
		String value = env.getProperty(key);
		if (value == null)
			throw new ResourceAccessException(key);
		return value;
	}

	public String getEnvSep(String key) {
		String value = env.getProperty(key);
		if (value == null)
			value = "~";
		return value;
	}

	public String getEnvValueNotOptional(String key) {
		String value = env.getProperty(key);
		if (value == null) {
			log.info("key Not Confiured in receiveractivemq.proeprties. KEY is : [{}]", key);
			value = " ";
		}
		return value;
	}

	
	
	public static String getBankCode(String bankName) {
		String banCode = null;
		if (backNameLst != null && backNameLst.size() > 0) {
			List<String> matches = findMatches(backNameLst, bankName.toUpperCase());
			System.out.println("Matches for query '" + bankName.toUpperCase() + "': " + matches);
			if (matches != null && matches.size() > 0) {
				if (bankCodeMap != null && bankCodeMap.size() > 0) {
					banCode = bankCodeMap.get(matches.get(0));
				}
			}
		}
		return banCode;
	}
	public static List<String> findMatches(List<String> options, String query) {
		List<String> matches = new ArrayList<>();
		for (String option : options) {
			if (StringUtils.containsIgnoreCase(option, query)) {
				matches.add(option);
			}
		}
		return matches;
	}
	
	
	
}
