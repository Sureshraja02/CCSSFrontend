/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

/**
 * @author e5745290
 *
 */
public class TransactionSearchResponseData {

	private List<I4CRequestData> i4CRequestData;
	
	private List<I4CResponseData> i4CResponseData;
	
	private List<I4CCallBackResponse> i4CCallBackResponse;
	
	private List<I4CCallBackRequest> i4CCallBackRequest;

	/**
	 * @return the i4CRequestData
	 */
	public List<I4CRequestData> getI4CRequestData() {
		return i4CRequestData;
	}

	/**
	 * @param i4cRequestData the i4CRequestData to set
	 */
	public void setI4CRequestData(List<I4CRequestData> i4cRequestData) {
		i4CRequestData = i4cRequestData;
	}

	

	

	public List<I4CResponseData> getI4CResponseData() {
		return i4CResponseData;
	}

	public void setI4CResponseData(List<I4CResponseData> i4cResponseData) {
		i4CResponseData = i4cResponseData;
	}

	public List<I4CCallBackResponse> getI4CCallBackResponse() {
		return i4CCallBackResponse;
	}

	public void setI4CCallBackResponse(List<I4CCallBackResponse> i4cCallBackResponse) {
		i4CCallBackResponse = i4cCallBackResponse;
	}

	/**
	 * @return the i4CCallBackRequest
	 */
	public List<I4CCallBackRequest> getI4CCallBackRequest() {
		return i4CCallBackRequest;
	}

	/**
	 * @param i4cCallBackRequest the i4CCallBackRequest to set
	 */
	public void setI4CCallBackRequest(List<I4CCallBackRequest> i4cCallBackRequest) {
		i4CCallBackRequest = i4cCallBackRequest;
	}

	

	
	
	
}
