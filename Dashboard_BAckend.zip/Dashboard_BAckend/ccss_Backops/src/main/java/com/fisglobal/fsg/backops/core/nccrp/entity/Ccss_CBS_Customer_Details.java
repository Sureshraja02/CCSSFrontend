/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_CBS_CUSTOMER_DETAILS")
@Entity
public class Ccss_CBS_Customer_Details {
	
	
		@Id
		@Column(name = "ID")
		private String Id;
		
		@Column(name = "CUSTOMER_TYPE")
		private String customer_Type;
		
		@Column(name = "CUSTOMER_STATUS")
	    private String customer_Status;
	    
		@Column(name = "CUSTOMER_NO")
	    private String customer_No;
		
		@Column(name = "NAME1")
	    private String name1;
	    
		@Column(name = "MID_NAME")
	    private String mid_Name;
	    
		@Column(name = "NAME2")
	    private String name2;
		
		@Column(name = "BIRTH_DATE_1")
	    private String birth_Date_1;
	    
		@Column(name = "SEX_CODE")
	    private String sex_Code;
	    
		@Column(name = "BIRTH_PLACE")
	    private String birth_Place;
		
		@Column(name = "NATIONALITY_CD")
	    private String nationality_Cd;
	    
		@Column(name = "LANGUAGE_CODE")
	    private String language_Code;
	    
		@Column(name = "CUST_TAX_PAN")
	    private String cust_Tax_pan;	
		
		@Column(name = "ADD1")
	    private String add1;
	    
		@Column(name = "ADD2")
	    private String add2;
	    
		@Column(name = "ADD3")
	    private String add3;
		
		@Column(name = "ADD4")
	    private String add4;
	    
		@Column(name = "MOBILE_NO")
	    private String mobile_No;
	    
		@Column(name = "EMAIL_ADD1")
	    private String email_Add1;
		
		@Column(name = "EMAIL_ADD2")
	    private String email_Add2;
	    
		@Column(name = "OCCUPATION_CODE")
	    private String occupation_Code;
	    
		@Column(name = "UID_NO")
	    private String uid_No;
		
		@Column(name = "ESTB_DATE")
	    private String estb_Date;
	    
		@Column(name = "COME_DATE")
	    private String come_date;
	    
		@Column(name = "LIQD_DATE")
	    private String liqd_Date;	
		
		@Column(name = "LICENCE_NO")
	    private String licence_No;
	    
		
		
		@Column(name = "RESI_STATUS")
	    private String resi_Status;
	    
		@Column(name = "MISLA_ORG_CODE")
	    private String misla_org_Code;
		
		@Column(name = "BUS_SECTOR_CODE")
	    private String bus_Sector_Code;
	    
		@Column(name = "INDUSTRY_CODE")
	    private String industry_Code;
	    
		@Column(name = "DOMESTIC_RISK")
	    private String domestic_risk;
		
		@Column(name = "CROSS_BORDER_RISK")
	    private String cross_border_risk;
	    
		@Column(name = "RES_COUNTRY_CODE")
	    private String res_Country_Code;
	    
		@Column(name = "TRADE_CUSTOMER")
	    private String trade_Customer;
		

		
		@Column(name = "CUST_EVAL_FLAG")
	    private String cust_Eval_flag;
	    
		@Column(name = "CREATE_DT")
	    private String create_Dt;
	    
		@Column(name = "NO_OF_ACCTS")
	    private String no_of_Accts;	
		
		@Column(name = "COUNTRY_OF_RISK")
	    private String country_of_risk;
		
		@Column(name = "ADD_PROOF")
	    private String add_Proof;
	    
		@Column(name = "ADD_NUMBER")
	    private String add_Number;
		
		@Column(name = "LAST_STAT_CHG_DT")
	    private String last_Stat_Chg_Dt;
	    
		@Column(name = "HOME_BRANCH_NO")
	    private String home_branch_No;
	    
		@Column(name = "VILLAGE_CODE")
	    private String village_Code;
		
		@Column(name = "ID_TYPE")
	    private String id_Type;
	    
		@Column(name = "ID_NUMBER")
	    private String id_Number;
	    
		@Column(name = "DEATH_DATE")
	    private String death_Date;
		
		@Column(name = "TIER_CUST_TYPE")
	    private String tier_Cust_Type;
	    
	
		@Column(name = "FATHER_NAME")
	    private String father_Name;
	    
		@Column(name = "MOTHER_NAME")
	    private String mother_Name;	
		
		@Column(name = "SPOUSE_NAME")
	    private String spouse_Name;
	    
		@Column(name = "INCOME")
	    private String income;
		
		@Column(name = "RENTAL_INCOME")
	    private String rental_Income;
	    
		@Column(name = "OTHER_INCOME")
	    private String other_Income;
	    
		@Column(name = "ACCURED_INCOME")
	    private String accured_Income;
	
		@Column(name = "MAKE_ID")
	    private String make_Id;
	    
		@Column(name = "CHK_ID")
	    private String chk_Id;
		
		@Column(name = "SR_NO")
	    private String sr_No;

		/**
		 * @return the id
		 */
		public String getId() {
			return Id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			Id = id;
		}

		/**
		 * @return the customer_Type
		 */
		public String getCustomer_Type() {
			return customer_Type;
		}

		/**
		 * @param customer_Type the customer_Type to set
		 */
		public void setCustomer_Type(String customer_Type) {
			this.customer_Type = customer_Type;
		}

		/**
		 * @return the customer_Status
		 */
		public String getCustomer_Status() {
			return customer_Status;
		}

		/**
		 * @param customer_Status the customer_Status to set
		 */
		public void setCustomer_Status(String customer_Status) {
			this.customer_Status = customer_Status;
		}

		/**
		 * @return the customer_No
		 */
		public String getCustomer_No() {
			return customer_No;
		}

		/**
		 * @param customer_No the customer_No to set
		 */
		public void setCustomer_No(String customer_No) {
			this.customer_No = customer_No;
		}

		/**
		 * @return the name1
		 */
		public String getName1() {
			return name1;
		}

		/**
		 * @param name1 the name1 to set
		 */
		public void setName1(String name1) {
			this.name1 = name1;
		}

		/**
		 * @return the mid_Name
		 */
		public String getMid_Name() {
			return mid_Name;
		}

		/**
		 * @param mid_Name the mid_Name to set
		 */
		public void setMid_Name(String mid_Name) {
			this.mid_Name = mid_Name;
		}

		/**
		 * @return the name2
		 */
		public String getName2() {
			return name2;
		}

		/**
		 * @param name2 the name2 to set
		 */
		public void setName2(String name2) {
			this.name2 = name2;
		}

		/**
		 * @return the birth_Date_1
		 */
		public String getBirth_Date_1() {
			return birth_Date_1;
		}

		/**
		 * @param birth_Date_1 the birth_Date_1 to set
		 */
		public void setBirth_Date_1(String birth_Date_1) {
			this.birth_Date_1 = birth_Date_1;
		}

		/**
		 * @return the sex_Code
		 */
		public String getSex_Code() {
			return sex_Code;
		}

		/**
		 * @param sex_Code the sex_Code to set
		 */
		public void setSex_Code(String sex_Code) {
			this.sex_Code = sex_Code;
		}

		/**
		 * @return the birth_Place
		 */
		public String getBirth_Place() {
			return birth_Place;
		}

		/**
		 * @param birth_Place the birth_Place to set
		 */
		public void setBirth_Place(String birth_Place) {
			this.birth_Place = birth_Place;
		}

		/**
		 * @return the nationality_Cd
		 */
		public String getNationality_Cd() {
			return nationality_Cd;
		}

		/**
		 * @param nationality_Cd the nationality_Cd to set
		 */
		public void setNationality_Cd(String nationality_Cd) {
			this.nationality_Cd = nationality_Cd;
		}

		/**
		 * @return the language_Code
		 */
		public String getLanguage_Code() {
			return language_Code;
		}

		/**
		 * @param language_Code the language_Code to set
		 */
		public void setLanguage_Code(String language_Code) {
			this.language_Code = language_Code;
		}

		/**
		 * @return the cust_Tax_pan
		 */
		public String getCust_Tax_pan() {
			return cust_Tax_pan;
		}

		/**
		 * @param cust_Tax_pan the cust_Tax_pan to set
		 */
		public void setCust_Tax_pan(String cust_Tax_pan) {
			this.cust_Tax_pan = cust_Tax_pan;
		}

		/**
		 * @return the add1
		 */
		public String getAdd1() {
			return add1;
		}

		/**
		 * @param add1 the add1 to set
		 */
		public void setAdd1(String add1) {
			this.add1 = add1;
		}

		/**
		 * @return the add2
		 */
		public String getAdd2() {
			return add2;
		}

		/**
		 * @param add2 the add2 to set
		 */
		public void setAdd2(String add2) {
			this.add2 = add2;
		}

		/**
		 * @return the add3
		 */
		public String getAdd3() {
			return add3;
		}

		/**
		 * @param add3 the add3 to set
		 */
		public void setAdd3(String add3) {
			this.add3 = add3;
		}

		/**
		 * @return the add4
		 */
		public String getAdd4() {
			return add4;
		}

		/**
		 * @param add4 the add4 to set
		 */
		public void setAdd4(String add4) {
			this.add4 = add4;
		}

		/**
		 * @return the mobile_No
		 */
		public String getMobile_No() {
			return mobile_No;
		}

		/**
		 * @param mobile_No the mobile_No to set
		 */
		public void setMobile_No(String mobile_No) {
			this.mobile_No = mobile_No;
		}

		/**
		 * @return the email_Add1
		 */
		public String getEmail_Add1() {
			return email_Add1;
		}

		/**
		 * @param email_Add1 the email_Add1 to set
		 */
		public void setEmail_Add1(String email_Add1) {
			this.email_Add1 = email_Add1;
		}

		/**
		 * @return the email_Add2
		 */
		public String getEmail_Add2() {
			return email_Add2;
		}

		/**
		 * @param email_Add2 the email_Add2 to set
		 */
		public void setEmail_Add2(String email_Add2) {
			this.email_Add2 = email_Add2;
		}

		/**
		 * @return the occupation_Code
		 */
		public String getOccupation_Code() {
			return occupation_Code;
		}

		/**
		 * @param occupation_Code the occupation_Code to set
		 */
		public void setOccupation_Code(String occupation_Code) {
			this.occupation_Code = occupation_Code;
		}

		/**
		 * @return the uid_No
		 */
		public String getUid_No() {
			return uid_No;
		}

		/**
		 * @param uid_No the uid_No to set
		 */
		public void setUid_No(String uid_No) {
			this.uid_No = uid_No;
		}

		/**
		 * @return the estb_Date
		 */
		public String getEstb_Date() {
			return estb_Date;
		}

		/**
		 * @param estb_Date the estb_Date to set
		 */
		public void setEstb_Date(String estb_Date) {
			this.estb_Date = estb_Date;
		}

		/**
		 * @return the come_date
		 */
		public String getCome_date() {
			return come_date;
		}

		/**
		 * @param come_date the come_date to set
		 */
		public void setCome_date(String come_date) {
			this.come_date = come_date;
		}

		/**
		 * @return the liqd_Date
		 */
		public String getLiqd_Date() {
			return liqd_Date;
		}

		/**
		 * @param liqd_Date the liqd_Date to set
		 */
		public void setLiqd_Date(String liqd_Date) {
			this.liqd_Date = liqd_Date;
		}

		/**
		 * @return the licence_No
		 */
		public String getLicence_No() {
			return licence_No;
		}

		/**
		 * @param licence_No the licence_No to set
		 */
		public void setLicence_No(String licence_No) {
			this.licence_No = licence_No;
		}

		/**
		 * @return the resi_Status
		 */
		public String getResi_Status() {
			return resi_Status;
		}

		/**
		 * @param resi_Status the resi_Status to set
		 */
		public void setResi_Status(String resi_Status) {
			this.resi_Status = resi_Status;
		}

		/**
		 * @return the misla_org_Code
		 */
		public String getMisla_org_Code() {
			return misla_org_Code;
		}

		/**
		 * @param misla_org_Code the misla_org_Code to set
		 */
		public void setMisla_org_Code(String misla_org_Code) {
			this.misla_org_Code = misla_org_Code;
		}

		/**
		 * @return the bus_Sector_Code
		 */
		public String getBus_Sector_Code() {
			return bus_Sector_Code;
		}

		/**
		 * @param bus_Sector_Code the bus_Sector_Code to set
		 */
		public void setBus_Sector_Code(String bus_Sector_Code) {
			this.bus_Sector_Code = bus_Sector_Code;
		}

		/**
		 * @return the industry_Code
		 */
		public String getIndustry_Code() {
			return industry_Code;
		}

		/**
		 * @param industry_Code the industry_Code to set
		 */
		public void setIndustry_Code(String industry_Code) {
			this.industry_Code = industry_Code;
		}

		/**
		 * @return the domestic_risk
		 */
		public String getDomestic_risk() {
			return domestic_risk;
		}

		/**
		 * @param domestic_risk the domestic_risk to set
		 */
		public void setDomestic_risk(String domestic_risk) {
			this.domestic_risk = domestic_risk;
		}

		/**
		 * @return the cross_border_risk
		 */
		public String getCross_border_risk() {
			return cross_border_risk;
		}

		/**
		 * @param cross_border_risk the cross_border_risk to set
		 */
		public void setCross_border_risk(String cross_border_risk) {
			this.cross_border_risk = cross_border_risk;
		}

		/**
		 * @return the res_Country_Code
		 */
		public String getRes_Country_Code() {
			return res_Country_Code;
		}

		/**
		 * @param res_Country_Code the res_Country_Code to set
		 */
		public void setRes_Country_Code(String res_Country_Code) {
			this.res_Country_Code = res_Country_Code;
		}

		/**
		 * @return the trade_Customer
		 */
		public String getTrade_Customer() {
			return trade_Customer;
		}

		/**
		 * @param trade_Customer the trade_Customer to set
		 */
		public void setTrade_Customer(String trade_Customer) {
			this.trade_Customer = trade_Customer;
		}

		/**
		 * @return the cust_Eval_flag
		 */
		public String getCust_Eval_flag() {
			return cust_Eval_flag;
		}

		/**
		 * @param cust_Eval_flag the cust_Eval_flag to set
		 */
		public void setCust_Eval_flag(String cust_Eval_flag) {
			this.cust_Eval_flag = cust_Eval_flag;
		}

		/**
		 * @return the create_Dt
		 */
		public String getCreate_Dt() {
			return create_Dt;
		}

		/**
		 * @param create_Dt the create_Dt to set
		 */
		public void setCreate_Dt(String create_Dt) {
			this.create_Dt = create_Dt;
		}

		/**
		 * @return the no_of_Accts
		 */
		public String getNo_of_Accts() {
			return no_of_Accts;
		}

		/**
		 * @param no_of_Accts the no_of_Accts to set
		 */
		public void setNo_of_Accts(String no_of_Accts) {
			this.no_of_Accts = no_of_Accts;
		}

		/**
		 * @return the country_of_risk
		 */
		public String getCountry_of_risk() {
			return country_of_risk;
		}

		/**
		 * @param country_of_risk the country_of_risk to set
		 */
		public void setCountry_of_risk(String country_of_risk) {
			this.country_of_risk = country_of_risk;
		}

		/**
		 * @return the add_Proof
		 */
		public String getAdd_Proof() {
			return add_Proof;
		}

		/**
		 * @param add_Proof the add_Proof to set
		 */
		public void setAdd_Proof(String add_Proof) {
			this.add_Proof = add_Proof;
		}

		/**
		 * @return the add_Number
		 */
		public String getAdd_Number() {
			return add_Number;
		}

		/**
		 * @param add_Number the add_Number to set
		 */
		public void setAdd_Number(String add_Number) {
			this.add_Number = add_Number;
		}

		/**
		 * @return the last_Stat_Chg_Dt
		 */
		public String getLast_Stat_Chg_Dt() {
			return last_Stat_Chg_Dt;
		}

		/**
		 * @param last_Stat_Chg_Dt the last_Stat_Chg_Dt to set
		 */
		public void setLast_Stat_Chg_Dt(String last_Stat_Chg_Dt) {
			this.last_Stat_Chg_Dt = last_Stat_Chg_Dt;
		}

		/**
		 * @return the home_branch_No
		 */
		public String getHome_branch_No() {
			return home_branch_No;
		}

		/**
		 * @param home_branch_No the home_branch_No to set
		 */
		public void setHome_branch_No(String home_branch_No) {
			this.home_branch_No = home_branch_No;
		}

		/**
		 * @return the village_Code
		 */
		public String getVillage_Code() {
			return village_Code;
		}

		/**
		 * @param village_Code the village_Code to set
		 */
		public void setVillage_Code(String village_Code) {
			this.village_Code = village_Code;
		}

		/**
		 * @return the id_Type
		 */
		public String getId_Type() {
			return id_Type;
		}

		/**
		 * @param id_Type the id_Type to set
		 */
		public void setId_Type(String id_Type) {
			this.id_Type = id_Type;
		}

		/**
		 * @return the id_Number
		 */
		public String getId_Number() {
			return id_Number;
		}

		/**
		 * @param id_Number the id_Number to set
		 */
		public void setId_Number(String id_Number) {
			this.id_Number = id_Number;
		}

		/**
		 * @return the death_Date
		 */
		public String getDeath_Date() {
			return death_Date;
		}

		/**
		 * @param death_Date the death_Date to set
		 */
		public void setDeath_Date(String death_Date) {
			this.death_Date = death_Date;
		}

		/**
		 * @return the tier_Cust_Type
		 */
		public String getTier_Cust_Type() {
			return tier_Cust_Type;
		}

		/**
		 * @param tier_Cust_Type the tier_Cust_Type to set
		 */
		public void setTier_Cust_Type(String tier_Cust_Type) {
			this.tier_Cust_Type = tier_Cust_Type;
		}

		/**
		 * @return the father_Name
		 */
		public String getFather_Name() {
			return father_Name;
		}

		/**
		 * @param father_Name the father_Name to set
		 */
		public void setFather_Name(String father_Name) {
			this.father_Name = father_Name;
		}

		/**
		 * @return the mother_Name
		 */
		public String getMother_Name() {
			return mother_Name;
		}

		/**
		 * @param mother_Name the mother_Name to set
		 */
		public void setMother_Name(String mother_Name) {
			this.mother_Name = mother_Name;
		}

		/**
		 * @return the spouse_Name
		 */
		public String getSpouse_Name() {
			return spouse_Name;
		}

		/**
		 * @param spouse_Name the spouse_Name to set
		 */
		public void setSpouse_Name(String spouse_Name) {
			this.spouse_Name = spouse_Name;
		}

		/**
		 * @return the income
		 */
		public String getIncome() {
			return income;
		}

		/**
		 * @param income the income to set
		 */
		public void setIncome(String income) {
			this.income = income;
		}

		/**
		 * @return the rental_Income
		 */
		public String getRental_Income() {
			return rental_Income;
		}

		/**
		 * @param rental_Income the rental_Income to set
		 */
		public void setRental_Income(String rental_Income) {
			this.rental_Income = rental_Income;
		}

		/**
		 * @return the other_Income
		 */
		public String getOther_Income() {
			return other_Income;
		}

		/**
		 * @param other_Income the other_Income to set
		 */
		public void setOther_Income(String other_Income) {
			this.other_Income = other_Income;
		}

		/**
		 * @return the accured_Income
		 */
		public String getAccured_Income() {
			return accured_Income;
		}

		/**
		 * @param accured_Income the accured_Income to set
		 */
		public void setAccured_Income(String accured_Income) {
			this.accured_Income = accured_Income;
		}

		/**
		 * @return the make_Id
		 */
		public String getMake_Id() {
			return make_Id;
		}

		/**
		 * @param make_Id the make_Id to set
		 */
		public void setMake_Id(String make_Id) {
			this.make_Id = make_Id;
		}

		/**
		 * @return the chk_Id
		 */
		public String getChk_Id() {
			return chk_Id;
		}

		/**
		 * @param chk_Id the chk_Id to set
		 */
		public void setChk_Id(String chk_Id) {
			this.chk_Id = chk_Id;
		}

		/**
		 * @return the sr_No
		 */
		public String getSr_No() {
			return sr_No;
		}

		/**
		 * @param sr_No the sr_No to set
		 */
		public void setSr_No(String sr_No) {
			this.sr_No = sr_No;
		}


		
		
}
