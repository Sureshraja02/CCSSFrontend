package com.fisglobal.fsg.backops.core.nccrp.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(Include.NON_NULL)
public class I4CRequest_VO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Schema(required = true, description = "Acknowledgement Number", example = "31608230000001")
	private String acknowledgement_no;
	@Schema(required = true, description = "Sub Category - E-Wallet Related Fraud", example = "E-Wallet Related Fraud")
	private String sub_category;
	@Schema(required = true, description = "Instrument Class")
	Instrument instrument;

	public String getAcknowledgement_no() {
		return acknowledgement_no;
	}

	public void setAcknowledgement_no(String acknowledgement_no) {
		this.acknowledgement_no = acknowledgement_no;
	}

	public String getSub_category() {
		return sub_category;
	}

	public void setSub_category(String sub_category) {
		this.sub_category = sub_category;
	}

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}
}
