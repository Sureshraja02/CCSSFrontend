/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_FileUploadData;

/**
 * @author e5745290
 *
 */
public interface Ccss_FileUploadDataRepo extends JpaRepository<Ccss_FileUploadData, String> {

	


}
