/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Account_Details;

/**
 * @author e5745290
 *
 */
public class AccountDetailsResponseData extends BaseResponseData{

	public Ccss_Account_Details ccss_Account_Details;

	/**
	 * @return the ccss_Account_Details
	 */
	public Ccss_Account_Details getCcss_Account_Details() {
		return ccss_Account_Details;
	}

	/**
	 * @param ccss_Account_Details the ccss_Account_Details to set
	 */
	public void setCcss_Account_Details(Ccss_Account_Details ccss_Account_Details) {
		this.ccss_Account_Details = ccss_Account_Details;
	}
	
	
	
}
