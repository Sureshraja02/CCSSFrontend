package com.fisglobal.fsg.backops.core.nccrp.activemq.jmsactivemq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.nccrp.activemq.jmsactivemq.data.I4CMQRequestVo;

@Component
public class SenderJMS {
	private static final Logger LOGGER = LoggerFactory.getLogger(SenderJMS.class);

	@Value("${server.filebase.inbound.topic}")
	String topicName;		
	
	@Value("${server.filebase.outbound.topic}")
	String outboundTopic;	
	
	@Autowired
	private JmsTemplate jmsTemplate;

	public String sendRequest(String message) {
		
		try {
			//LOGGER.debug("Topic : [{}]", topicName);
			jmsTemplate.convertAndSend(topicName, message);
			return RMSConstants.SUCCESS_MSG;
		} catch (Exception ex) {
			LOGGER.error("Exception in message : ", ex);
			return RMSConstants.FAILURE_MSG;

		}
	}
	


	public void send(String message) {
		LOGGER.info("sending message='{}'", message);
		jmsTemplate.convertAndSend(topicName, message);
	}
	
}
