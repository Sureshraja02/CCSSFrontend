package com.fisglobal.fsg.backops.core.service.v1;

import java.util.Collection;
import java.util.Optional;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fisglobal.fsg.backops.core.entity.User_Master;

public class CustomUserDetails implements UserDetails {
	
	private static final long serialVersionUID = 1L;
	private String username;
	private String keyword;
	Collection<? extends GrantedAuthority> authorities;
	
	
	public CustomUserDetails(User_Master userMaster) {
		this.username = userMaster.getEmail();
		/*this.keyword = byUsername.getKeyword();

		List<GrantedAuthority> auths = new ArrayList<>();

		for (UserRole role : byUsername.getRoles()) {

			auths.add(new SimpleGrantedAuthority(role.getName().toUpperCase()));
		}
		this.authorities = auths;*/
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return authorities;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return keyword;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return username;
	}


	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
