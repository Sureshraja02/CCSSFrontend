/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fisglobal.fsg.backops.core.nccrp.data.DemographicViewResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedInterface;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Account_Details;
import com.google.common.base.Optional;

/**
 * @author e5745290
 *
 */


	@Repository
	public interface Ccss_SuspectedChainRepo extends JpaRepository<Ccss_Account_Details, Long> {
		
		
	    
		@Query(nativeQuery = true,
	            value = "select A.ROOT_ACCOUNT_NUMBER as payer,A.PAYEE_ACCOUNT_NUMBER as payee from Ccss_Trans_Details A inner join Ccss_Account_Details B on " + 
	            		"A.ROOT_ACCOUNT_NUMBER = B.acct_No inner join Ccss_customer_Details C on " + 
	            		"C.CUSTOMER_NO = B.CUSTOMER_NO where C.MOBILE_NO=?1")
	    public List<SuspectedInterface> getSuspectedChainBymobileNo(String mobileNumber);
	 
	    
		@Query(nativeQuery = true,
	            value = "select B.ROOT_ACCOUNT_NUMBER as payer,B.PAYEE_ACCOUNT_NUMBER as payee from Ccss_Account_Details A inner join Ccss_Trans_Details B on A.acct_No = B.root_Account_Number where A.acct_No=?1")
	    public List<SuspectedInterface> getSuspectedChainByAccountNo(String acctNo);
	 
		@Query(nativeQuery = true,
	            value = " select ACCT_NO as acctNo,CUSTOMER_NO as customerNo,SHORT_NAME as shortName,CURR_BAL as balance , CURRENCY as currency from Ccss_Account_Details where CUSTOMER_NO=(select CUSTOMER_NO from Ccss_customer_Details where MOBILE_NO=?1)")
	    public List<SuspectedInterface> getDemographicDetailsByMobileNo(String mobileNumber);
	 
		@Query(nativeQuery = true,
	            value = " select ACCT_NO as acctNo,CUSTOMER_NO as customerNo,SHORT_NAME as shortName,CURR_BAL as balance , CURRENCY as currency from Ccss_Account_Details where ACCT_NO=?1")
	    public List<SuspectedInterface> getDemographicDetailsByAccountNo(String acctNo);

		@Query(nativeQuery = true,
	            value = " select ACCT_NO as acctNo,CUSTOMER_NO as customerNo,SHORT_NAME as shortName,CURR_BAL as balance , CURRENCY as currency from Ccss_Account_Details where ACCT_NO=(select ROOT_ACCOUNT_NUMBER from ccss_trans_details where TRANSACTION_ID=?1)")
	    public List<SuspectedInterface> getDemographicDetailsByTransactionId(String txnId);
	 
		@Query(nativeQuery = true,
	            value = " select ACCT_NO as acctNo,CUSTOMER_NO as customerNo,SHORT_NAME as shortName,CURR_BAL as balance , CURRENCY as currency from Ccss_Account_Details where CUSTOMER_NO=(select CUSTOMER_NO from Ccss_customer_Details where CUST_TAX_PAN=?1)")
	    public List<SuspectedInterface> getDemographicDetailsByPAN(String pan);
	 
		@Query(nativeQuery = true,
	            value = " select ACCT_NO as acctNo,CUSTOMER_NO as customerNo,SHORT_NAME as shortName,CURR_BAL as balance , CURRENCY as currency from Ccss_Account_Details where ACCT_NO=(select ROOT_ACCOUNT_NUMBER from ccss_trans_details where ACKNOWLEDGEMENT_NO=?1)")
	    public List<SuspectedInterface> getDemographicDetailsByAcknowledgement(String acknowledgementNo );
	 
		@Query(nativeQuery = true,
	            value = "  select A.ACCT_NO as acctNo,A.CUSTOMER_NO as customerNo,A.SHORT_NAME as shortName, A.ACCT_TYPE as acctType, A.CURR_STATUS as status,A.ACCT_OPEN_DATE as openDate, " + 
	            		"  A.BRANCH_NO as branchCode, B.CUST_TAX_PAN as pan, B.NAME1 as name,B.ADD1 as address, B.MOBILE_NO as mobileNo, B.EMAIL_ADD1 as emailAddress,B.INCOME as income, " + 
	            		"  CURR_BAL as balance , CURRENCY as currency,C.AMOUNT as amount,C.ROOT_ACCOUNT_NUMBER as rootAccountNumber,C.PAYEE_ACCOUNT_NUMBER as payeeAcctNumber,C.TXN_TYPE as txnType,A.AADHAR_NO as aadharNo from Ccss_Account_Details A inner join ccss_customer_details B on a.CUSTOMER_NO=b.CUSTOMER_NO inner join Ccss_trans_Details C on C.ROOT_ACCOUNT_NUMBER=A.ACCT_NO or C.PAYEE_ACCOUNT_NUMBER=A.ACCT_NO where ACCT_NO=?1")
	    public List<SuspectedInterface> getDemographicAccountInfo(String acctNo);
	 
		

		@Query(nativeQuery = true,
	            value = "select A.ACCT_NO as accountNo,A.DESCRIPT as desc,B.NAME1 as name,A.CURRENCY as currency from Ccss_cbs_Account_Details A inner join Ccss_CBS_customer_Details B on A.CUSTOMER_NO = B.CUSTOMER_NO where B.MOBILE_NO=?1")
	    public List<SuspectedInterface> getNewDemographicDetailsByMobileNo(String mobileNumber);
		
		
		@Query(nativeQuery = true,
	            value = "select A.ACCT_NO as acctNo,A.DESCRIPT as accountTitle,B.NAME1 as name,A.CURRENCY as currency from Ccss_cbs_Account_Details A inner join Ccss_CBS_customer_Details B on A.CUSTOMER_NO = B.CUSTOMER_NO where A.ACCT_NO=?1")
	    public List<DemographicViewResponseData> getNewDemographicDetailsByAccountNumber(String accountNo);
		
		
		@Query(nativeQuery = true,
	            value = "select A.ACCT_NO as acctNo,A.DESCRIPT as descs,B.NAME1 as shortName,A.CURRENCY as currency from Ccss_cbs_Account_Details A inner join Ccss_CBS_customer_Details B on a.CUSTOMER_NO=b.CUSTOMER_NO inner join CCSS_CFTD C on C.PAYER_ACCOUNT_NUMBER=A.ACCT_NO  where C.ACKNOWLEDGEMENT_NO=?1")
	    public List<DemographicViewResponseData> getNewDemographicDetailsByAckNo(String ackNo);
		
		
		@Query(nativeQuery = true,
	            value = "select A.ACCT_NO as accountNo,A.DESCRIPT as desc,B.NAME1 as name,A.CURRENCY as currency from Ccss_cbs_Account_Details A inner join Ccss_CBS_customer_Details B on A.CUSTOMER_NO = B.CUSTOMER_NO where B.CUST_TAX_PAN=?1")
	    public List<DemographicViewResponseData> getNewDemographicDetailsByPAN(String pan);
		
		
		@Query(nativeQuery = true,
	            value = "select A.ACCT_NO as accountNo,A.DESCRIPT as desc,B.NAME1 as name,A.CURRENCY as currency from Ccss_cbs_Account_Details A inner join Ccss_CBS_customer_Details B on a.CUSTOMER_NO=b.CUSTOMER_NO inner join CCSS_CFTD C on C.PAYER_ACCOUNT_NUMBER=A.ACCT_NO  where C.RRN=?1")
	    public List<DemographicViewResponseData> getNewDemographicDetailsByRRN(String rrn);
		
		@Query(nativeQuery = true,
	            value = "select A.CHANNEL as channel,A.TRANS_REF_NO as transRefNo,A.PAYEE_VPA as payeeVpa,A.BENE_NAME as beneName,A.AMOUNT as amount,A.DISPUTE_AMOUNT as disputeAmount,A.FRAUD_FG as fraudFg,B.SUB_CATEGORY as subCategory,B.ACKNOWLEDGEMENT_NO as ackNo,B.TRANSACTION_DATE as transactionDate from CCSS_CBS_TRANS_FRAUD_DETAILS A inner join CCSS_CFTD B on a.ACCOUNT_NO=b.PAYER_ACCOUNT_NUMBER inner join Ccss_CBS_account_Details C on C.ACCT_NO=A.ACCOUNT_NO  where C.CUSTOMER_NO=(select CUSTOMER_NO from Ccss_CBS_customer_Details where MOBILE_NO=?1)")
	    public List<DemographicViewResponseData> getNewSuspectedChainDetailByMobileNo(String mobileNo);
		
		@Query(nativeQuery = true,
	            value = "select A.CHANNEL as channel,A.TRANS_REF_NO as transRefNo,A.PAYEE_VPA as payeeVpa,A.BENE_NAME as beneName,A.AMOUNT as amount,A.DISPUTE_AMOUNT as disputeAmount,A.FRAUD_FG as fraudFg,B.SUB_CATEGORY as subCategory,B.ACKNOWLEDGEMENT_NO as ackNo,B.TRANSACTION_DATE as transactionDate from CCSS_CBS_TRANS_FRAUD_DETAILS A inner join CCSS_CFTD B on A.COMPLIANT_RRN = B.RRN where B.PAYER_ACCOUNT_NUMBER=?1")
	    public List<DemographicViewResponseData> getNewSuspectedChainDetailByAccount(String accountNo);
		
		

	}

