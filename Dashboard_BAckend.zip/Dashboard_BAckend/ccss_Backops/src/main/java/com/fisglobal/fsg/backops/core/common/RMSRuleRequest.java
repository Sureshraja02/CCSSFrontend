package com.fisglobal.fsg.backops.core.common;

import java.util.List;



public class RMSRuleRequest {

	private String ruleName;
	private String ruleAction;
	private String caseManagerFlag;
	private String enviroment;
	private String order;

	private List<RMSEvent> event;

	private List<RMSRuleCondition> ruleCondition;

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public List<RMSEvent> getEvent() {
		return event;
	}

	public void setEvent(List<RMSEvent> event) {
		this.event = event;
	}

	public List<RMSRuleCondition> getRuleCondition() {
		return ruleCondition;
	}

	public void setRuleCondition(List<RMSRuleCondition> ruleCondition) {
		this.ruleCondition = ruleCondition;
	}

	public String getRuleAction() {
		return ruleAction;
	}

	public void setRuleAction(String ruleAction) {
		this.ruleAction = ruleAction;
	}

	public String getCaseManagerFlag() {
		return caseManagerFlag;
	}

	public void setCaseManagerFlag(String caseManagerFlag) {
		this.caseManagerFlag = caseManagerFlag;
	}

	public String getEnviroment() {
		return enviroment;
	}

	public void setEnviroment(String enviroment) {
		this.enviroment = enviroment;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}
