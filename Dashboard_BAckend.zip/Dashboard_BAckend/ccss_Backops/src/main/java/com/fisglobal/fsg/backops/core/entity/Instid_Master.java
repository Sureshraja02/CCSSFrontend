package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.sql.Blob;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fisglobal.fsg.backops.core.entity.pk.Menu_Master_PK;

@Table(name = "INSTID_MASTER")
@Entity
public class Instid_Master implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ORG_NAME")
	private String orgName;

	@Column(name = "ORG_LOGO")
	private String orgLogo;

	@Id
	@GeneratedValue(generator = "instseq")
	@SequenceGenerator(name = "instseq", sequenceName = "INSTSEQ", allocationSize = 1)
	@Column(name = "ORG_ID")
	private Long orgID;

	@Column(name = "ORG_PRIMARY_COLOR")
	private String orgPrimaryColor;

	@Column(name = "ORG_SECONDARY_COLOR")
	private String orgSecondaryColor;

	@Column(name = "CREATEUSERID")
	private String createdUserID;

	@Column(name = "INSERTEDDATE")
	private LocalDateTime insertedDT;

	@Column(name = "MODIFIEDDATE")
	private LocalDateTime modifiedDT;

	@Column(name = "APPINFOCOLOR")
	private String appInfoColor;

	@Column(name = "APPWARNINGCOLOR")
	private String appWarningColor;

	@Column(name = "APPSUCCESSCOLOR")
	private String appSuccessColor;

	@Column(name = "APPDANGERCOLOR")
	private String appDangerColor;

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgLogo() {
		return orgLogo;
	}

	public void setOrgLogo(String orgLogo) {
		this.orgLogo = orgLogo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getOrgID() {
		return orgID;
	}

	public void setOrgID(Long orgID) {
		this.orgID = orgID;
	}

	public String getOrgPrimaryColor() {
		return orgPrimaryColor;
	}

	public void setOrgPrimaryColor(String orgPrimaryColor) {
		this.orgPrimaryColor = orgPrimaryColor;
	}

	public String getOrgSecondaryColor() {
		return orgSecondaryColor;
	}

	public void setOrgSecondaryColor(String orgSecondaryColor) {
		this.orgSecondaryColor = orgSecondaryColor;
	}

	public String getCreatedUserID() {
		return createdUserID;
	}

	public void setCreatedUserID(String createdUserID) {
		this.createdUserID = createdUserID;
	}

	public LocalDateTime getInsertedDT() {
		return insertedDT;
	}

	public void setInsertedDT(LocalDateTime insertedDT) {
		this.insertedDT = insertedDT;
	}

	public LocalDateTime getModifiedDT() {
		return modifiedDT;
	}

	public void setModifiedDT(LocalDateTime modifiedDT) {
		this.modifiedDT = modifiedDT;
	}

	public String getAppInfoColor() {
		return appInfoColor;
	}

	public void setAppInfoColor(String appInfoColor) {
		this.appInfoColor = appInfoColor;
	}

	public String getAppWarningColor() {
		return appWarningColor;
	}

	public void setAppWarningColor(String appWarningColor) {
		this.appWarningColor = appWarningColor;
	}

	public String getAppSuccessColor() {
		return appSuccessColor;
	}

	public void setAppSuccessColor(String appSuccessColor) {
		this.appSuccessColor = appSuccessColor;
	}

	public String getAppDangerColor() {
		return appDangerColor;
	}

	public void setAppDangerColor(String appDangerColor) {
		this.appDangerColor = appDangerColor;
	}

}
