package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_KEY_ROTATION_MASTER")
@Entity
@DynamicUpdate
public class CCSSKeyRotationMaster_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "KRLMIDSEQ", sequenceName = "KRLMIDSEQ", allocationSize = 1)
	private String id;
	
	@Column(name = "ENCKEY")
	private String encKey;

	@Column(name = "KEY_MASTER_ID")
	private Integer	keyMasterId;
	 
	@Column(name = "CREATEDDATE")
	private Date createdDate;

	@Column(name = "ROLLOVERDATE")
	private Date rolloverDate;

	@Column(name = "STATUS")
	private Integer	status;
	
	@Column(name = "SALTKEY")
	private String saltKey;
	
	@ManyToOne
	@JoinColumn(name = "KEY_MASTER_ID", insertable = false, updatable = false)
	private CCSSKeyMaster_DAO keyMaster;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEncKey() {
		return encKey;
	}

	public void setEncKey(String encKey) {
		this.encKey = encKey;
	}

	public Integer getKeyMasterId() {
		return keyMasterId;
	}

	public void setKeyMasterId(Integer keyMasterId) {
		this.keyMasterId = keyMasterId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getRolloverDate() {
		return rolloverDate;
	}

	public void setRolloverDate(Date rolloverDate) {
		this.rolloverDate = rolloverDate;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getSaltKey() {
		return saltKey;
	}

	public void setSaltKey(String saltKey) {
		this.saltKey = saltKey;
	}

	public CCSSKeyMaster_DAO getKeyMaster() {
		return keyMaster;
	}

	public void setKeyMaster(CCSSKeyMaster_DAO keyMaster) {
		this.keyMaster = keyMaster;
	}
	
}
