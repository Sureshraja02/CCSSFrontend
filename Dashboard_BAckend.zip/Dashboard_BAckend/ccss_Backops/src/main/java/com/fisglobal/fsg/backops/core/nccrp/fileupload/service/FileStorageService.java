/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.fileupload.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fisglobal.fsg.backops.core.nccrp.activemq.jmsactivemq.SenderJMS;
import com.fisglobal.fsg.backops.core.nccrp.activemq.jmsactivemq.data.I4CMQRequestVo;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.SuspectrRegistryDetails_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_CftdRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.SuspectedRegsitryDetailsRepo;
import com.fisglobal.fsg.backops.core.utils.CommonUtils;
/**
 * @author e5745290
 *
 */
@Service
public class FileStorageService {
	
	
	@Autowired
	Ccss_CftdRepo ccssCftd;
	
	@Autowired
	SuspectedRegsitryDetailsRepo suspectedDetailsI4CRepo;
	
	@Inject
	private SenderJMS senderJms;
	
	@Autowired
	CommonUtils commonUtils;

	
	private static final Logger LOGGER = LoggerFactory.getLogger(FileStorageService.class);

    private final Path fileStorageLocation = Paths.get("uploads").toAbsolutePath().normalize();
    
    private final Path suspectFileStorageLocation = Paths.get("suspectuploads").toAbsolutePath().normalize();

    public FileStorageService() {
        try {
            Files.createDirectories(this.fileStorageLocation);
            Files.createDirectories(this.suspectFileStorageLocation);
        } catch (Exception ex) {
            throw new RuntimeException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public String storeFile(MultipartFile file) throws InvalidFormatException {
        // Normalize file name
    
 
        String fileName = file.getOriginalFilename()+System.currentTimeMillis();
        UUID uuid = null;
		String job_id = null;
		
        try {
            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation);
            
            Workbook workbook = WorkbookFactory.create(file.getInputStream());
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter();
    
            for(int i=1;i<sheet.getPhysicalNumberOfRows() ;i++) {
            	Ccss_Cftd_Details cftdEntity=new Ccss_Cftd_Details();
            	
            	if(formatter.formatCellValue(sheet.getRow(i).getCell(1))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(12))!=null)
            	{
            		Ccss_Cftd_Details ccssCftdInsrtObj = ccssCftd.getAckNoDetailsrrnAndAck(formatter.formatCellValue(sheet.getRow(i).getCell(1)), formatter.formatCellValue(sheet.getRow(i).getCell(12)));
    				if (ccssCftdInsrtObj != null) {
    					
    					LOGGER.info("JobId : [{}] - Ack No. [{}] RRN [{}] - Record Already Exist ", job_id,
								formatter.formatCellValue(sheet.getRow(i).getCell(1)),formatter.formatCellValue(sheet.getRow(i).getCell(12)));
    				}
    				else
					{

						cftdEntity.setAcknowledgementNo(formatter.formatCellValue(sheet.getRow(i).getCell(1)));
						cftdEntity.setSubCategory(formatter.formatCellValue(sheet.getRow(i).getCell(2)));
						
						if(formatter.formatCellValue(sheet.getRow(i).getCell(4))!=null)
						{
							String[] txnDate=(formatter.formatCellValue(sheet.getRow(i).getCell(4))).toString().split("-");
							
							cftdEntity.setComplaintDate(txnDate[2]+"-"+txnDate[1]+"-"+txnDate[0]);	
						}
						if(formatter.formatCellValue(sheet.getRow(i).getCell(3))!=null)
						{
							String[] ComplaintDate=(formatter.formatCellValue(sheet.getRow(i).getCell(3))).toString().split("-");
							cftdEntity.setTransactionDate(ComplaintDate[2]+"-"+ComplaintDate[1]+"-"+ComplaintDate[0]);
						}
						
					
						// cftdEntity.setEntryDate(formatter.formatCellValue(sheet.getRow(i).getCell(5)));
						cftdEntity.setState(formatter.formatCellValue(sheet.getRow(i).getCell(6)));
						cftdEntity.setDistrict(formatter.formatCellValue(sheet.getRow(i).getCell(7)));
						cftdEntity.setModeOfPayment(formatter.formatCellValue(sheet.getRow(i).getCell(9)));
						cftdEntity.setPayerAccountNumber(formatter.formatCellValue(sheet.getRow(i).getCell(10)));
						cftdEntity.setRrn(formatter.formatCellValue(sheet.getRow(i).getCell(12)));
						cftdEntity.setLayer(formatter.formatCellValue(sheet.getRow(i).getCell(13)));
						cftdEntity.setRequestor(formatter.formatCellValue(sheet.getRow(i).getCell(14)));
						cftdEntity.setAmount(formatter.formatCellValue(sheet.getRow(i).getCell(15)));

						if (formatter.formatCellValue(sheet.getRow(i).getCell(16)) != null) {
							cftdEntity.setDisputedAmount(
									new BigDecimal(formatter.formatCellValue(sheet.getRow(i).getCell(16))));

						}
						cftdEntity.setRemarks("Record Inserted from File");
						uuid = UUID.randomUUID();
						job_id = "IND" + "-" + uuid.toString();
						cftdEntity.setJobId(job_id);
						cftdEntity.setRecordType("FILE");
						cftdEntity.setMiddlewareAPICallStatus("01");
						cftdEntity.setEntryDate(new Date(System.currentTimeMillis()));
						cftdEntity.setHoldStatus("N");
						ccssCftd.save(cftdEntity);

						I4CMQRequestVo I4cReqVoObj = new I4CMQRequestVo();
						LOGGER.info("JobId : [{}] - Ack No. [{}] - Pushing to MQ - [ASYNC Call]", job_id,
								formatter.formatCellValue(sheet.getRow(i).getCell(1)));
						I4cReqVoObj.setAcknowledgement_no(formatter.formatCellValue(sheet.getRow(i).getCell(1)));
						I4cReqVoObj.setInstCode("IND");
						I4cReqVoObj.setJobId(job_id);
						I4cReqVoObj.setpFlag("A");
						ObjectMapper objectMapper = new ObjectMapper();
						String requestStr = objectMapper.writeValueAsString(I4cReqVoObj);
						String jmsStatus = senderJms.sendRequest(requestStr);
						LOGGER.info("JobId : [{}] - Ack No. [{}] - Pushed to MQ - [{}]", job_id,
								formatter.formatCellValue(sheet.getRow(i).getCell(1)), jmsStatus);

					}
            	   }
            }
            
            
            return fileName;
        } catch (IOException ex) {
            throw new RuntimeException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }
    
    public String storeSuspectRepositoryFile(MultipartFile file) throws InvalidFormatException {
        // Normalize file name
    
 
        String fileName = file.getOriginalFilename()+System.currentTimeMillis();
        UUID uuid = null;
		String job_id = null;
		
        try {
            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.suspectFileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation);
            
            Workbook workbook = WorkbookFactory.create(file.getInputStream());
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter formatter = new DataFormatter();
            String errorLines="";
           /* for(int i=1;i<sheet.getPhysicalNumberOfRows() ;i++) {
            	if(formatter.formatCellValue(sheet.getRow(i).getCell(1))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(1)).equals(""))
				{
            		errorLines=errorLines+","+i; 
            		
				}
            	else if(formatter.formatCellValue(sheet.getRow(i).getCell(5))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(5)).equals(""))
				{
            		errorLines=errorLines+","+i; 
            		
            		
				}
            	else if(formatter.formatCellValue(sheet.getRow(i).getCell(6))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(6)).equals(""))
				{
            		errorLines=errorLines+","+i; 
            		
				}
            	else if(formatter.formatCellValue(sheet.getRow(i).getCell(7))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(7)).equals(""))
				{
            		errorLines=errorLines+","+i; 
            		
				}
            	else if(formatter.formatCellValue(sheet.getRow(i).getCell(8))!=null && formatter.formatCellValue(sheet.getRow(i).getCell(8)).equals(""))
				{
            		errorLines=errorLines+","+i;  
            	
				}
            	
            }
    */
            if(StringUtils.isNotBlank(errorLines))
            {
            	fileName="Please upload the Mandatory Filed(Account Number, Line number :"+errorLines;	
            }
            if(!StringUtils.isNotBlank(errorLines))
            {
            	
            
            for(int i=1;i<sheet.getPhysicalNumberOfRows() ;i++) {
            	
            	SuspectrRegistryDetails_DAO suspectRepoEntity=new SuspectrRegistryDetails_DAO();
            	
            	if(formatter.formatCellValue(sheet.getRow(i).getCell(1))!=null && !formatter.formatCellValue(sheet.getRow(i).getCell(1)).equals(""))
				{

				
					suspectRepoEntity.setAccountNo(formatter.formatCellValue(sheet.getRow(i).getCell(1)));
					suspectRepoEntity.setIfscCode(formatter.formatCellValue(sheet.getRow(i).getCell(2)));
					suspectRepoEntity.setCinNumber(formatter.formatCellValue(sheet.getRow(i).getCell(3)));
					suspectRepoEntity.setAccountHolderName(formatter.formatCellValue(sheet.getRow(i).getCell(4)));
					
					suspectRepoEntity.setPanNoOfCompany(formatter.formatCellValue(sheet.getRow(i).getCell(5)));
					suspectRepoEntity.setPanNoOfIndividual(formatter.formatCellValue(sheet.getRow(i).getCell(6)));
					suspectRepoEntity.setEmailOfSuspect(formatter.formatCellValue(sheet.getRow(i).getCell(7)));
					suspectRepoEntity.setPhoneNoOfSuspect(formatter.formatCellValue(sheet.getRow(i).getCell(8)));
					suspectRepoEntity.setGstNo(formatter.formatCellValue(sheet.getRow(i).getCell(9)));
					
					suspectRepoEntity.setWebsite(formatter.formatCellValue(sheet.getRow(i).getCell(10)));
					suspectRepoEntity.setUpiHandle((formatter.formatCellValue(sheet.getRow(i).getCell(11))));
					suspectRepoEntity.setSource(formatter.formatCellValue(sheet.getRow(i).getCell(12)));
					
					
					suspectRepoEntity.setSuspectAddress(formatter.formatCellValue(sheet.getRow(i).getCell(13)));
					suspectRepoEntity.setDlNumber(formatter.formatCellValue(sheet.getRow(i).getCell(14)));
					suspectRepoEntity.setPassportNumber(formatter.formatCellValue(sheet.getRow(i).getCell(15)));
					suspectRepoEntity.setVoterId(formatter.formatCellValue(sheet.getRow(i).getCell(16)));
					suspectRepoEntity.setNregaCardNo(formatter.formatCellValue(sheet.getRow(i).getCell(17)));
					suspectRepoEntity.setOtherDocNumber(formatter.formatCellValue(sheet.getRow(i).getCell(18)));
					suspectRepoEntity.setOtherDicType(formatter.formatCellValue(sheet.getRow(i).getCell(19)));
				
					suspectRepoEntity.setPresentDirector(formatter.formatCellValue(sheet.getRow(i).getCell(20)));
					suspectRepoEntity.setCountryCode(formatter.formatCellValue(sheet.getRow(i).getCell(21)));
					suspectRepoEntity.setIpAddress(formatter.formatCellValue(sheet.getRow(i).getCell(22)));
					suspectRepoEntity.setEntryDate(new Date(System.currentTimeMillis()));
					suspectedDetailsI4CRepo.save(suspectRepoEntity);
					
					fileName="File uploaded successfully:"; 
				}
    				
            	else
            	{
            		fileName="Upload Failed Missing Mandatory in this file";	        
            	}

						

					}
            	   
            
            }
            
           
        } catch (IOException ex) {
        	fileName="Could not store file" + fileName + ". Please check the file!";
        }
		return fileName;
    }
}
