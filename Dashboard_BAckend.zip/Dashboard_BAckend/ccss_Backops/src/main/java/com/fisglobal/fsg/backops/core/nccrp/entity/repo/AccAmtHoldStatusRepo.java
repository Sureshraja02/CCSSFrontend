package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.entity.AccAmtHoldStatus_DAO;

public interface AccAmtHoldStatusRepo extends JpaRepository<AccAmtHoldStatus_DAO, AccAmtHoldStatus_PK>,
		JpaSpecificationExecutor<AccAmtHoldStatus_DAO> {
			
			@Query(value = "select * from CCSS_ACC_AMT_HOLD_STATUS where ACCOUNT_NO=?1", nativeQuery = true)
			List<AccAmtHoldStatus_DAO> getHoldDetailsBasedOnAccNo(String accNo);
			
			@Query(value = "select * from CCSS_ACC_AMT_HOLD_STATUS where JOURNAL_NUMBER=?1", nativeQuery = true)
			List<AccAmtHoldStatus_DAO> getHoldDetailsBasedOnJournalNum(String journNum);

	List<AccAmtHoldStatus_DAO> findByHoldDateBetween(Date startDate, Date endDate);

}
