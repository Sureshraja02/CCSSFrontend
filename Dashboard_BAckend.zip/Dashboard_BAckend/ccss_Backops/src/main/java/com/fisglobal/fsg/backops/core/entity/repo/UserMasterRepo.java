package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.pk.User_Master_PK;

public interface UserMasterRepo
		extends JpaRepository<User_Master, User_Master_PK>, JpaSpecificationExecutor<User_Master> {
	
	@Query(value = "SELECT * FROM USER_MASTER WHERE EMAIL = ?1 and PASSWORD =?2", nativeQuery = true)		
	User_Master getLoginData(String userId,String password);
}
