package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.io.Serializable;

import javax.persistence.Basic;

public class AccAmtHoldStatus_PK implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Basic
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	

}
