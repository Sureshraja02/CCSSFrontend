package com.fisglobal.fsg.backops.core.entity.pk;

import java.io.Serializable;

import javax.persistence.Basic;

public class Group_Master_PK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Basic
	private String groupId;

	@Basic
	private String tid;

	@Basic
	private String sid;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

}
