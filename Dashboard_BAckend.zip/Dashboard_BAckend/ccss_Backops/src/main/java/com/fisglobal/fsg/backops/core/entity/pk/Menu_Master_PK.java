package com.fisglobal.fsg.backops.core.entity.pk;

import java.io.Serializable;

import javax.persistence.Basic;

public class Menu_Master_PK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Basic
	private String menuID;

	public String getMenuID() {
		return menuID;
	}

	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}

}
