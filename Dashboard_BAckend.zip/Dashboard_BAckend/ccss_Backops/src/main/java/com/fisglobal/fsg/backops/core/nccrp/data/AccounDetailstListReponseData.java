/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

/**
 * @author e5745290
 *
 */
public class AccounDetailstListReponseData {

	private List<AccountListData> accountList;

	/**
	 * @return the accountList
	 */
	public List<AccountListData> getAccountList() {
		return accountList;
	}

	/**
	 * @param accountList the accountList to set
	 */
	public void setAccountList(List<AccountListData> accountList) {
		this.accountList = accountList;
	}

	
}
