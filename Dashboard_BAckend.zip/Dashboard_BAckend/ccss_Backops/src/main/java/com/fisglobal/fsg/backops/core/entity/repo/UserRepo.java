package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.User_Master;

public interface UserRepo extends PagingAndSortingRepository<User_Master, Long> {

	@Query(value = "select * from USER_MASTER where EMAIL=?1", nativeQuery = true)	
	User_Master findByEmail(String userID);

	User_Master findByUserID(Long userId);
	
	Page<User_Master> findByLoginTypeContaining(String loginType,
			org.springframework.data.domain.Pageable paging);
}
