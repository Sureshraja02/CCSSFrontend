package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.entity.CCSSKeyRotationMaster_DAO;

public interface CCSSKeyRotationMasterRepo extends JpaRepository<CCSSKeyRotationMaster_DAO, String> {
}
