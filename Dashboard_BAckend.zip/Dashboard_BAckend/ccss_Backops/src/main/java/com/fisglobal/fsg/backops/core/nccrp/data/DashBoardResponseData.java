/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class DashBoardResponseData extends BaseResponseData{

	public DashBoardData dashBoardData;

	/**
	 * @return the dashBoardData
	 */
	public DashBoardData getDashBoardData() {
		return dashBoardData;
	}

	/**
	 * @param dashBoardData the dashBoardData to set
	 */
	public void setDashBoardData(DashBoardData dashBoardData) {
		this.dashBoardData = dashBoardData;
	}
	
	
	
	

}
