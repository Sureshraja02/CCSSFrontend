package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.Event_Request;
import com.fisglobal.fsg.backops.core.entity.pk.Event_Request_PK;

public interface EventRequestRepo
		extends JpaRepository<Event_Request, Event_Request_PK>, JpaSpecificationExecutor<Event_Request> {

	@Query(value = "SELECT * FROM EVENT_REQUEST WHERE EVENT_TYPE =upper(?1) order by PARENTTAGNAME", nativeQuery = true)
	List<Event_Request> getTagDetails(String eventType);

}
