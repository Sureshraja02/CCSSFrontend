package com.fisglobal.fsg.backops.core.nccrp.fileupload.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.nccrp.data.DashboardInterface;
import com.fisglobal.fsg.backops.core.nccrp.entity.CcssCBSTransactionFraudDetails_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssCbsTransactionFraudDetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_CftdRepo;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.BeneficiaryData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadRequestData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadResponseData;

@Service
public class FileDownloadService {

	@Autowired
	Ccss_CftdRepo ccssCftd;
	
	@Autowired
	CcssCbsTransactionFraudDetailsRepo ccssCbsTransactionFraudDetailsRepo;
	
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(FileDownloadService.class);
	
	 private static final String CSV_HEADER = "SNO,RECORD_STATUS,REMARKS,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,TRANS_REF_NO,TRANSACTION_AMOUNT,DISPUTE_AMOUNT,FRAUD_FG,CHANNEL,BENE_NAME,PAYEE_VPA,TERMINAL_ID,MERCHANT_ID,ATM_ID, ATM_PLACE,ATM_BRANCH,BENE_REMI_ACC_NUM, BENE_REMI_IFSC, BENE_REMI_BANK\n";
	 
	 private static final String OVERALL_CSV_HEADER = "SNO,COMPLAINT_DATE,TOTAL_ACK,FULLY_SUCCESS,PARTIAL_SUCCESS,FULLY_FAILED\n";
	 
	 private static final String TRANSACTIONHOLD_CSV_HEADER = "SNO,ACCOUNT_NO,HOLD_VALUE,DISPUTED_AMOUNT\n";
	 
	 private static final String DIGITAL_CSV_HEADER = "SNO,ACCOUNT_NO,MOBILE_NUMBER,ACKNOWLEDGEMENT_NO,COMPLAINT_RRN\n";
	 
	 private static final String ERROR_CSV_HEADER = "SNO,ACCOUNT_NO,MOBILE_NUMBER,ACKNOWLEDGEMENT_NO,COMPLAINT_RRN\n";
	 
	 private static final String FULLY_FAILED_TECH_CSV_HEADER = "SNO,COMPLAINT_DATE,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,AMOUNT,DISPUTE_AMOUNT,TXN_DATE,TXN_TIME,STATUS,REASON\n";
	 
	 private static final String FULLY_FAILED_BUS_CSV_HEADER = "SNO,COMPLAINT_DATE,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,AMOUNT,DISPUTE_AMOUNT,TXN_DATE,STATUS,REASON\n";
	 
	 private static final String PARTIAL_SUCCESS_TECH_CSV_HEADER = "SNO,COMPLAINT_DATE,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,AMOUNT,DISPUTE_AMOUNT,TXN_DATE,STATUS,REASON\n";
	 
	 private static final String PARTIAL_SUCCESS_BUS_CSV_HEADER = "SNO,COMPLAINT_DATE,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,AMOUNT,DISPUTE_AMOUNT,TXN_DATE,STATUS,REASON\n";
	 
	 
	 private final Path fileStorageLocation = Paths.get("download").toAbsolutePath().normalize();
	 
	public DownloadResponseData fileDownload(DownloadRequestData request) throws IOException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
        

		List<Ccss_Cftd_Details> list = ccssCftd.getCftd_DetailsByFromandToDate(fromDate, toDate,request.getDownloadType(),RMSConstants.SUCCESS_CODE);

		if (list != null && !list.isEmpty()) {

			for(Ccss_Cftd_Details entity:list)
			{
				if (StringUtils.isNotBlank(entity.getMiddlewareAPICallStatus()) && RMSConstants.SUCCESS_CODE.equals(entity.getMiddlewareAPICallStatus()) 
						&& StringUtils.isNotBlank(entity.getMiddleStatusCode()) && RMSConstants.SUCCESS_CODE.equals(entity.getMiddleStatusCode())) {
					
					
					List<CcssCBSTransactionFraudDetails_DAO> beneficiaryList= ccssCbsTransactionFraudDetailsRepo.getAllFraudDetailsByRrnandAccountNo(entity.getRrn(), entity.getPayerAccountNumber());
					
					if(beneficiaryList!=null && !beneficiaryList.isEmpty())
					{
						
						downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
						for(CcssCBSTransactionFraudDetails_DAO beneficiaryEntity:beneficiaryList)
						{
							
							 csvContent.append(sNo).append(",")
							 .append(beneficiaryEntity.getFraudStatus()).append(",")
							 .append(beneficiaryEntity.getRemarks()).append(",")
							 .append(beneficiaryEntity.getAcknowledgementNo()).append(",")
		                      .append(beneficiaryEntity.getAccountNo()).append(",")		                     
		                      .append(beneficiaryEntity.getComplaintRrn()).append(",")		                      
		                      .append(beneficiaryEntity.getTxnRefNo()).append(",")
		                      .append(beneficiaryEntity.getAmount()).append(",")
		                      .append(beneficiaryEntity.getDisputeBalance()).append(",");
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getFraud_Fg()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getFraud_Fg()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getChannel()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getChannel()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneName()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneName()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getPayeeVpa()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getPayeeVpa()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getTerminalId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getTerminalId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getMerchantId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getMerchantId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmBranch()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmBranch()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmPlace()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmPlace()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiAcctNum()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiAcctNum()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiIfsc()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiIfsc()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiBank()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiBank()).append("\n");  
		                      }else
		                      {
		                    	  csvContent.append("").append("\n");  
		                      }
		                     
		                     
		                     
							 sNo++;
							 
						}
						
					}
					
					
					

				} 
				
				
				
			}
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	
	public DownloadResponseData fileDownloadOverAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(OVERALL_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.getOverallcount(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getComplaint_date()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getFully_success()))
		              {
		            	  csvContent.append(entity.getFully_success()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getPartial_success()))
		              {
		            	  csvContent.append(entity.getPartial_success()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getFully_failed()))
		              {
		            	  csvContent.append(entity.getFully_failed()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadTransaction(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(TRANSACTIONHOLD_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.getTransactionHold(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getAccountNo()).append(",")
					 .append(entity.getHoldValue()).append(",");
		              
		           
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadDigital(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(DIGITAL_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.getDigitalBlock(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getAccountNo()).append(",")
					 .append(entity.getMobileNo()).append(",")
					 .append(entity.getAcknowlegementNo()).append(",");
		           
		              if(StringUtils.isNotBlank(entity.getComplaintRrn()))
		              {
		            	  csvContent.append(entity.getComplaintRrn()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadError(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(ERROR_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.getError(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getAccountNo()).append(",")
					 .append(entity.getMobileNo()).append(",")
					 .append(entity.getAcknowlegementNo()).append(",");
		           
		              if(StringUtils.isNotBlank(entity.getComplaintRrn()))
		              {
		            	  csvContent.append(entity.getComplaintRrn()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData reportDownload(DownloadRequestData request) throws IOException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
        

		List<Ccss_Cftd_Details> list = ccssCftd.getCftd_DetailsByFromandToDate(fromDate, toDate,request.getDownloadType(),RMSConstants.SUCCESS_CODE);

		if (list != null && !list.isEmpty()) {

			for(Ccss_Cftd_Details entity:list)
			{
				if (StringUtils.isNotBlank(entity.getMiddlewareAPICallStatus()) && RMSConstants.SUCCESS_CODE.equals(entity.getMiddlewareAPICallStatus()) 
						&& StringUtils.isNotBlank(entity.getMiddleStatusCode()) && RMSConstants.SUCCESS_CODE.equals(entity.getMiddleStatusCode())) {
					
					
					List<CcssCBSTransactionFraudDetails_DAO> beneficiaryList= ccssCbsTransactionFraudDetailsRepo.getAllFraudDetailsByRrnandAccountNo(entity.getRrn(), entity.getPayerAccountNumber());
					
					if(beneficiaryList!=null && !beneficiaryList.isEmpty())
					{
						
						downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
						for(CcssCBSTransactionFraudDetails_DAO beneficiaryEntity:beneficiaryList)
						{
							
							 csvContent.append(sNo).append(",")
							 .append(beneficiaryEntity.getFraudStatus()).append(",")
							 .append(beneficiaryEntity.getRemarks()).append(",")
							 .append(beneficiaryEntity.getAcknowledgementNo()).append(",")
		                      .append(beneficiaryEntity.getAccountNo()).append(",")		                     
		                      .append(beneficiaryEntity.getComplaintRrn()).append(",")		                      
		                      .append(beneficiaryEntity.getTxnRefNo()).append(",")
		                      .append(beneficiaryEntity.getAmount()).append(",")
		                      .append(beneficiaryEntity.getDisputeBalance()).append(",");
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getFraud_Fg()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getFraud_Fg()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getChannel()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getChannel()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneName()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneName()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getPayeeVpa()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getPayeeVpa()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getTerminalId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getTerminalId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getMerchantId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getMerchantId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmId()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmId()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmBranch()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmBranch()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getAtmPlace()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getAtmPlace()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiAcctNum()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiAcctNum()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiIfsc()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiIfsc()).append(",");  
		                      }else
		                      {
		                    	  csvContent.append("").append(",");  
		                      }
		                      
		                      if(StringUtils.isNotBlank(beneficiaryEntity.getBeneRemiBank()))
		                      {
		                    	  csvContent.append(beneficiaryEntity.getBeneRemiBank()).append("\n");  
		                      }else
		                      {
		                    	  csvContent.append("").append("\n");  
		                      }
		                     
		                     
		                     
							 sNo++;
							 
						}
						
					}
					
					
					

				} 
				
				
				
			}
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadFullyFailedTechnicalAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(FULLY_FAILED_TECH_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.fileDownloadFullyFailedTechnicalAll(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getEntryDate()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getAccountNo()))
		              {
		            	  csvContent.append(entity.getAccountNo()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getRrn()))
		              {
		            	  csvContent.append(entity.getRrn()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getAmount()))
		              {
		            	  csvContent.append(entity.getAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		             
		              
		              if(StringUtils.isNotBlank(entity.getTxnDate()))
		              {
		            	  csvContent.append(entity.getTxnDate()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getTxnTime()))
		              {
		            	  csvContent.append(entity.getTxnTime()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getStatus()))
		              {
		            	  csvContent.append(entity.getStatus()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              if(StringUtils.isNotBlank(entity.getReason()))
		              {
		            	  csvContent.append(entity.getReason()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadFullyFailedBusinessAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(FULLY_FAILED_TECH_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.fileDownloadFullyFailedBusinessAll(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getEntryDate()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getAccountNo()))
		              {
		            	  csvContent.append(entity.getAccountNo()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getRrn()))
		              {
		            	  csvContent.append(entity.getRrn()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getAmount()))
		              {
		            	  csvContent.append(entity.getAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		            
		              
		              if(StringUtils.isNotBlank(entity.getTxnDate()))
		              {
		            	  csvContent.append(entity.getTxnDate()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getTxnTime()))
		              {
		            	  csvContent.append(entity.getTxnTime()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getStatus()))
		              {
		            	  csvContent.append(entity.getStatus()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              if(StringUtils.isNotBlank(entity.getReason()))
		              {
		            	  csvContent.append(entity.getReason()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadPartialSuccessTechnicalAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(FULLY_FAILED_TECH_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.fileDownloadPartialSuccessTechnicalAll(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getEntryDate()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getAccountNo()))
		              {
		            	  csvContent.append(entity.getAccountNo()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getRrn()))
		              {
		            	  csvContent.append(entity.getRrn()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getAmount()))
		              {
		            	  csvContent.append(entity.getAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		             
		              
		              if(StringUtils.isNotBlank(entity.getTxnDate()))
		              {
		            	  csvContent.append(entity.getTxnDate()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getTxnTime()))
		              {
		            	  csvContent.append(entity.getTxnTime()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getStatus()))
		              {
		            	  csvContent.append(entity.getStatus()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              if(StringUtils.isNotBlank(entity.getReason()))
		              {
		            	  csvContent.append(entity.getReason()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	public DownloadResponseData fileDownloadPartialSucessBusinessAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(FULLY_FAILED_TECH_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.fileDownloadPartialSucessBusinessAll(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getEntryDate()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getAccountNo()))
		              {
		            	  csvContent.append(entity.getAccountNo()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getRrn()))
		              {
		            	  csvContent.append(entity.getRrn()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getAmount()))
		              {
		            	  csvContent.append(entity.getAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		             
		              
		              if(StringUtils.isNotBlank(entity.getTxnDate()))
		              {
		            	  csvContent.append(entity.getTxnDate()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getTxnTime()))
		              {
		            	  csvContent.append(entity.getTxnTime()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getStatus()))
		              {
		            	  csvContent.append(entity.getStatus()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              if(StringUtils.isNotBlank(entity.getReason()))
		              {
		            	  csvContent.append(entity.getReason()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
	
	public DownloadResponseData fileDownloadFullySuccessAll(DownloadRequestData request) throws IOException, ParseException
	{
		DownloadResponseData downloadresp=new DownloadResponseData();
		int sNo=1;
		BeneficiaryData beneData=new BeneficiaryData();
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		beneData.setFileName(filename);
		downloadresp.setFileName(filename);
		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(FULLY_FAILED_TECH_CSV_HEADER);
		String toDatestr[] = request.getToDate().split("-");
		String fromDatestr[] = request.getFromDate().split("-");
		String fromDate = fromDatestr[2] + "-" + fromDatestr[1] + "-" + fromDatestr[0];
		String toDate = toDatestr[2] + "-" + toDatestr[1] + "-" +toDatestr[0];
		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		 
		 Date fromDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(fromDate);
		 Date toDateAsDate = new SimpleDateFormat("dd-MM-yyyy").parse(toDate);
        
		 List<DashboardInterface> list= ccssCftd.fileDownloadSuccessAll(fromDateAsDate, toDateAsDate);
			if (list != null && !list.isEmpty()) {
				downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
				 for(DashboardInterface entity:list)
					{
					
					 
					 csvContent.append(sNo).append(",")
					 .append(entity.getEntryDate()).append(",")
					 .append(entity.getAckNumber()).append(",");
		              
		              if(StringUtils.isNotBlank(entity.getAccountNo()))
		              {
		            	  csvContent.append(entity.getAccountNo()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getRrn()))
		              {
		            	  csvContent.append(entity.getRrn()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getAmount()))
		              {
		            	  csvContent.append(entity.getAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getDisputedAmount()))
		              {
		            	  csvContent.append(entity.getDisputedAmount()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }		              
		              
		              
		              if(StringUtils.isNotBlank(entity.getTxnDate()))
		              {
		            	  csvContent.append(entity.getTxnDate()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append(",");  
		              }
		              if(StringUtils.isNotBlank(entity.getTxnTime()))
		              {
		            	  csvContent.append(entity.getTxnTime()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              
		              if(StringUtils.isNotBlank(entity.getStatus()))
		              {
		            	  csvContent.append(entity.getStatus()).append(",");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		              if(StringUtils.isNotBlank(entity.getReason()))
		              {
		            	  csvContent.append(entity.getReason()).append("\n");  
		              }else
		              {
		            	  csvContent.append("").append("\n");  
		              }
		             
		             
					 sNo++;
					}
			
		

	
			beneData.setCsvContent(csvContent.toString());
			targetLocation.toFile().createNewFile();
			 OutputStream os = new FileOutputStream(targetLocation.toFile());
	         os.write(beneData.getCsvContent().getBytes());
		}
		else
		{
			downloadresp.setStatus(RMSConstants.FAILURE_CODE);
			downloadresp.setStatusDesc("No record Found for the Date");
			
		}
		return downloadresp;
	}
	
}
