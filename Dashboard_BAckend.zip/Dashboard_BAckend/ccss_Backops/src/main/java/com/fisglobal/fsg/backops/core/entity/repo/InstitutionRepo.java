package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.Instid_Master;

public interface InstitutionRepo extends PagingAndSortingRepository<Instid_Master,Long> {

}
