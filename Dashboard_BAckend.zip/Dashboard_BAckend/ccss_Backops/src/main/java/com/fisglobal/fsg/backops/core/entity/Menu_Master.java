package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.fisglobal.fsg.backops.core.entity.pk.Menu_Master_PK;

@Table(name = "MENU_MASTER")
@Entity
@IdClass(Menu_Master_PK.class)
public class Menu_Master implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MENU_ID")
	private String menuID;

	@Column(name = "MENU_NAME")
	private String menuName;

	@Column(name = "TID")
	private String tid;

	@Column(name = "SID")
	private String sid;

	@Column(name = "PATH")
	private String path;

	@Column(name = "PAGE")
	private String page;

	@Column(name = "SUB_MENU")
	private String subMenu;

	@Column(name = "PARENT_MENU_ID")
	private String parentMenuID;

	@Column(name = "MAKERID")
	private String makerID;

	@Column(name = "CHECKERID")
	private String checkerID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFIEDDATE", columnDefinition = "TIMESTAMP")
	private java.util.Date modifiedDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INSERTEDDATE", columnDefinition = "TIMESTAMP")
	private java.util.Date insertedDate;

	@Column(name = "RC_ID")
	private long moduleId;
	
	@Column(name = "ICONS")
	private String icons;
	
	

	public String getIcons() {
		return icons;
	}

	public void setIcons(String icons) {
		this.icons = icons;
	}

	public String getMenuID() {
		return menuID;
	}

	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getSubMenu() {
		return subMenu;
	}

	public void setSubMenu(String subMenu) {
		this.subMenu = subMenu;
	}

	public String getParentMenuID() {
		return parentMenuID;
	}

	public void setParentMenuID(String parentMenuID) {
		this.parentMenuID = parentMenuID;
	}

	public String getMakerID() {
		return makerID;
	}

	public void setMakerID(String makerID) {
		this.makerID = makerID;
	}

	public String getCheckerID() {
		return checkerID;
	}

	public void setCheckerID(String checkerID) {
		this.checkerID = checkerID;
	}

	public long getModuleId() {
		return moduleId;
	}

	public void setModuleId(long moduleId) {
		this.moduleId = moduleId;
	}

	public long getModule() {
		return moduleId;
	}

	public void setModule(long module) {
		this.moduleId = module;
	}

	public java.util.Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(java.util.Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public java.util.Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(java.util.Date insertedDate) {
		this.insertedDate = insertedDate;
	}

}
