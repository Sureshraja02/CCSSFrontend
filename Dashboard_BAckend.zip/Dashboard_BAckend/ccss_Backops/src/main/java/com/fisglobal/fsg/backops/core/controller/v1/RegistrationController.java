package com.fisglobal.fsg.backops.core.controller.v1;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.data.v1.ChangePasswordResponse;

import io.swagger.annotations.Api;

@Api(tags="Password Management",description = "User Password Management Functionality")
@RestController
@RequestMapping(value = "/app/rest/v1.0/service/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class RegistrationController {
	
	@RequestMapping(value = "changepassword", method = RequestMethod.GET)
	public ResponseEntity<ChangePasswordResponse> changePassword(
			@RequestHeader(value = "requestid") String reqId,
			@PathVariable String userid,
			@PathVariable String password){
		
		ChangePasswordResponse response = new ChangePasswordResponse();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
