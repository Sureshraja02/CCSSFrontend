package com.fisglobal.fsg.backops.core.nccrp.data;

public interface SuspectedChainInterface {

	
	
	String getAccountNo();
	
	String getChannel();
	
	String getName();
	
	String getBalance();
	
	String getCurrency();
	
	String getDesc();
	
	String getTransRefNo();
	
	String getPayeeVpa();
	
	String getBeneName();
	
	String getPan();

	
	String getAmount();
	
	String getDisputeAmount();
	
	String getFraudFg();
	
	
	String getSubCategory();
	
	String getAckNo();
	
	String getTransactionDate();

}
