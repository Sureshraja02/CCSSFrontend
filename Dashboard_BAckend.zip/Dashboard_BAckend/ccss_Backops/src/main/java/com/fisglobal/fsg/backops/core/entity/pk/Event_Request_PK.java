package com.fisglobal.fsg.backops.core.entity.pk;

import java.io.Serializable;

import javax.persistence.Basic;

public class Event_Request_PK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Basic
	private String eventType;

	@Basic
	private String propertyName;

	@Basic
	private String propertyValue;

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

}
