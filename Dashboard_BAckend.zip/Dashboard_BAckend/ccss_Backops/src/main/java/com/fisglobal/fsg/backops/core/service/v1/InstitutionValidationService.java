package com.fisglobal.fsg.backops.core.service.v1;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.Error;
import com.fisglobal.fsg.backops.core.common.ErrorDetails;
import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.data.v1.InstitutionData;
import com.fisglobal.fsg.backops.core.entity.repo.RMSErrorRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;

@Service
public class InstitutionValidationService {

	@Inject
	private RMSErrorRepo errorRepo;

	public ErrorDetails validateInstitutionData(InstitutionData instRequest) {
		ErrorDetails errorDetails = new ErrorDetails();
		List<Error> errorList = new ArrayList<Error>();


		if (StringUtils.isBlank(instRequest.getAppDangerColor())) {
			errorList.add(new Error(RMSConstants.appDangerColorCode,
					errorRepo.findById(RMSConstants.appDangerColorCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getAppInfoColor())) {
			errorList.add(new Error(RMSConstants.appInfoColorCode,
					errorRepo.findById(RMSConstants.appInfoColorCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getAppSuccessColor())) {
			errorList.add(new Error(RMSConstants.appSuccessColorCode,
					errorRepo.findById(RMSConstants.appSuccessColorCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getAppWarningColor())) {
			errorList.add(new Error(RMSConstants.appWarningColorCode,
					errorRepo.findById(RMSConstants.appWarningColorCode).get().getErrorDesc()));
		}


		if (StringUtils.isBlank(instRequest.getOrgLogo())) {
			errorList.add(new Error(RMSConstants.orgLogoCode,
					errorRepo.findById(RMSConstants.orgLogoCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getOrgName())) {
			errorList.add(new Error(RMSConstants.orgNameCode,
					errorRepo.findById(RMSConstants.orgNameCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getOrgPrimaryColor())) {
			errorList.add(new Error(RMSConstants.orgPrimaryColorCode,
					errorRepo.findById(RMSConstants.orgPrimaryColorCode).get().getErrorDesc()));
		}

		if (StringUtils.isBlank(instRequest.getOrgSecondaryColor())) {
			errorList.add(new Error(RMSConstants.orgSecondaryColorCode,
					errorRepo.findById(RMSConstants.orgSecondaryColorCode).get().getErrorDesc()));
		}

		errorDetails.setErrorList(errorList);

		return errorDetails;
	}
}
