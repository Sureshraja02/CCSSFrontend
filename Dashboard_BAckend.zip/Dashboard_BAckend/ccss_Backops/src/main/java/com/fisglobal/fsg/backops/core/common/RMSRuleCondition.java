package com.fisglobal.fsg.backops.core.common;

import java.util.List;

public class RMSRuleCondition {

	private List<RuleExpression> ruleExpression;

	public List<RuleExpression> getRuleExpression() {
		return ruleExpression;
	}

	public void setRuleExpression(List<RuleExpression> ruleExpression) {
		this.ruleExpression = ruleExpression;
	}

}
