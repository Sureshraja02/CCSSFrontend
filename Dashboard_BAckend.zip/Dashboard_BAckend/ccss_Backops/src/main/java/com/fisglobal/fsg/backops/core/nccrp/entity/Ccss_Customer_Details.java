package com.fisglobal.fsg.backops.core.nccrp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_CUSTOMER_DETAILS")
@Entity
public class Ccss_Customer_Details {

	@Id
	@Column(name = "ID")
	private String Id;

	@Column(name = "CUSTOMER_NO")
	private String customerNo;

	@Column(name = "NAME1")
	private String Name1;
	

	@Column(name = "MOBILE_NO")
	private String mobileNo;

	@Column(name = "CUSTOMER_STATUS")
	private String customerStatus;
	

	@Column(name = "CUST_TAX_PAN")
	private String custTaxPan;


	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}


	/**
	 * @return the customerNo
	 */
	public String getCustomerNo() {
		return customerNo;
	}


	/**
	 * @param customerNo the customerNo to set
	 */
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}


	/**
	 * @return the name1
	 */
	public String getName1() {
		return Name1;
	}


	/**
	 * @param name1 the name1 to set
	 */
	public void setName1(String name1) {
		Name1 = name1;
	}


	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}


	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	/**
	 * @return the customerStatus
	 */
	public String getCustomerStatus() {
		return customerStatus;
	}


	/**
	 * @param customerStatus the customerStatus to set
	 */
	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}


	/**
	 * @return the custTaxPan
	 */
	public String getCustTaxPan() {
		return custTaxPan;
	}


	/**
	 * @param custTaxPan the custTaxPan to set
	 */
	public void setCustTaxPan(String custTaxPan) {
		this.custTaxPan = custTaxPan;
	}

	
	
	
	
	

}
