package com.fisglobal.fsg.backops.core.nccrp.data;

public interface DashboardInterface {

	String getFully_failed();
	
	String getFully_procees();
	
	String getPartial_processed();
	
	String getRecordNoFound();
	
	String getAckNumber();
	
	String getRrn();
	
	String getEntryDate();
	
	String getAccountNo();
	
	String getFully_success();
	
	String getPartial_success();
	
	String getComplaint_date();
	
	String getTotal_ack();
	
	String getHoldValue();
	
	String getDisputedAmount();
	
	String getMobileNo();
	
	String getAcknowlegementNo();
	
	String getComplaintRrn();
	
	String getAmount();
	
	String getTxnDate();

	String getTxnTime();
	
	String getStatus();

	String getReason();
	 
}
