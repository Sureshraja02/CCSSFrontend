/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.fileupload.data;

/**
 * @author e5745290
 *
 */
public class DownloadRequestData {

	private String downloadType;
	
	private String fromDate;
	
	private String toDate;

	/**
	 * @return the downloadType
	 */
	public String getDownloadType() {
		return downloadType;
	}

	/**
	 * @param downloadType the downloadType to set
	 */
	public void setDownloadType(String downloadType) {
		this.downloadType = downloadType;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
	
	
}
