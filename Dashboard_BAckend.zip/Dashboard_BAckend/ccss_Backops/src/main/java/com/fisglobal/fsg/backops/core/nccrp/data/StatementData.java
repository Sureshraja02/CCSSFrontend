/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class StatementData {
	
	private String transaction_Data;
	
	private String tranAmount;
	
	private String tranType;
	
	private String balance;
	
	private	String txn_Ref_No;
	
	private String channel;
	
	private String beneRemiAccNum;
	
	private String beneRemiIfsc;
	
	private String transactionTime;
	
	private String narration;

	/**
	 * @return the transaction_Data
	 */
	public String getTransaction_Data() {
		return transaction_Data;
	}

	/**
	 * @param transaction_Data the transaction_Data to set
	 */
	public void setTransaction_Data(String transaction_Data) {
		this.transaction_Data = transaction_Data;
	}

	/**
	 * @return the tranAmount
	 */
	public String getTranAmount() {
		return tranAmount;
	}

	/**
	 * @param tranAmount the tranAmount to set
	 */
	public void setTranAmount(String tranAmount) {
		this.tranAmount = tranAmount;
	}

	/**
	 * @return the tranType
	 */
	public String getTranType() {
		return tranType;
	}

	/**
	 * @param tranType the tranType to set
	 */
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}

	/**
	 * @return the txn_Ref_No
	 */
	public String getTxn_Ref_No() {
		return txn_Ref_No;
	}

	/**
	 * @param txn_Ref_No the txn_Ref_No to set
	 */
	public void setTxn_Ref_No(String txn_Ref_No) {
		this.txn_Ref_No = txn_Ref_No;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the beneRemiAccNum
	 */
	public String getBeneRemiAccNum() {
		return beneRemiAccNum;
	}

	/**
	 * @param beneRemiAccNum the beneRemiAccNum to set
	 */
	public void setBeneRemiAccNum(String beneRemiAccNum) {
		this.beneRemiAccNum = beneRemiAccNum;
	}

	/**
	 * @return the beneRemiIfsc
	 */
	public String getBeneRemiIfsc() {
		return beneRemiIfsc;
	}

	/**
	 * @param beneRemiIfsc the beneRemiIfsc to set
	 */
	public void setBeneRemiIfsc(String beneRemiIfsc) {
		this.beneRemiIfsc = beneRemiIfsc;
	}

	/**
	 * @return the transactionTime
	 */
	public String getTransactionTime() {
		return transactionTime;
	}

	/**
	 * @param transactionTime the transactionTime to set
	 */
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	/**
	 * @return the narration
	 */
	public String getNarration() {
		return narration;
	}

	/**
	 * @param narration the narration to set
	 */
	public void setNarration(String narration) {
		this.narration = narration;
	}
	
	
	
	 

}
