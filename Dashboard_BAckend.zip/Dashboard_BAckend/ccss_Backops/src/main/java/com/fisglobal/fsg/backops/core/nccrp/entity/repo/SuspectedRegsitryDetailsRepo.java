package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.SuspectrRegistryDetails_DAO;

public interface SuspectedRegsitryDetailsRepo extends JpaRepository<SuspectrRegistryDetails_DAO, String> {

	
}
