package com.fisglobal.fsg.backops.core.common;

public class SuspectedChain {
	private String remitter;
	private String txnId;
	private String benificary;
	private Boolean demograhic;
	private String txnDate;

	public String getRemitter() {
		return remitter;
	}

	public void setRemitter(String remitter) {
		this.remitter = remitter;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getBenificary() {
		return benificary;
	}

	public void setBenificary(String benificary) {
		this.benificary = benificary;
	}

	public Boolean getDemograhic() {
		return demograhic;
	}

	public void setDemograhic(Boolean demograhic) {
		this.demograhic = demograhic;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

}
