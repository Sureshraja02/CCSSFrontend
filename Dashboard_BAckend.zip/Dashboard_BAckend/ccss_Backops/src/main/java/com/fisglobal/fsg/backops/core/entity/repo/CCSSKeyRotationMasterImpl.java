package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.fisglobal.fsg.backops.core.entity.CCSSKeyRotationMaster_DAO;

@Repository
public class CCSSKeyRotationMasterImpl {

	@PersistenceContext
	EntityManager em;
	
	public CCSSKeyRotationMaster_DAO getRotationMasterDataDAO(String paramStatus, String id) {
		CriteriaBuilder cb = null;
		CriteriaQuery<CCSSKeyRotationMaster_DAO> cq =null;
		List<Predicate> predicates = null;
		Root<CCSSKeyRotationMaster_DAO> rootBk = null;
		try {
			cb = em.getCriteriaBuilder();
			cq = cb.createQuery(CCSSKeyRotationMaster_DAO.class);
			predicates = new ArrayList<Predicate>();
			
			rootBk = cq.from(CCSSKeyRotationMaster_DAO.class);
			predicates.add(cb.equal(rootBk.get("id"), id));
			//predicates.add(cb.equal(rootBk.get("keyAlias"), paramKeyAlias));
			predicates.add(cb.equal(rootBk.get("status"), paramStatus));
			cq.where(predicates.toArray(new Predicate[] {}));
			TypedQuery<CCSSKeyRotationMaster_DAO> query = em.createQuery(cq);
			return query.getSingleResult();

		} catch(Exception e) {
			return null;
		} finally {
			cb = null; cq = null;predicates = null;rootBk=null;
		}
	}
}
