package com.fisglobal.fsg.backops.core.utils;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fisglobal.fsg.backops.core.config.RouterMQConfiguration;
import com.fisglobal.fsg.backops.core.crypto.DecryptionUtils;
import com.fisglobal.fsg.backops.core.crypto.EncryptionUtils;


@Component
public class CommonUtils {
	private final static Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);
	
	
	
	@Autowired
	EncryptionUtils cncryptionUtils;
	
	@Autowired
	DecryptionUtils decryptionUtils;
	



	
	
	
	public String toEncryptData(String encDecValue, String type) {
		String encDate = null;
		try {
			if (StringUtils.isNotBlank(encDecValue)) {
				if (RouterMQConfiguration.rotationkeyMstrDaoPub != null && StringUtils.isNotBlank(type)
						&& type.equalsIgnoreCase("ENC") && StringUtils.isNotBlank(encDecValue)) {
				
						encDate = cncryptionUtils.encryption256(encDecValue, RouterMQConfiguration.rotationkeyMstrDaoPub.getEncKey(),
								RouterMQConfiguration.rotationkeyMstrDaoPub.getSaltKey());
					
				} else if (RouterMQConfiguration.rotationkeyMstrDaoPub != null && StringUtils.isNotBlank(type)
						&& type.equalsIgnoreCase("DEC") && StringUtils.isNotBlank(encDecValue)) {
					
						encDate = new DecryptionUtils().decrypt256(encDecValue,
								RouterMQConfiguration.rotationkeyMstrDaoPub.getEncKey(),
								RouterMQConfiguration.rotationkeyMstrDaoPub.getSaltKey());
					
				} else {
					encDate = encDecValue;
				}
			} else {
				encDate = encDecValue;
			}
		} catch (Exception e) {
			encDate = encDecValue;
		}
		return encDate;
	}
	public static boolean isEncrypted(String str) {
		// Regular expression for base64 encoded strings
		// String base64Pattern = "^[A-Za-z0-9+/=]+$";
		String regex = ".*[^a-zA-Z0-9].*";
		return Pattern.matches(regex, str);
	}
	
	
	
	
	
}
