package com.fisglobal.fsg.backops.core.controller.v1;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.NCCRPDashBoard;
import com.fisglobal.fsg.backops.core.data.v1.ChangePasswordResponse;
import com.fisglobal.fsg.backops.core.entity.NccrpRegistration;
import com.fisglobal.fsg.backops.core.entity.repo.NccrptxnRepo;
import com.fisglobal.fsg.backops.core.service.v1.NccrpService;

@RestController
@RequestMapping(value = "/app/rest/v1.0/service/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class NccrpController {

	@Inject
	private NccrptxnRepo nccrpRepo;

	@Inject
	private NccrpService nccrpService;

	@RequestMapping(value = "dashboard", method = RequestMethod.GET)
	public ResponseEntity<?> dashboard() {
		NCCRPDashBoard dashBoard = new NCCRPDashBoard();
		return new ResponseEntity<>(nccrpService.getNccrpDashboard(), HttpStatus.OK);
	}

	@RequestMapping(value = "suspectedChain/{mobileno}", method = RequestMethod.GET)
	public ResponseEntity<?> suspected(@PathVariable String mobileno) {

		return new ResponseEntity<>(nccrpService.getSuspectedList(mobileno), HttpStatus.OK);
	}

	@RequestMapping(value = "account/{mobileno}", method = RequestMethod.GET)
	public ResponseEntity<?> accounts(@PathVariable String mobileno) {

		return new ResponseEntity<>(nccrpService.getAccounts(mobileno), HttpStatus.OK);
	}

	@RequestMapping(value = "nccrp/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getNccrp(@PathVariable int pageSize, @PathVariable int page) {
		return new ResponseEntity<>(nccrpService.getNccrpComplaints(pageSize, page), HttpStatus.OK);
	}

	@RequestMapping(value = "save/nccrp", method = RequestMethod.POST)
	public ResponseEntity<?> saveNccrp(@RequestBody NccrpRegistration request) {
		nccrpService.saveNCCRP(request);	
		return new ResponseEntity<>("Success", HttpStatus.OK);
	}

}
