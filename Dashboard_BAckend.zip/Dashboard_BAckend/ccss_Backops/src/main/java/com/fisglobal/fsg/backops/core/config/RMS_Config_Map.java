package com.fisglobal.fsg.backops.core.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fisglobal.fsg.backops.core.entity.RMS_Config;
import com.fisglobal.fsg.backops.core.entity.repo.RMSConfigRepo;

@Component
public class RMS_Config_Map {

	private static final Logger LOGGER = LoggerFactory.getLogger(RMS_Config_Map.class);

	public HashMap<String, String> rmsConfigMap = new HashMap<String, String>();

	@Inject
	private RMSConfigRepo rmsConfigRepo;

	@PostConstruct
	public void loadMap() {
		LOGGER.info("Loading Application Config");
		List<RMS_Config> getlist = rmsConfigRepo.getModules();

		for (RMS_Config rmsConfig : getlist) {
			LOGGER.info("Rms config into list : [{}]: [{}]", rmsConfig.getId(), rmsConfig.getPropertyValue());
			rmsConfigMap.put(String.valueOf(rmsConfig.getId()), String.valueOf(rmsConfig.getPropertyValue()));
		}
		LOGGER.info("Application Config loaded.[{}]", rmsConfigMap.size());

		LOGGER.info("Config Datas [{}]", Arrays.asList(rmsConfigMap));

		LOGGER.info("Sample Test[{}]", rmsConfigMap.get("2"));
	}
}
