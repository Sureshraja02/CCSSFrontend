package com.fisglobal.fsg.backops.core.service.v1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.AccountList;
import com.fisglobal.fsg.backops.core.common.Accounts;
import com.fisglobal.fsg.backops.core.common.Atm;
import com.fisglobal.fsg.backops.core.common.Ib;
import com.fisglobal.fsg.backops.core.common.Mb;
import com.fisglobal.fsg.backops.core.common.NCCRPDashBoard;
import com.fisglobal.fsg.backops.core.common.Pos;
import com.fisglobal.fsg.backops.core.common.StatusCount;
import com.fisglobal.fsg.backops.core.common.SuspectedChain;
import com.fisglobal.fsg.backops.core.common.SuspectedChainList;
import com.fisglobal.fsg.backops.core.common.TxnsCount;
import com.fisglobal.fsg.backops.core.common.Values;
import com.fisglobal.fsg.backops.core.entity.Instid_Master;
import com.fisglobal.fsg.backops.core.entity.NccrpAcc;
import com.fisglobal.fsg.backops.core.entity.NccrpRegistration;
import com.fisglobal.fsg.backops.core.entity.Nccrptxn;
import com.fisglobal.fsg.backops.core.entity.repo.NccrpAccint;
import com.fisglobal.fsg.backops.core.entity.repo.NccrpRegRepo;
import com.fisglobal.fsg.backops.core.entity.repo.NccrptxnRepo;

@Service
public class NccrpService {

	@Inject
	private NccrptxnRepo nccrpRepo;

	@Inject
	private NccrpRegRepo nccrpReg;

	@Inject
	private NccrpService nccrpService;

	@Inject
	private NccrpAccint nccrpAcc;
	
	public void saveNCCRP(NccrpRegistration request) {
		nccrpReg.save(request);
	}
	
	public Page<NccrpRegistration> getNccrpComplaints(int pageSize,int pageNo) {
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<NccrpRegistration> regList = nccrpReg.findAll(paging);
		return regList;
	}

	public Accounts getAccounts(String mobileNumber) {
		List<NccrpAcc> acclist = nccrpAcc.findAll();
		Accounts accs = new Accounts();
		List<AccountList> list = new ArrayList<AccountList>();
		for (NccrpAcc acc : acclist) {
			AccountList acclists = new AccountList();
			acclists.setAccountNo(acc.getAccountNo());
			acclists.setAccoutType(acc.getAccountType());
			acclists.setClick(true);
			acclists.setCurrentAmount(acc.getCurrentAmt());
			acclists.setStatus(acc.getStatus());
			list.add(acclists);
		}

		accs.setAccountList(list);

		return accs;
	}

	public SuspectedChainList getSuspectedList(String mobileNumber) {
		List<Nccrptxn> txnList = nccrpRepo.findAll();

		List<Nccrptxn> newlist = txnList.stream().distinct().collect(Collectors.toList());

		HashMap<String, String> map = new HashMap<String, String>();

		for (Nccrptxn txn : newlist) {
			map.put(txn.getPayerAddr(), txn.getPayerAddr());
			map.put(txn.getPayeeAddr(), txn.getPayeeAddr());
		}

		List<String> txnLists = map.values().stream().collect(Collectors.toList());

		SuspectedChainList list = new SuspectedChainList();
		List<SuspectedChain> listChain = new ArrayList<SuspectedChain>();
		for (Nccrptxn txn : newlist) {
			SuspectedChain chain = new SuspectedChain();
			String key = txn.getPayerAddr() + "|" + txn.getPayeeAddr();
			chain.setRemitter(txn.getPayerAddr());
			chain.setBenificary(txn.getPayeeAddr());
			chain.setDemograhic(true);
			if (map.containsKey(key)) {

			} else {
				listChain.add(chain);
				map.put(key, key);
			}

		}
		list.setChain(listChain);
		return list;
	}

	public NCCRPDashBoard getNccrpDashboard() {
		NCCRPDashBoard dashBoard = new NCCRPDashBoard();
		TxnsCount txnCount = new TxnsCount();
		StatusCount statusCount = new StatusCount();
		Values values = new Values();

		Atm amt = new Atm();
		Pos pos = new Pos();
		Ib ib = new Ib();
		Mb mb = new Mb();

		List<String> monthlyTxnCount = new ArrayList<String>();
		List<String> monthlyTxnDate = new ArrayList<String>();

		monthlyTxnDate.add("Jan");
		monthlyTxnDate.add("Feb");
		monthlyTxnDate.add("Mar");
		monthlyTxnDate.add("Apr");
		monthlyTxnDate.add("May");
		monthlyTxnDate.add("Jun");
		monthlyTxnDate.add("Jul");
		monthlyTxnDate.add("Aug");
		monthlyTxnDate.add("Sep");
		monthlyTxnDate.add("Oct");
		monthlyTxnDate.add("Nov");
		monthlyTxnDate.add("Dec");

		monthlyTxnCount.add("300");
		monthlyTxnCount.add("50");
		monthlyTxnCount.add("100");
		monthlyTxnCount.add("500");
		monthlyTxnCount.add("300");
		monthlyTxnCount.add("700");
		monthlyTxnCount.add("200");
		monthlyTxnCount.add("800");
		monthlyTxnCount.add("200");
		monthlyTxnCount.add("1000");

		List<Nccrptxn> nccrpList = nccrpRepo.findAll();

		List<NccrpRegistration> regList = nccrpReg.findAll();
		
		//List<Nccrptxn> freezeAcc = nccrpAcc.freezeAcc();

		int totalSize = nccrpList.size();

		dashBoard.setCompliantsReceived(String.valueOf(regList.size()));
		dashBoard.setTotalTxns(String.valueOf(nccrpList.size()));
		dashBoard.setFreezedAccounts("1");
		dashBoard.setTotalSuspeciousTxns(String.valueOf(
				nccrpList.stream().filter(e -> e.getStatus().equals("CHALLENGE")).collect(Collectors.toList()).size()));

		txnCount.setCount(monthlyTxnCount);
		txnCount.setDate(monthlyTxnDate);

		dashBoard.setTxnsCount(txnCount);
		
		int successCnt = nccrpList.stream().filter(e -> e.getStatus().equals("SUCCESS")).collect(Collectors.toList()).size();
		int failurCnt = nccrpList.stream().filter(e -> e.getStatus().equals("FAILURE")).collect(Collectors.toList()).size();
		int chanllengeCnt = nccrpList.stream().filter(e -> e.getStatus().equals("CHALLENGE")).collect(Collectors.toList()).size(); 
		
		float successPer = Math.round(successCnt * 100 / totalSize);
		float failPer = Math.round(failurCnt * 100 / totalSize);
		float challengePer = Math.round(chanllengeCnt * 100 / totalSize);
		
		//statusCount.setSuccess(String.valueOf(successPer));
		//statusCount.setFailure(String.valueOf(failPer));
				
//		statusCount.setChallenge(String.valueOf(challengePer
//				));
		dashBoard.setStatusCount(statusCount);

		int amtCount = nccrpList.stream().filter(e -> e.getChannel().equals("ATM")).collect(Collectors.toList()).size();
		float amtPer = Math.round(amtCount * 100 / totalSize);

		// Math.round(x * 100.0/total)

		int posCount = nccrpList.stream().filter(e -> e.getChannel().equals("POS")).collect(Collectors.toList()).size();
		float posPer = Math.round(posCount * 100 / totalSize);

		System.out.println("posCount->" + posCount);
		System.out.println("posPer->" + posPer);

		int ibCount = nccrpList.stream().filter(e -> e.getChannel().equals("IB")).collect(Collectors.toList()).size();
		int ibPer = Math.round(ibCount * 100 / totalSize);

		System.out.println("ibCount->" + ibCount);
		System.out.println("ibPer->" + ibPer);

		int mbCount = nccrpList.stream().filter(e -> e.getChannel().equals("MB")).collect(Collectors.toList()).size();
		int mbPer = Math.round(mbCount * 100 / totalSize);

		System.out.println("mbCount->" + mbCount);
		System.out.println("mbPer->" + mbPer);

		amt.setCount(String.valueOf(amtCount));
		amt.setPercentage(String.valueOf(amtPer));
		pos.setCount(String.valueOf(posCount));
		pos.setPercentage(String.valueOf(posPer));
		ib.setCount(String.valueOf(ibCount));
		ib.setPercentage(String.valueOf(ibPer));
		mb.setCount(String.valueOf(mbCount));
		mb.setPercentage(String.valueOf(mbPer));

		dashBoard.setAtm(amt);
		dashBoard.setPos(pos);
		dashBoard.setIb(ib);
		dashBoard.setMb(mb);

		int atmsuccess = nccrpList.stream().filter(e -> e.getChannel().equals("ATM"))
				.filter(e -> e.getStatus().equals("SUCCESS")).collect(Collectors.toList()).size();
		int possuccess = nccrpList.stream().filter(e -> e.getChannel().equals("POS"))
				.filter(e -> e.getStatus().equals("SUCCESS")).collect(Collectors.toList()).size();
		int ibsuccess = nccrpList.stream().filter(e -> e.getChannel().equals("IB"))
				.filter(e -> e.getStatus().equals("SUCCESS")).collect(Collectors.toList()).size();
		int mbsuccess = nccrpList.stream().filter(e -> e.getChannel().equals("MB"))
				.filter(e -> e.getStatus().equals("SUCCESS")).collect(Collectors.toList()).size();

		int atmsuccessper = 0;
		int possuccessper = 0;
		int ibsuccessper = 0;
		int mbsuccessper = 0;

		System.out.println(atmsuccess + "==" + amtCount);

		if (atmsuccess > 0) {
			atmsuccessper = Math.round(atmsuccess * 100 / amtCount);
		}
		if (possuccess > 0) {
			possuccessper = Math.round(possuccess * 100 / posCount);
		}
		if (ibsuccess > 0) {
			ibsuccessper = Math.round(ibsuccess * 100 / ibCount);
		}
		if (mbsuccess > 0) {
			mbsuccessper = Math.round(mbsuccess * 100 / mbCount);
		}

		values.setAtm(String.valueOf(atmsuccessper));
		values.setPos(String.valueOf(possuccessper));
		values.setMb(String.valueOf(mbsuccessper));
		values.setIb(String.valueOf(ibsuccessper));

		dashBoard.setValues(values);

		return dashBoard;
	}
}
