/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class ChannelStatisticsData {

	    private String success;
	
	    private String failure;
	
	    private String totalCount;
	    
	    private String txnType;
	    
	    private String pending;

		/**
		 * @return the success
		 */
		public String getSuccess() {
			return success;
		}

		/**
		 * @param success the success to set
		 */
		public void setSuccess(String success) {
			this.success = success;
		}

		/**
		 * @return the failure
		 */
		public String getFailure() {
			return failure;
		}

		/**
		 * @param failure the failure to set
		 */
		public void setFailure(String failure) {
			this.failure = failure;
		}

		/**
		 * @return the totalCount
		 */
		public String getTotalCount() {
			return totalCount;
		}

		/**
		 * @param totalCount the totalCount to set
		 */
		public void setTotalCount(String totalCount) {
			this.totalCount = totalCount;
		}

		/**
		 * @return the txnType
		 */
		public String getTxnType() {
			return txnType;
		}

		/**
		 * @param txnType the txnType to set
		 */
		public void setTxnType(String txnType) {
			this.txnType = txnType;
		}

		/**
		 * @return the pending
		 */
		public String getPending() {
			return pending;
		}

		/**
		 * @param pending the pending to set
		 */
		public void setPending(String pending) {
			this.pending = pending;
		}
	    
	    
}
