package com.fisglobal.fsg.backops.core.nccrp.fileupload;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.ComplaintRequestData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.service.FileStorageService;

@RestController
@RequestMapping("/api/files")
@CrossOrigin
public class SuspectedRepositoryFileUploadController {

	private final FileStorageService fileStorageService;

    @Autowired
    public SuspectedRepositoryFileUploadController(FileStorageService fileStorageService) {
        this.fileStorageService = fileStorageService;
    }

  
    @RequestMapping(value="/suspectrepoupload", 
    method=RequestMethod.POST,
    produces=MediaType.APPLICATION_JSON_VALUE,
    consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
 public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) throws InvalidFormatException {
      
    	
    	String fileName = fileStorageService.storeFile(file);
    	
    	
        return ResponseEntity.ok("File uploaded successfully: " + fileName);
    }
}
