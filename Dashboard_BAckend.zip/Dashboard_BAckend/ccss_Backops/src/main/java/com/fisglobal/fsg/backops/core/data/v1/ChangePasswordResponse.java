package com.fisglobal.fsg.backops.core.data.v1;

public class ChangePasswordResponse {

	private String status;

	private String errorcode;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

}
