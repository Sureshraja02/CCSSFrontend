package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(Include.NON_NULL)
public class Instrument  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Schema(required = true, description = "Requestor", example = "I4C-MHA")
	private String requestor;
	@Schema(required = true, description = "Payer Bank", example = "Central Bank of India")
	private String payer_bank;
	@Schema(required = true, description = "Payer Bank Code", example = "1")
	private Integer payer_bank_code;
	@Schema(required = true, description = "Mode Of Payment", example = "E-Wallet")
	private String mode_of_payment;
	@Schema(required = true, description = "Payer Mobile NUmber", example = "919798868768")
	private String payer_mobile_number;
	@Schema(required = true, description = "Payer Account NUmber", example = "9987868786777")
	private String payer_account_number;
	@Schema(required = true, description = "State Of the INDIA", example = "DELHI")
	private String state;
	@Schema(required = true, description = "District Of the INDIA", example = "South Delhi")
	private String district;
	@Schema(required = false, description = "Transaction Type", example = "14")
	private String transaction_type;
	@Schema(required = true, description = "Wallet", example = "Phonepe")
	private String wallet;
	@Schema(required = true, description = "incidents JSON Array")
	private List<Incidents> incidents;

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getPayer_bank() {
		return payer_bank;
	}

	public void setPayer_bank(String payer_bank) {
		this.payer_bank = payer_bank;
	}

	public Integer getPayer_bank_code() {
		return payer_bank_code;
	}

	public void setPayer_bank_code(Integer payer_bank_code) {
		this.payer_bank_code = payer_bank_code;
	}

	public String getMode_of_payment() {
		return mode_of_payment;
	}

	public void setMode_of_payment(String mode_of_payment) {
		this.mode_of_payment = mode_of_payment;
	}

	public String getPayer_mobile_number() {
		return payer_mobile_number;
	}

	public void setPayer_mobile_number(String payer_mobile_number) {
		this.payer_mobile_number = payer_mobile_number;
	}

	public String getPayer_account_number() {
		return payer_account_number;
	}

	public void setPayer_account_number(String payer_account_number) {
		this.payer_account_number = payer_account_number;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public List<Incidents> getIncidents() {
		return incidents;
	}

	public void setIncidents(List<Incidents> incidents) {
		this.incidents = incidents;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getWallet() {
		return wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
}
