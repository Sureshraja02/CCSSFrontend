package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_REQ_AUDIT")
@Entity
@DynamicUpdate
public class CCSS_REQ_Audit_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "AUDITIDSEQ", sequenceName = "AUDITIDSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Column(name = "JOBID")
	private String jobId;

	@Column(name = "RRN")
	private String rrn;
	
	@Column(name = "SUB_CATEGORY")
	private String subCategory;
	
	@Column(name = "REQUESTOR")
	private String requestor;
	
	@Column(name = "PAYER_BANK")
	private String payerBank;
	
	@Column(name = "PAYER_BANK_CODE")
	private Integer payerBankCode;
	
	@Column(name = "PAYER_MOBILE_NUMBER")
	private String payerMobileNumber;
	
	@Column(name = "PAYER_ACCOUNT_NUMBER")
	private String payerAccountNumber;
	
	@Column(name = "LAYER")
	private String layer;
	
	@Column(name = "STATE")
	private String state;

	@Column(name = "DISTRICT")
	private String district;
	
	@Column(name = "AMOUNT")
	private BigDecimal amount;

	@Column(name = "DISPUTED_AMOUNT")
	private BigDecimal disputedAmount;
	
	@Column(name = "TRANSACTION_TYPE")
	private String transType;
	
	@Column(name = "MODE_OF_PAYMENT")
	private String modeOfPayment;
	
	@Column(name = "TRANSACTION_DATE")
	private String transDate;

	@Column(name = "TRANSACTION_TIME")
	private String transTIme;

	@Column(name = "WALLET")
	private String wallet;
	
	@Column(name = "FIRST_6_DIGIT")
	private String first6Digit;

	@Column(name = "LAST_4_DIGIT")
	private String last4Digit;

	@Column(name = "CARD_LENGTH")
	private String cardLength;
	
	@Column(name = "ENTRY_DATE")
	private Timestamp entryDate;
	
	@Column(name = "ENTRY_BY")
	private String entryBy;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "FULLY_SUCCESS")
	private Integer fullySuccess;

	@Column(name = "PARTIAL_SUCCESS")
	private Integer patialSuccess;

	@Column(name = "FULLY_FAILED")
	private Integer fullyFailed;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "RETRY_COUNT")
	private Integer retryCount;
	
	@Column(name = "STATUS_REASON")
	private String statusReason;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransTIme() {
		return transTIme;
	}

	public void setTransTIme(String transTIme) {
		this.transTIme = transTIme;
	}

	
	
	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getDisputedAmount() {
		return disputedAmount;
	}

	public void setDisputedAmount(BigDecimal disputedAmount) {
		this.disputedAmount = disputedAmount;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Timestamp getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Timestamp entryDate) {
		this.entryDate = entryDate;
	}

	
	public Integer getFullySuccess() {
		return fullySuccess;
	}

	public void setFullySuccess(Integer fullySuccess) {
		this.fullySuccess = fullySuccess;
	}

	public Integer getPatialSuccess() {
		return patialSuccess;
	}

	public void setPatialSuccess(Integer patialSuccess) {
		this.patialSuccess = patialSuccess;
	}

	public Integer getFullyFailed() {
		return fullyFailed;
	}

	public void setFullyFailed(Integer fullyFailed) {
		this.fullyFailed = fullyFailed;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getPayerBank() {
		return payerBank;
	}

	public void setPayerBank(String payerBank) {
		this.payerBank = payerBank;
	}

	public Integer getPayerBankCode() {
		return payerBankCode;
	}

	public void setPayerBankCode(Integer payerBankCode) {
		this.payerBankCode = payerBankCode;
	}

	public String getPayerMobileNumber() {
		return payerMobileNumber;
	}

	public void setPayerMobileNumber(String payerMobileNumber) {
		this.payerMobileNumber = payerMobileNumber;
	}

	public String getPayerAccountNumber() {
		return payerAccountNumber;
	}

	public void setPayerAccountNumber(String payerAccountNumber) {
		this.payerAccountNumber = payerAccountNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public String getWallet() {
		return wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public String getFirst6Digit() {
		return first6Digit;
	}

	public void setFirst6Digit(String first6Digit) {
		this.first6Digit = first6Digit;
	}

	public String getLast4Digit() {
		return last4Digit;
	}

	public void setLast4Digit(String last4Digit) {
		this.last4Digit = last4Digit;
	}

	public String getCardLength() {
		return cardLength;
	}

	public void setCardLength(String cardLength) {
		this.cardLength = cardLength;
	}

	public String getEntryBy() {
		return entryBy;
	}

	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	public String getStatusReason() {
		return statusReason;
	}

	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}
	
}
