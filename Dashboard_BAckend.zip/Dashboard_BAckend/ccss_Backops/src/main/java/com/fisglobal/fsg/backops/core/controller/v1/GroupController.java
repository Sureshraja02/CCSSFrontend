package com.fisglobal.fsg.backops.core.controller.v1;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.GroupBean;
import com.fisglobal.fsg.backops.core.common.GrpRequestList;
import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.entity.Group_Master;
import com.fisglobal.fsg.backops.core.entity.Instid_Master;
import com.fisglobal.fsg.backops.core.entity.repo.GroupRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.AuthTokenService;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@Api(tags = "User Roles", description = "Assign Application Roles To User")
@RestController
@RequestMapping(value = "/app/rest/v1.0/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class GroupController {
	private static final Logger LOGGER = LoggerFactory.getLogger(GroupController.class);

	@Inject
	private GroupRepo groupRepo;

	@Inject
	private PaginationService paginationService;
	
	@Inject
	private AuthTokenService tokenService;

	@RequestMapping(value = "fetch/group/{groupid}", method = RequestMethod.GET)
	public ResponseEntity<?> getMenuGrpList(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String groupid, @PathVariable int page) throws Exception {

		RMSResponse response = new RMSResponse();

		Optional<Group_Master> grpDetails = groupRepo.findById(groupid);

		if (!grpDetails.isPresent()) {
			throw new RMSException(RMSConstants.INVALID_GRP_CODE, RMSConstants.INVALID_GRP_MSG);
		}

		return new ResponseEntity<>(grpDetails, HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/group/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getGrpList(@RequestHeader(value = "requestid") String reqId, @PathVariable int pageSize,
			@PathVariable int page) throws Exception {

		RMSResponse response = new RMSResponse();

		Page<Group_Master> pageResult = paginationService.getGrpList(pageSize, page);

		if (!pageResult.hasContent()) {
			throw new RMSException(RMSConstants.INVALID_REQUEST_CODE, RMSConstants.INVALID_REQUEST_MSG);
		}

		return new ResponseEntity<>(pageResult, HttpStatus.OK);
	}

	@RequestMapping(value = "list/group", method = RequestMethod.GET)
	public ResponseEntity<?> getFullGrpList(@RequestHeader(value = "requestid") String reqId) throws Exception {
		List<Group_Master> grpList = groupRepo.getGrpList();
				
		return new ResponseEntity<>(grpList, HttpStatus.OK);
	}

	@RequestMapping(value = "group/save", method = RequestMethod.POST)
	public ResponseEntity<?> saveGrp(@RequestHeader(value = "requestid") String reqId,
			@org.springframework.web.bind.annotation.RequestBody GrpRequestList requestList) throws Exception {
		RMSResponse response = new RMSResponse();
		
		LOGGER.info("Request Messge [{}]",requestList.toString());
		
		List<Group_Master> grpDetails = groupRepo.getGrpDetails(requestList.getGroupName());
		
		if(grpDetails.size() > 0) {
			response.setErrorCode("B-10034");
			response.setStatus("Group Already Exists");
		}
		
		for (GroupBean grpBean : requestList.getGrpList()) {
			Group_Master grp = new Group_Master();
			grp.setGroupName(requestList.getGroupName());
			grp.setGroupId(requestList.getGroupName());
			grp.setTid(grpBean.gettId());
			grp.setMakerId(tokenService.getMakerId());
			grp.setCheckerId(tokenService.getMakerId());
			grp.setInsertedDate(LocalDateTime.now());
			grp.setModifiedDate(LocalDateTime.now());
			groupRepo.save(grp);
		}

		response.setErrorCode(RMSConstants.SUCCESS_CODE);
		response.setStatus(RMSConstants.SUCCESS_MSG);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
}
