package com.fisglobal.fsg.backops.core.nccrp.data;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(Include.NON_NULL)
public class Incidents {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Schema(required = true, description = "Amount of the transaction", example = "210.10")
	private BigDecimal amount;
	@Schema(required = true, description = "RRN -  Transaction identifier", example = "244444444444")
	private String rrn;
	@Schema(required = true, description = "Transaction Date, Format - DD-MM-YYYY", example = "02-01-2023")
	private String transaction_date;
	@Schema(required = true, description = "Transaction Time 24 Hours - 00:00:00, Format - HH:MM:SS", example = "13:20:23")
	private String transaction_time;
	@Schema(required = true, description = "First 6 digits Card Number", example = "423131")
	private String first6digit;
	@Schema(required = true, description = "Last 4 digits Card Number", example = "4231")
	private String last4digit;
	@Schema(required = true, description = "Card Length", example = "17")
	private String cardlength;
	@Schema(required = true, description = "Amount with two decimal places, 35.00", example = "35.00")
	private BigDecimal disputed_amount;
	@Schema(required = true, description = "Layer", example = "0")
	private Integer layer;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}

	public String getTransaction_time() {
		return transaction_time;
	}

	public void setTransaction_time(String transaction_time) {
		this.transaction_time = transaction_time;
	}

	public String getFirst6digit() {
		return first6digit;
	}

	public void setFirst6digit(String first6digit) {
		this.first6digit = first6digit;
	}

	public String getLast4digit() {
		return last4digit;
	}

	public void setLast4digit(String last4digit) {
		this.last4digit = last4digit;
	}

	public String getCardlength() {
		return cardlength;
	}

	public void setCardlength(String cardlength) {
		this.cardlength = cardlength;
	}

	public BigDecimal getDisputed_amount() {
		return disputed_amount;
	}

	public void setDisputed_amount(BigDecimal disputed_amount) {
		this.disputed_amount = disputed_amount;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}
	
}
