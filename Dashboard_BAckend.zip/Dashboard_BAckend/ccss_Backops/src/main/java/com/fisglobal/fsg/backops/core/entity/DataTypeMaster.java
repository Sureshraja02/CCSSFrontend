package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fisglobal.fsg.backops.core.entity.pk.DataType_Master_PK;

@Table(name = "DATATYPE_MASTER")
@Entity
@IdClass(DataType_Master_PK.class)
public class DataTypeMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "DATATYPE_CODE")
	private String dataTypeCode;
	
	@Id
	@Column(name = "DATATYPE_IDX")
	private String idx;
	
	@Column(name = "DATATYPE_DESC")
	private String dataTypeDesc;
	
	@Id
	@Column(name = "ALLOWED_CONDITION")
	private String allowedCondition;

	public String getDataTypeCode() {
		return dataTypeCode;
	}

	public void setDataTypeCode(String dataTypeCode) {
		this.dataTypeCode = dataTypeCode;
	}

	public String getDataTypeDesc() {
		return dataTypeDesc;
	}

	public void setDataTypeDesc(String dataTypeDesc) {
		this.dataTypeDesc = dataTypeDesc;
	}

	public String getAllowedCondition() {
		return allowedCondition;
	}

	public void setAllowedCondition(String allowedCondition) {
		this.allowedCondition = allowedCondition;
	}

}
