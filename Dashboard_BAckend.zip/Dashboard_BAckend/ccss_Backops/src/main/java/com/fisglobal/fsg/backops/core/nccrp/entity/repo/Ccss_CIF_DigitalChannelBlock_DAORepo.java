package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.CCSS_CIF_DigitalChannelBlock_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Callback_Ack_Resp_DAO;

public interface Ccss_CIF_DigitalChannelBlock_DAORepo extends JpaRepository<CCSS_CIF_DigitalChannelBlock_DAO, String> {

	List<CCSS_CIF_DigitalChannelBlock_DAO> findByEntryDateBetween(Date startDate, Date endDate);

}
