/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class TransactionHistoryRequestData {

	private String acknowledgementNo;

	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}
	
	
}
