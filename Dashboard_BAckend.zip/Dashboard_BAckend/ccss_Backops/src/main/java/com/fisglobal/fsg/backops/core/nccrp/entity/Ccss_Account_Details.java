/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_ACCOUNT_DETAILS")
@Entity
public class Ccss_Account_Details {
	
	
		@Id
		@Column(name = "ID")
		private String Id;

		@Column(name = "ACCT_NO")
		private String acct_No;

		@Column(name = "SHORT_NAME")
		private String short_Name;
		
		@Column(name = "CUSTOMER_NO")
		private String costomerNo;		
		
		@Column(name = "ACCT_OPEN_DATE")
		private String acctOpenDate;		
		
		@Column(name = "NOMI_NAME")
		private String nomiName;
		
		@Column(name = "AADHAR_NO")
		private String aadharNo;
		
		@Column(name = "DESCRIPT")
		private String description;
		
		@Column(name = "CURR_STATUS")
		private String currentStatus;
		
		@Column(name = "CURRENCY")
		private String currency;

		/**
		 * @return the id
		 */
		public String getId() {
			return Id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			Id = id;
		}

		/**
		 * @return the acct_No
		 */
		public String getAcct_No() {
			return acct_No;
		}

		/**
		 * @param acct_No the acct_No to set
		 */
		public void setAcct_No(String acct_No) {
			this.acct_No = acct_No;
		}

		/**
		 * @return the short_Name
		 */
		public String getShort_Name() {
			return short_Name;
		}

		/**
		 * @param short_Name the short_Name to set
		 */
		public void setShort_Name(String short_Name) {
			this.short_Name = short_Name;
		}

		/**
		 * @return the costomerNo
		 */
		public String getCostomerNo() {
			return costomerNo;
		}

		/**
		 * @param costomerNo the costomerNo to set
		 */
		public void setCostomerNo(String costomerNo) {
			this.costomerNo = costomerNo;
		}

		

		/**
		 * @return the nomiName
		 */
		public String getNomiName() {
			return nomiName;
		}

		/**
		 * @param nomiName the nomiName to set
		 */
		public void setNomiName(String nomiName) {
			this.nomiName = nomiName;
		}

		/**
		 * @return the aadharNo
		 */
		public String getAadharNo() {
			return aadharNo;
		}

		/**
		 * @param aadharNo the aadharNo to set
		 */
		public void setAadharNo(String aadharNo) {
			this.aadharNo = aadharNo;
		}

		/**
		 * @return the description
		 */
		public String getDescription() {
			return description;
		}

		/**
		 * @param description the description to set
		 */
		public void setDescription(String description) {
			this.description = description;
		}

		/**
		 * @return the currentStatus
		 */
		public String getCurrentStatus() {
			return currentStatus;
		}

		/**
		 * @param currentStatus the currentStatus to set
		 */
		public void setCurrentStatus(String currentStatus) {
			this.currentStatus = currentStatus;
		}

		/**
		 * @return the currency
		 */
		public String getCurrency() {
			return currency;
		}

		/**
		 * @param currency the currency to set
		 */
		public void setCurrency(String currency) {
			this.currency = currency;
		}

		/**
		 * @return the acctOpenDate
		 */
		public String getAcctOpenDate() {
			return acctOpenDate;
		}

		/**
		 * @param acctOpenDate the acctOpenDate to set
		 */
		public void setAcctOpenDate(String acctOpenDate) {
			this.acctOpenDate = acctOpenDate;
		}
		
	
		
		
		
		
	
		

}
