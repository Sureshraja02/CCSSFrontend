package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;


@Table(name = "CCSS_KEY_MASTER")
@Entity
@DynamicUpdate
public class CCSSKeyMaster_DAO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "EMAILIDSEQ", sequenceName = "EMAILIDSEQ", allocationSize = 1)
	private String id;
	
	@Column(name = "CUSTODIAN1")
	private String custodian1;
	
	@Column(name = "KEY1")
	private String key1;
	
	@Column(name = "CUSTODIAN2")
	private String custodian2;
	
	@Column(name = "KEY2")
	private String key2;
		
	@Column(name = "SALTKEY")
	private String saltKey;
	
	@Column(name = "STATUS")
	private Integer	status;
	
	@Column(name = "ROLLOVER_PERIOD")
	private String rolloverPeriod;

	@Column(name = "CREATEDDATE")
	private Date createdDate;

	@Column(name = "UPDATEDDATE")
	private Date updatedDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKey1() {
		return key1;
	}

	public void setKey1(String key1) {
		this.key1 = key1;
	}

	public String getKey2() {
		return key2;
	}

	public void setKey2(String key2) {
		this.key2 = key2;
	}

	
	public String getSaltKey() {
		return saltKey;
	}

	public void setSaltKey(String saltKey) {
		this.saltKey = saltKey;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCustodian1() {
		return custodian1;
	}

	public void setCustodian1(String custodian1) {
		this.custodian1 = custodian1;
	}

	public String getCustodian2() {
		return custodian2;
	}

	public void setCustodian2(String custodian2) {
		this.custodian2 = custodian2;
	}

	public String getRolloverPeriod() {
		return rolloverPeriod;
	}

	public void setRolloverPeriod(String rolloverPeriod) {
		this.rolloverPeriod = rolloverPeriod;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}
