package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.Menu_Master;
import com.fisglobal.fsg.backops.core.entity.pk.Menu_Master_PK;

public interface MenuMasterRepo
		extends JpaRepository<Menu_Master, Menu_Master_PK>, JpaSpecificationExecutor<Menu_Master> {

	@Query(value = "select b.* from group_master a,menu_master b where b.menu_id = a.tid and a.groupid=:grpid and b.sub_menu='false' order by menu_id,parent_menu_id", nativeQuery = true)
	List<Menu_Master> getmenuData(String grpid);

}
