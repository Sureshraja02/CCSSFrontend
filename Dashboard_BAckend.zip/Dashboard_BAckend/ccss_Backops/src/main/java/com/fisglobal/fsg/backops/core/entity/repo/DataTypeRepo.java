package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.DataTypeMaster;
import com.fisglobal.fsg.backops.core.entity.pk.DataType_Master_PK;

public interface DataTypeRepo
		extends JpaRepository<DataTypeMaster, DataType_Master_PK>, JpaSpecificationExecutor<DataTypeMaster> {

	@Query(value = "SELECT * FROM DATATYPE_MASTER WHERE DATATYPE_CODE = ?1 ", nativeQuery = true)
	ArrayList<DataTypeMaster> getDataTypeDetails(String dataType);

}
