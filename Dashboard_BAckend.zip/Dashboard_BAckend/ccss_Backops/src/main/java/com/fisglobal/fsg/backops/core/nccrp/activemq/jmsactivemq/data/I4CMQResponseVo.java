package com.fisglobal.fsg.backops.core.nccrp.activemq.jmsactivemq.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fisglobal.fsg.backops.core.data.v1.BaseDTO;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class I4CMQResponseVo extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String instCode;
	private String acknowledgement_no;
	private String jobId;
	private String pFlag;
	private String middlewareStatus;

	public String getInstCode() {
		return instCode;
	}

	public void setInstCode(String instCode) {
		this.instCode = instCode;
	}

	public String getAcknowledgement_no() {
		return acknowledgement_no;
	}

	public void setAcknowledgement_no(String acknowledgement_no) {
		this.acknowledgement_no = acknowledgement_no;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getpFlag() {
		return pFlag;
	}

	public void setpFlag(String pFlag) {
		this.pFlag = pFlag;
	}

	public String getMiddlewareStatus() {
		return middlewareStatus;
	}

	public void setMiddlewareStatus(String middlewareStatus) {
		this.middlewareStatus = middlewareStatus;
	}

	
}
