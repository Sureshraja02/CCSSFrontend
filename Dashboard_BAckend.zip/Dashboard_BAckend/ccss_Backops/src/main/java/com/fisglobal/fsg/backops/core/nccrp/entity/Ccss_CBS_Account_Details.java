/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_CBS_ACCOUNT_DETAILS")
@Entity
public class Ccss_CBS_Account_Details {
	
	
		@Id
		@Column(name = "ID")
		private String Id;
		
		
		@Column(name = "ACCT_NO")
		private String acct_No;
		
		
		@Column(name = "ACCT_TYPE")
	    private String acct_Type;
	    
		
		@Column(name = "CURR_STATUS")
	    private String curr_Status;
		
		
		@Column(name = "LIS_FIN_DT")
	    private String lis_Fin_Dt;
	    
		
		@Column(name = "INT_CAT")
	    private String int_Cat;
	    
		
		@Column(name = "CUSTOMER_NO")
	    private String customer_No;
		
	
		@Column(name = "ACCT_OPEN_DT")
	    private String acct_Open_Dt;
	    
		
		@Column(name = "EXTN_COUNTER")
	    private String extn_Counter;
	    
		
		@Column(name = "BRANCH_NO")
	    private String branch_No;
		
		
		@Column(name = "ACCT_STMT_CODE")
	    private String acct_Stmt_Code;
	  
		@Column(name = "DESCRIPT")
	    private String descript;
	    
		
		@Column(name = "GL_CLASS_CODE")
	    private String gl_Class_Code;    
	    
		
		@Column(name = "TRAP")
	    private String trap;
	    
		
		@Column(name = "TRF_ACCT_NO")
	    private String trf_Acct_No;
	    
	
		
		@Column(name = "VAR_INT_RATE")
	    private String var_Int_Rate;
		
		
		@Column(name = "AADHAR_NO")
	    private String aadhar_No;
	    
		
		@Column(name = "TERM_DAY")
	    private String term_Day;
	    
		
		@Column(name = "TERM_NO_DAYS")
	    private String term_No_Days;
		
		
		@Column(name = "TERM_BASIS")
	    private String term_Basis;
	    
	
		@Column(name = "TERM_NO_MONTHS")
	    private String term_No_months;
	    
		
		@Column(name = "TERM_VALUES")
	    private String term_Values;
		
		
		@Column(name = "TERM_YEARS")
	    private String term_years;
	    
		
		@Column(name = "MATURITY_DATE")
	    private String maturity_Date;
	    
		
		@Column(name = "TERM_MAT_VAL")
	    private String term_mat_Val;    
	    
		
		@Column(name = "TERM_PAY_FREQUENCY")
	    private String term_Pay_Frequency;
	    
		
		@Column(name = "INSTL_DUE_DAY")
	    private String instl_Due_Day;
	    
		
		@Column(name = "INSTL_FREQ")
	    private String instl_Freq;
		
		
		@Column(name = "SEC_ACCESS_IND")
	    private String sec_Access_Ind;
	    
		
		@Column(name = "CR_THRD")
	    private String cr_Thrd;
		
		
		@Column(name = "DR_THRD")
	    private String dr_Thrd;
		
		
		@Column(name = "DOB")
	    private String dob;
		
		
		@Column(name = "REL_IND")
	    private String rel_Ind;	
	    
		
		@Column(name = "MINOR_FLAG")
	    private String minor_Flag;
		
		
		@Column(name = "PERCENT")
	    private String percent;
	    
		
		@Column(name = "CURR_BAL")
	    private String curr_Bal;
	    
		
		@Column(name = "APP_AMT")
	    private String app_Amt;
		
		
		@Column(name = "NEW_BAD_DEBT_IND")
	    private String new_Bad_Debt_Ind;
	    
		
		@Column(name = "OLD_BAD_DEBT_IND")
	    private String old_Bad_Debt_Ind;
	    
		
		@Column(name = "EXP_INSTL")
	    private String exp_Instl;    
	    
		
		@Column(name = "CURRENCY")
	    private String currency;
	    
		
		@Column(name = "INT_INCR")
	    private String int_Incr;
	    
		
		@Column(name = "UNPD_OD_PNLTY_INT")
	    private String unpd_Od_Pnlty_Int;
		
		
		@Column(name = "MINOR_AC")
	    private String minor_Ac;
	    
		@Column(name = "MOP_TYPE")
	    private String mop_Type;
	    
		
		@Column(name = "STOP_ATM")
	    private String stop_Atm;
		
		
		@Column(name = "ATM_ACCT_FLAG")
	    private String atm_Acct_Flag;
	    
		
		@Column(name = "DATE_OF_APPL")
	    private String date_Of_Appl;
	    
		
		@Column(name = "CURR_RENEWAL_DT")
	    private String curr_Renewal_Dt;
		
		
		@Column(name = "ACTUAL_RENEWAL_DT")
	    private String actual_Renewal_Dt;
	    
		@Column(name = "SHORT_NAME")
	    private String short_Name;
	    
		
		@Column(name = "LINKED_ACCOUNT_NO")
	    private String linked_Account_No;    
	    
		
		@Column(name = "CHEQUE_BOOK_CNT")
	    private String cheque_Book_Cnt;
	    
		
		@Column(name = "SMS_FLAG")
	    private String sms_Flag;
	    
		
		@Column(name = "NOMI_NAME")
	    private String nomi_Name;
		
		
		@Column(name = "NOMI_CIF_NO")
	    private String nomi_Cif_No;
	    
		
		@Column(name = "STAT")
	    private String stat;
		
		
		@Column(name = "EXP_AN_CR")
	    private String exp_An_Cr;
		
		@Column(name = "TRNOV_THR_LIM")
	    private String trnov_Thr_Lim;
	    
		
		@Column(name = "ACTUAL_TRNOVR")
	    private String actual_Trnovr;
	    
		
		@Column(name = "HOLD_VAL")
	    private String hold_Val;
		
		
		@Column(name = "HOLD_REASON")
	    private String hold_Reason;


		/**
		 * @return the id
		 */
		public String getId() {
			return Id;
		}


		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			Id = id;
		}


		/**
		 * @return the acct_No
		 */
		public String getAcct_No() {
			return acct_No;
		}


		/**
		 * @param acct_No the acct_No to set
		 */
		public void setAcct_No(String acct_No) {
			this.acct_No = acct_No;
		}


		/**
		 * @return the acct_Type
		 */
		public String getAcct_Type() {
			return acct_Type;
		}


		/**
		 * @param acct_Type the acct_Type to set
		 */
		public void setAcct_Type(String acct_Type) {
			this.acct_Type = acct_Type;
		}


		/**
		 * @return the curr_Status
		 */
		public String getCurr_Status() {
			return curr_Status;
		}


		/**
		 * @param curr_Status the curr_Status to set
		 */
		public void setCurr_Status(String curr_Status) {
			this.curr_Status = curr_Status;
		}


		/**
		 * @return the lis_Fin_Dt
		 */
		public String getLis_Fin_Dt() {
			return lis_Fin_Dt;
		}


		/**
		 * @param lis_Fin_Dt the lis_Fin_Dt to set
		 */
		public void setLis_Fin_Dt(String lis_Fin_Dt) {
			this.lis_Fin_Dt = lis_Fin_Dt;
		}


		/**
		 * @return the int_Cat
		 */
		public String getInt_Cat() {
			return int_Cat;
		}


		/**
		 * @param int_Cat the int_Cat to set
		 */
		public void setInt_Cat(String int_Cat) {
			this.int_Cat = int_Cat;
		}


		/**
		 * @return the customer_No
		 */
		public String getCustomer_No() {
			return customer_No;
		}


		/**
		 * @param customer_No the customer_No to set
		 */
		public void setCustomer_No(String customer_No) {
			this.customer_No = customer_No;
		}


		/**
		 * @return the acct_Open_Dt
		 */
		public String getAcct_Open_Dt() {
			return acct_Open_Dt;
		}


		/**
		 * @param acct_Open_Dt the acct_Open_Dt to set
		 */
		public void setAcct_Open_Dt(String acct_Open_Dt) {
			this.acct_Open_Dt = acct_Open_Dt;
		}


		/**
		 * @return the extn_Counter
		 */
		public String getExtn_Counter() {
			return extn_Counter;
		}


		/**
		 * @param extn_Counter the extn_Counter to set
		 */
		public void setExtn_Counter(String extn_Counter) {
			this.extn_Counter = extn_Counter;
		}


		/**
		 * @return the branch_No
		 */
		public String getBranch_No() {
			return branch_No;
		}


		/**
		 * @param branch_No the branch_No to set
		 */
		public void setBranch_No(String branch_No) {
			this.branch_No = branch_No;
		}


		/**
		 * @return the acct_Stmt_Code
		 */
		public String getAcct_Stmt_Code() {
			return acct_Stmt_Code;
		}


		/**
		 * @param acct_Stmt_Code the acct_Stmt_Code to set
		 */
		public void setAcct_Stmt_Code(String acct_Stmt_Code) {
			this.acct_Stmt_Code = acct_Stmt_Code;
		}


		/**
		 * @return the descript
		 */
		public String getDescript() {
			return descript;
		}


		/**
		 * @param descript the descript to set
		 */
		public void setDescript(String descript) {
			this.descript = descript;
		}


		/**
		 * @return the gl_Class_Code
		 */
		public String getGl_Class_Code() {
			return gl_Class_Code;
		}


		/**
		 * @param gl_Class_Code the gl_Class_Code to set
		 */
		public void setGl_Class_Code(String gl_Class_Code) {
			this.gl_Class_Code = gl_Class_Code;
		}


		/**
		 * @return the trap
		 */
		public String getTrap() {
			return trap;
		}


		/**
		 * @param trap the trap to set
		 */
		public void setTrap(String trap) {
			this.trap = trap;
		}


		/**
		 * @return the trf_Acct_No
		 */
		public String getTrf_Acct_No() {
			return trf_Acct_No;
		}


		/**
		 * @param trf_Acct_No the trf_Acct_No to set
		 */
		public void setTrf_Acct_No(String trf_Acct_No) {
			this.trf_Acct_No = trf_Acct_No;
		}


		/**
		 * @return the var_Int_Rate
		 */
		public String getVar_Int_Rate() {
			return var_Int_Rate;
		}


		/**
		 * @param var_Int_Rate the var_Int_Rate to set
		 */
		public void setVar_Int_Rate(String var_Int_Rate) {
			this.var_Int_Rate = var_Int_Rate;
		}


		/**
		 * @return the aadhar_No
		 */
		public String getAadhar_No() {
			return aadhar_No;
		}


		/**
		 * @param aadhar_No the aadhar_No to set
		 */
		public void setAadhar_No(String aadhar_No) {
			this.aadhar_No = aadhar_No;
		}


		/**
		 * @return the term_Day
		 */
		public String getTerm_Day() {
			return term_Day;
		}


		/**
		 * @param term_Day the term_Day to set
		 */
		public void setTerm_Day(String term_Day) {
			this.term_Day = term_Day;
		}


		/**
		 * @return the term_No_Days
		 */
		public String getTerm_No_Days() {
			return term_No_Days;
		}


		/**
		 * @param term_No_Days the term_No_Days to set
		 */
		public void setTerm_No_Days(String term_No_Days) {
			this.term_No_Days = term_No_Days;
		}


		/**
		 * @return the term_Basis
		 */
		public String getTerm_Basis() {
			return term_Basis;
		}


		/**
		 * @param term_Basis the term_Basis to set
		 */
		public void setTerm_Basis(String term_Basis) {
			this.term_Basis = term_Basis;
		}


		/**
		 * @return the term_No_months
		 */
		public String getTerm_No_months() {
			return term_No_months;
		}


		/**
		 * @param term_No_months the term_No_months to set
		 */
		public void setTerm_No_months(String term_No_months) {
			this.term_No_months = term_No_months;
		}


		/**
		 * @return the term_Values
		 */
		public String getTerm_Values() {
			return term_Values;
		}


		/**
		 * @param term_Values the term_Values to set
		 */
		public void setTerm_Values(String term_Values) {
			this.term_Values = term_Values;
		}


		/**
		 * @return the term_years
		 */
		public String getTerm_years() {
			return term_years;
		}


		/**
		 * @param term_years the term_years to set
		 */
		public void setTerm_years(String term_years) {
			this.term_years = term_years;
		}


		/**
		 * @return the maturity_Date
		 */
		public String getMaturity_Date() {
			return maturity_Date;
		}


		/**
		 * @param maturity_Date the maturity_Date to set
		 */
		public void setMaturity_Date(String maturity_Date) {
			this.maturity_Date = maturity_Date;
		}


		/**
		 * @return the term_mat_Val
		 */
		public String getTerm_mat_Val() {
			return term_mat_Val;
		}


		/**
		 * @param term_mat_Val the term_mat_Val to set
		 */
		public void setTerm_mat_Val(String term_mat_Val) {
			this.term_mat_Val = term_mat_Val;
		}


		/**
		 * @return the term_Pay_Frequency
		 */
		public String getTerm_Pay_Frequency() {
			return term_Pay_Frequency;
		}


		/**
		 * @param term_Pay_Frequency the term_Pay_Frequency to set
		 */
		public void setTerm_Pay_Frequency(String term_Pay_Frequency) {
			this.term_Pay_Frequency = term_Pay_Frequency;
		}


		/**
		 * @return the instl_Due_Day
		 */
		public String getInstl_Due_Day() {
			return instl_Due_Day;
		}


		/**
		 * @param instl_Due_Day the instl_Due_Day to set
		 */
		public void setInstl_Due_Day(String instl_Due_Day) {
			this.instl_Due_Day = instl_Due_Day;
		}


		/**
		 * @return the instl_Freq
		 */
		public String getInstl_Freq() {
			return instl_Freq;
		}


		/**
		 * @param instl_Freq the instl_Freq to set
		 */
		public void setInstl_Freq(String instl_Freq) {
			this.instl_Freq = instl_Freq;
		}


		/**
		 * @return the sec_Access_Ind
		 */
		public String getSec_Access_Ind() {
			return sec_Access_Ind;
		}


		/**
		 * @param sec_Access_Ind the sec_Access_Ind to set
		 */
		public void setSec_Access_Ind(String sec_Access_Ind) {
			this.sec_Access_Ind = sec_Access_Ind;
		}


		/**
		 * @return the cr_Thrd
		 */
		public String getCr_Thrd() {
			return cr_Thrd;
		}


		/**
		 * @param cr_Thrd the cr_Thrd to set
		 */
		public void setCr_Thrd(String cr_Thrd) {
			this.cr_Thrd = cr_Thrd;
		}


		/**
		 * @return the dr_Thrd
		 */
		public String getDr_Thrd() {
			return dr_Thrd;
		}


		/**
		 * @param dr_Thrd the dr_Thrd to set
		 */
		public void setDr_Thrd(String dr_Thrd) {
			this.dr_Thrd = dr_Thrd;
		}


		/**
		 * @return the dob
		 */
		public String getDob() {
			return dob;
		}


		/**
		 * @param dob the dob to set
		 */
		public void setDob(String dob) {
			this.dob = dob;
		}


		/**
		 * @return the rel_Ind
		 */
		public String getRel_Ind() {
			return rel_Ind;
		}


		/**
		 * @param rel_Ind the rel_Ind to set
		 */
		public void setRel_Ind(String rel_Ind) {
			this.rel_Ind = rel_Ind;
		}


		/**
		 * @return the minor_Flag
		 */
		public String getMinor_Flag() {
			return minor_Flag;
		}


		/**
		 * @param minor_Flag the minor_Flag to set
		 */
		public void setMinor_Flag(String minor_Flag) {
			this.minor_Flag = minor_Flag;
		}


		/**
		 * @return the percent
		 */
		public String getPercent() {
			return percent;
		}


		/**
		 * @param percent the percent to set
		 */
		public void setPercent(String percent) {
			this.percent = percent;
		}


		/**
		 * @return the curr_Bal
		 */
		public String getCurr_Bal() {
			return curr_Bal;
		}


		/**
		 * @param curr_Bal the curr_Bal to set
		 */
		public void setCurr_Bal(String curr_Bal) {
			this.curr_Bal = curr_Bal;
		}


		/**
		 * @return the app_Amt
		 */
		public String getApp_Amt() {
			return app_Amt;
		}


		/**
		 * @param app_Amt the app_Amt to set
		 */
		public void setApp_Amt(String app_Amt) {
			this.app_Amt = app_Amt;
		}


		/**
		 * @return the new_Bad_Debt_Ind
		 */
		public String getNew_Bad_Debt_Ind() {
			return new_Bad_Debt_Ind;
		}


		/**
		 * @param new_Bad_Debt_Ind the new_Bad_Debt_Ind to set
		 */
		public void setNew_Bad_Debt_Ind(String new_Bad_Debt_Ind) {
			this.new_Bad_Debt_Ind = new_Bad_Debt_Ind;
		}


		/**
		 * @return the old_Bad_Debt_Ind
		 */
		public String getOld_Bad_Debt_Ind() {
			return old_Bad_Debt_Ind;
		}


		/**
		 * @param old_Bad_Debt_Ind the old_Bad_Debt_Ind to set
		 */
		public void setOld_Bad_Debt_Ind(String old_Bad_Debt_Ind) {
			this.old_Bad_Debt_Ind = old_Bad_Debt_Ind;
		}


		/**
		 * @return the exp_Instl
		 */
		public String getExp_Instl() {
			return exp_Instl;
		}


		/**
		 * @param exp_Instl the exp_Instl to set
		 */
		public void setExp_Instl(String exp_Instl) {
			this.exp_Instl = exp_Instl;
		}


		/**
		 * @return the currency
		 */
		public String getCurrency() {
			return currency;
		}


		/**
		 * @param currency the currency to set
		 */
		public void setCurrency(String currency) {
			this.currency = currency;
		}


		/**
		 * @return the int_Incr
		 */
		public String getInt_Incr() {
			return int_Incr;
		}


		/**
		 * @param int_Incr the int_Incr to set
		 */
		public void setInt_Incr(String int_Incr) {
			this.int_Incr = int_Incr;
		}


		/**
		 * @return the unpd_Od_Pnlty_Int
		 */
		public String getUnpd_Od_Pnlty_Int() {
			return unpd_Od_Pnlty_Int;
		}


		/**
		 * @param unpd_Od_Pnlty_Int the unpd_Od_Pnlty_Int to set
		 */
		public void setUnpd_Od_Pnlty_Int(String unpd_Od_Pnlty_Int) {
			this.unpd_Od_Pnlty_Int = unpd_Od_Pnlty_Int;
		}


		/**
		 * @return the minor_Ac
		 */
		public String getMinor_Ac() {
			return minor_Ac;
		}


		/**
		 * @param minor_Ac the minor_Ac to set
		 */
		public void setMinor_Ac(String minor_Ac) {
			this.minor_Ac = minor_Ac;
		}


		/**
		 * @return the mop_Type
		 */
		public String getMop_Type() {
			return mop_Type;
		}


		/**
		 * @param mop_Type the mop_Type to set
		 */
		public void setMop_Type(String mop_Type) {
			this.mop_Type = mop_Type;
		}


		/**
		 * @return the stop_Atm
		 */
		public String getStop_Atm() {
			return stop_Atm;
		}


		/**
		 * @param stop_Atm the stop_Atm to set
		 */
		public void setStop_Atm(String stop_Atm) {
			this.stop_Atm = stop_Atm;
		}


		/**
		 * @return the atm_Acct_Flag
		 */
		public String getAtm_Acct_Flag() {
			return atm_Acct_Flag;
		}


		/**
		 * @param atm_Acct_Flag the atm_Acct_Flag to set
		 */
		public void setAtm_Acct_Flag(String atm_Acct_Flag) {
			this.atm_Acct_Flag = atm_Acct_Flag;
		}


		/**
		 * @return the date_Of_Appl
		 */
		public String getDate_Of_Appl() {
			return date_Of_Appl;
		}


		/**
		 * @param date_Of_Appl the date_Of_Appl to set
		 */
		public void setDate_Of_Appl(String date_Of_Appl) {
			this.date_Of_Appl = date_Of_Appl;
		}


		/**
		 * @return the curr_Renewal_Dt
		 */
		public String getCurr_Renewal_Dt() {
			return curr_Renewal_Dt;
		}


		/**
		 * @param curr_Renewal_Dt the curr_Renewal_Dt to set
		 */
		public void setCurr_Renewal_Dt(String curr_Renewal_Dt) {
			this.curr_Renewal_Dt = curr_Renewal_Dt;
		}


		/**
		 * @return the actual_Renewal_Dt
		 */
		public String getActual_Renewal_Dt() {
			return actual_Renewal_Dt;
		}


		/**
		 * @param actual_Renewal_Dt the actual_Renewal_Dt to set
		 */
		public void setActual_Renewal_Dt(String actual_Renewal_Dt) {
			this.actual_Renewal_Dt = actual_Renewal_Dt;
		}


		/**
		 * @return the short_Name
		 */
		public String getShort_Name() {
			return short_Name;
		}


		/**
		 * @param short_Name the short_Name to set
		 */
		public void setShort_Name(String short_Name) {
			this.short_Name = short_Name;
		}


		/**
		 * @return the linked_Account_No
		 */
		public String getLinked_Account_No() {
			return linked_Account_No;
		}


		/**
		 * @param linked_Account_No the linked_Account_No to set
		 */
		public void setLinked_Account_No(String linked_Account_No) {
			this.linked_Account_No = linked_Account_No;
		}


		/**
		 * @return the cheque_Book_Cnt
		 */
		public String getCheque_Book_Cnt() {
			return cheque_Book_Cnt;
		}


		/**
		 * @param cheque_Book_Cnt the cheque_Book_Cnt to set
		 */
		public void setCheque_Book_Cnt(String cheque_Book_Cnt) {
			this.cheque_Book_Cnt = cheque_Book_Cnt;
		}


		/**
		 * @return the sms_Flag
		 */
		public String getSms_Flag() {
			return sms_Flag;
		}


		/**
		 * @param sms_Flag the sms_Flag to set
		 */
		public void setSms_Flag(String sms_Flag) {
			this.sms_Flag = sms_Flag;
		}


		/**
		 * @return the nomi_Name
		 */
		public String getNomi_Name() {
			return nomi_Name;
		}


		/**
		 * @param nomi_Name the nomi_Name to set
		 */
		public void setNomi_Name(String nomi_Name) {
			this.nomi_Name = nomi_Name;
		}


		/**
		 * @return the nomi_Cif_No
		 */
		public String getNomi_Cif_No() {
			return nomi_Cif_No;
		}


		/**
		 * @param nomi_Cif_No the nomi_Cif_No to set
		 */
		public void setNomi_Cif_No(String nomi_Cif_No) {
			this.nomi_Cif_No = nomi_Cif_No;
		}


		/**
		 * @return the stat
		 */
		public String getStat() {
			return stat;
		}


		/**
		 * @param stat the stat to set
		 */
		public void setStat(String stat) {
			this.stat = stat;
		}


		/**
		 * @return the exp_An_Cr
		 */
		public String getExp_An_Cr() {
			return exp_An_Cr;
		}


		/**
		 * @param exp_An_Cr the exp_An_Cr to set
		 */
		public void setExp_An_Cr(String exp_An_Cr) {
			this.exp_An_Cr = exp_An_Cr;
		}


		/**
		 * @return the trnov_Thr_Lim
		 */
		public String getTrnov_Thr_Lim() {
			return trnov_Thr_Lim;
		}


		/**
		 * @param trnov_Thr_Lim the trnov_Thr_Lim to set
		 */
		public void setTrnov_Thr_Lim(String trnov_Thr_Lim) {
			this.trnov_Thr_Lim = trnov_Thr_Lim;
		}


		/**
		 * @return the actual_Trnovr
		 */
		public String getActual_Trnovr() {
			return actual_Trnovr;
		}


		/**
		 * @param actual_Trnovr the actual_Trnovr to set
		 */
		public void setActual_Trnovr(String actual_Trnovr) {
			this.actual_Trnovr = actual_Trnovr;
		}


		/**
		 * @return the hold_Val
		 */
		public String getHold_Val() {
			return hold_Val;
		}


		/**
		 * @param hold_Val the hold_Val to set
		 */
		public void setHold_Val(String hold_Val) {
			this.hold_Val = hold_Val;
		}


		/**
		 * @return the hold_Reason
		 */
		public String getHold_Reason() {
			return hold_Reason;
		}


		/**
		 * @param hold_Reason the hold_Reason to set
		 */
		public void setHold_Reason(String hold_Reason) {
			this.hold_Reason = hold_Reason;
		}
		
	    

		
		
		
	
		

}
