
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Callback_Ack_Resp_DAO;

public interface CcssCallbackAckRespDetailsRepo extends JpaRepository<Ccss_Callback_Ack_Resp_DAO, String> {

	@Query(value = "select * from CCSS_CALLBACK_ACK_RESP where ACK_TYPE=?1 and ACKNOWLEDGEMENT_NO=?2", nativeQuery = true)
	List<Ccss_Callback_Ack_Resp_DAO> getCallBackAckResponseByAckType(String ackType, String ackNo);

	@Query(value = "select count(ACK_TYPE) as openComplaint from CCSS_CALLBACK_ACK_RESP where ACK_TYPE='I4C' and RESP_CODE !=00", nativeQuery = true)
	String getOpenComplaintByAckType();

	@Query(value = "select  count(ACK_TYPE) as closeComplaint from CCSS_CALLBACK_ACK_RESP where ACK_TYPE='I4C' and RESP_CODE='00'", nativeQuery = true)
	String getCloseComplaintByAckType();

	List<Ccss_Callback_Ack_Resp_DAO> findByEntryDateTimeBetween(Date startDate, Date endDate);
}
