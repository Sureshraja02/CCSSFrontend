package com.fisglobal.fsg.backops.core.controller.v1;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.data.v1.RMSConfigRequest;
import com.fisglobal.fsg.backops.core.entity.RMS_Config;
import com.fisglobal.fsg.backops.core.entity.repo.RMSConfigRepo;
import com.fisglobal.fsg.backops.core.entity.repo.RMS_Rule_Repo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping(value = "/app/rest/v1.0/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class ConfigController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigController.class);

	@Inject
	private PaginationService pageService;
	
	@Inject
	private RMSConfigRepo configRepo;

	
	@RequestMapping(value = "save/appconfig", method = RequestMethod.POST)
	public ResponseEntity<?> saveConfig(
			@RequestHeader(value = "requestid") String reqId,
			@RequestBody RMSConfigRequest appConfigRequest) throws IllegalAccessException, InvocationTargetException{
		
		RMSResponse response = new RMSResponse();
		RMS_Config config = new RMS_Config();
		
		BeanUtils.copyProperties(config, appConfigRequest);
		
		configRepo.save(config);
		
		response.setErrorCode(RMSConstants.SUCCESS_CODE);
		response.setStatus(RMSConstants.SUCCESS_MSG);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/{property_name}/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getConfig(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String property_name,
			@PathVariable int pageSize,
			@PathVariable int page) throws Exception {
		RMSResponse response = new RMSResponse();
		
		//Page<RMS_Config> resultPage = configRepo.findAll(PageRequest.of(0, pageSize));
		
		Page<RMS_Config> configList = pageService.getConfigList(property_name, pageSize, page);
		
		if(!configList.hasContent()) {
			throw new RMSException(RMSConstants.INVALID_CONFIG_CODE, RMSConstants.INVALID_CONFIG_MSG);
		}

		/*if (configList.size() <= 0) {
			throw new RMSException(RMSConstants.INVALID_CONFIG_CODE, RMSConstants.INVALID_CONFIG_MSG);
		}*/

		return new ResponseEntity<>(configList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "fetch/{property_name}", method = RequestMethod.GET)
	public ResponseEntity<?> getAppConfig(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String property_name) throws Exception {
		RMSResponse response = new RMSResponse();
		
		List<RMS_Config> configList = configRepo.getAppProperty(property_name);
		
		if(configList.size() <= 0) {
			throw new RMSException(RMSConstants.INVALID_CONFIG_CODE, RMSConstants.INVALID_CONFIG_MSG);
		}

		return new ResponseEntity<>(configList, HttpStatus.OK);
	}
}
