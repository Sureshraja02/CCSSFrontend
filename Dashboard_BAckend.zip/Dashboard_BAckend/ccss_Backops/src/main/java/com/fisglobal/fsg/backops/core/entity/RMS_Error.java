package com.fisglobal.fsg.backops.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "RMS_ERROR")
@Entity
public class RMS_Error {

	@Id
	@Column(name = "ERROR_CODE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String errorCode;

	@Column(name = "ERROR_DESC")
	private String errorDesc;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

}
