package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.Group_Master;
import com.fisglobal.fsg.backops.core.entity.pk.Group_Master_PK;

public interface GroupRepo extends PagingAndSortingRepository<Group_Master,String> {
	
	@Query(value = "select * from GROUP_MASTER where GROUPID=?1", 
			nativeQuery = true)	
	Group_Master findByGroupId(String userID);
	
	@Query(value = "select * from GROUP_MASTER",nativeQuery = true)	
	List<Group_Master> getGrpList();
	
	@Query(value = "select * from GROUP_MASTER WHERE GROUPNAME=?1",nativeQuery = true)	
	List<Group_Master> getGrpDetails(String grpName);

}
