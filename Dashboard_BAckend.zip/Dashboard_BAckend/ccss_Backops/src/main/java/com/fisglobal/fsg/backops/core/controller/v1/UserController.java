package com.fisglobal.fsg.backops.core.controller.v1;

import java.security.Principal;
import java.time.LocalDateTime;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.ErrorDetails;
import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.data.v1.UserRequest;
import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.repo.UserRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.AuthTokenService;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;
import com.fisglobal.fsg.backops.core.service.v1.UserValidationService;

import io.swagger.annotations.Api;

@Api(tags = "User Registration", description = "Application User Creation")
@RestController
@RequestMapping(value = "/app/rest/v1.0/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class UserController {

	@Inject
	private PaginationService paginationService;

	@Inject
	private UserRepo userRepo;

	@Inject
	private UserValidationService validationService;

	@Inject
	private AuthTokenService tokenService;

	@RequestMapping(value = "save/user", method = RequestMethod.POST)
	public ResponseEntity<?> updateUserDetails(@RequestHeader(value = "requestid") String reqId,
			@RequestBody UserRequest request, Principal principal) {
		RMSResponse response = new RMSResponse();

//		ErrorDetails erroDetails = validationService.validateData(request);

//		if (erroDetails.getErrorList().size() > 0) {
//			return new ResponseEntity<>(erroDetails, HttpStatus.OK);
//		}

		User_Master userMasterObj = userRepo.findByEmail(request.getEmail());
		if (userMasterObj != null) {
			userMasterObj.setCreateUserID(request.getUserName());
			userMasterObj.setEmail(request.getEmail());
			userMasterObj.setGroupID("supergrp"); //static implementation need to make it dynamic
			userMasterObj.setGroupName("supergrp");
			userMasterObj.setInsertDate(LocalDateTime.now());
			userMasterObj.setModifiedDate(LocalDateTime.now());
			userMasterObj.setIsFirstTimeLogin("true");
			userMasterObj.setInstID(request.getInstid());
			userMasterObj.setMobileNo(request.getMobileNo());
			userMasterObj.setPassword(request.getPassword());
			userMasterObj.setPasswordDate(LocalDateTime.now());
			userMasterObj.setUserType(request.getUserType());
			userMasterObj.setUserName(request.getUserName());
			userMasterObj.setCreateUserID(tokenService.getMakerId());
			userMasterObj.setStatus("1");
			userRepo.save(userMasterObj);
		} else {
			User_Master userMaster = new User_Master();
			userMaster.setCreateUserID(request.getUserName());
			userMaster.setEmail(request.getEmail());
			userMaster.setGroupID("supergrp"); //static implementation need to make it dynamic
			userMaster.setGroupName("supergrp");
			userMaster.setInsertDate(LocalDateTime.now());
			userMaster.setModifiedDate(LocalDateTime.now());
			userMaster.setIsFirstTimeLogin("true");
			userMaster.setInstID(request.getInstid());
			userMaster.setMobileNo(request.getMobileNo());
			userMaster.setPassword(request.getPassword());
			userMaster.setPasswordDate(LocalDateTime.now());
			userMaster.setUserType(request.getUserType());
			userMaster.setUserName(request.getUserName());
			userMaster.setCreateUserID(tokenService.getMakerId());
			userMaster.setStatus("1");
			userRepo.save(userMaster);
		}

		response.setErrorCode(RMSConstants.SUCCESS_CODE);
		response.setStatus(RMSConstants.SUCCESS_MSG);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/user/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getUserList(@RequestHeader(value = "requestid") String reqId, @PathVariable int pageSize,
			@PathVariable int page) throws Exception {

		Page<User_Master> pageResult = paginationService.getUserListDashboard(pageSize, page,"F");

		/*
		 * if(!pageResult.hasContent()) {
		 * 
		 * throw new RMSException(RMSConstants.INVALID_REQUEST_CODE,
		 * RMSConstants.INVALID_REQUEST_MSG); }
		 */

		return new ResponseEntity<>(pageResult, HttpStatus.OK);

	}

	@RequestMapping(value = "fetch/user/{userid}", method = RequestMethod.GET)
	public ResponseEntity<?> getUserData(@RequestHeader(value = "requestid") String reqId, @PathVariable Long userid)
			throws Exception {

		System.out.println("user ID : " + userid);

		User_Master userMaster = userRepo.findByUserID(userid);

		return new ResponseEntity<>(userMaster, HttpStatus.OK);

	}
}
