package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_BankCodes_DAO;

public interface CCSSBankCodesRepo extends JpaRepository<Ccss_BankCodes_DAO, String>  {

	@Query(value = "select * from CCSS_BANK_CODES where BANK_IFSC_CODE=?1", nativeQuery = true)	
	List<Ccss_BankCodes_DAO> getBankDetailSByIfsccode(String ifscCode);
}
