package com.fisglobal.fsg.backops.core.data.v1;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class InstitutionData {

	private String orgName;

	private String orgLogo;

	private Long orgID;

	private String orgPrimaryColor;

	private String orgSecondaryColor;

	private String createdUserID;

	private String appInfoColor;

	private String appWarningColor;

	private String appSuccessColor;

	private String appDangerColor;

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgLogo() {
		return orgLogo;
	}

	public void setOrgLogo(String orgLogo) {
		this.orgLogo = orgLogo;
	}

	public Long getOrgID() {
		return orgID;
	}

	public void setOrgID(Long orgID) {
		this.orgID = orgID;
	}

	public String getOrgPrimaryColor() {
		return orgPrimaryColor;
	}

	public void setOrgPrimaryColor(String orgPrimaryColor) {
		this.orgPrimaryColor = orgPrimaryColor;
	}

	public String getOrgSecondaryColor() {
		return orgSecondaryColor;
	}

	public void setOrgSecondaryColor(String orgSecondaryColor) {
		this.orgSecondaryColor = orgSecondaryColor;
	}

	public String getCreatedUserID() {
		return createdUserID;
	}

	public void setCreatedUserID(String createdUserID) {
		this.createdUserID = createdUserID;
	}

	public String getAppInfoColor() {
		return appInfoColor;
	}

	public void setAppInfoColor(String appInfoColor) {
		this.appInfoColor = appInfoColor;
	}

	public String getAppWarningColor() {
		return appWarningColor;
	}

	public void setAppWarningColor(String appWarningColor) {
		this.appWarningColor = appWarningColor;
	}

	public String getAppSuccessColor() {
		return appSuccessColor;
	}

	public void setAppSuccessColor(String appSuccessColor) {
		this.appSuccessColor = appSuccessColor;
	}

	public String getAppDangerColor() {
		return appDangerColor;
	}

	public void setAppDangerColor(String appDangerColor) {
		this.appDangerColor = appDangerColor;
	}

	@Override
	public String toString() {
		return "InstitutionData [orgName=" + orgName + ", orgLogo=" + orgLogo + ", orgID=" + orgID
				+ ", orgPrimaryColor=" + orgPrimaryColor + ", orgSecondaryColor=" + orgSecondaryColor
				+ ", createdUserID=" + createdUserID + ", appInfoColor=" + appInfoColor + ", appWarningColor="
				+ appWarningColor + ", appSuccessColor=" + appSuccessColor + ", appDangerColor=" + appDangerColor + "]";
	}

}
