package com.fisglobal.fsg.backops.core.data.v1;

import java.util.List;

public class EventTagDetails {

	private String tagName;

	private String isMandate;

	private String isActive;

	private String parentTagName;

	private String dataType;

	private List<EventDataTypeDetails> dataTypeDetails;

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getIsMandate() {
		return isMandate;
	}

	public void setIsMandate(String isMandate) {
		this.isMandate = isMandate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getParentTagName() {
		return parentTagName;
	}

	public void setParentTagName(String parentTagName) {
		this.parentTagName = parentTagName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public List<EventDataTypeDetails> getDataTypeDetails() {
		return dataTypeDetails;
	}

	public void setDataTypeDetails(List<EventDataTypeDetails> dataTypeDetails) {
		this.dataTypeDetails = dataTypeDetails;
	}

}
