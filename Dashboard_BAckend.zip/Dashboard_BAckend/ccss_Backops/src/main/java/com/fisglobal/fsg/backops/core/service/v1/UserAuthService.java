package com.fisglobal.fsg.backops.core.service.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.repo.UserRepo;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Service
public class UserAuthService {
	
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(UserAuthService.class);
	
	@Inject
	private UserRepo userRepo;
	
	private String username;
	private String keyword;


	public UserDetails loadUserById(String userId) {
		
		User_Master userMaster = userRepo.findByEmail(userId);
		
		if(userMaster == null) {
			logger.error("Username not found: " + userId);
		}
		logger.info("DB ID[{}]",userMaster.getUserID());
		return new CustomUserDetails(userMaster);
	}

}
