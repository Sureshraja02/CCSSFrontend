package com.fisglobal.fsg.backops.core.common;

import java.util.List;

public class Accounts {

	private List<AccountList> accountList;

	public List<AccountList> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<AccountList> accountList) {
		this.accountList = accountList;
	}

}
