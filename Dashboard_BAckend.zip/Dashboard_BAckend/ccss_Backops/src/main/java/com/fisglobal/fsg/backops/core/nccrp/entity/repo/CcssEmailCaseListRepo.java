package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.CcssEmailCaseList;

public interface CcssEmailCaseListRepo extends JpaRepository<CcssEmailCaseList, String> {

}
