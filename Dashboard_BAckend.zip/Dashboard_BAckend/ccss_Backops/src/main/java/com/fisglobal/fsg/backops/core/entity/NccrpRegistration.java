package com.fisglobal.fsg.backops.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "NCCRPREGISTRATION")
@Entity
public class NccrpRegistration {

	@Column(name = "ACCOUNTNO")
	private String accNo;

	@Column(name = "CHANNEL")
	private String channel;

	@Column(name = "AMOUNT")
	private String amt;

	@Column(name = "IFSC")
	private String ifsc;

	@Column(name = "MOBILENUMBER")
	private String mobileNumber;

	@Column(name = "BANKNAME")
	private String bankName;

	@Column(name = "CUSTOMERNAME")
	private String customerName;

	@Column(name = "TXNDT")
	private String txnDT;

	@Column(name = "UPIID")
	private String upiID;

	@Column(name = "REMARKS")
	private String remarks;

	@Id
	@Column(name = "CASEID")
	private String caseID;

	@Column(name = "REQUESTOR")
	private String requestor;

	@Column(name = "CODE")
	private String bankCode;

	@Column(name = "TXNTYPE")
	private String txnType;

	@Column(name = "TRANSACTION_ID")
	private String txnID;

	@Column(name = "RRN")
	private String rrn;

	@Column(name = "CASESTATUS")
	private String caseStatus;

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getTxnID() {
		return txnID;
	}

	public void setTxnID(String txnID) {
		this.txnID = txnID;
	}

	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getTxnDT() {
		return txnDT;
	}

	public void setTxnDT(String txnDT) {
		this.txnDT = txnDT;
	}

	public String getUpiID() {
		return upiID;
	}

	public void setUpiID(String upiID) {
		this.upiID = upiID;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}

}
