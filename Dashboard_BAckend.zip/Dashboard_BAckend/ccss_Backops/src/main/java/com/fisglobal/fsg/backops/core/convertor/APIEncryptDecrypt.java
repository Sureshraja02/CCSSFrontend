package com.fisglobal.fsg.backops.core.convertor;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Inject;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fisglobal.fsg.backops.core.common.Request;
import com.fisglobal.fsg.backops.core.crypto.DecryptionUtils;
import com.fisglobal.fsg.backops.core.crypto.EncryptionUtils;
import com.fisglobal.fsg.backops.core.data.v1.LoginResponseData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class APIEncryptDecrypt extends AbstractHttpMessageConverter<Object> {

	private static final Logger LOGGER = LoggerFactory.getLogger(APIEncryptDecrypt.class);

	private String SECRET_KEY;

	private String SALT;

	private EncryptionUtils encrypt;

	private DecryptionUtils decrypt;

	private ObjectMapper objectMapper;

	public APIEncryptDecrypt(String secretKey, String salt, EncryptionUtils encrypt, DecryptionUtils decrypt,
			ObjectMapper objectMapper) {
		super(MediaType.APPLICATION_JSON, new MediaType("application", "*+json", StandardCharsets.UTF_8));
		this.SECRET_KEY = secretKey;
		this.SALT = salt;
		this.encrypt = encrypt;
		this.decrypt = decrypt;
		this.objectMapper = objectMapper;
	}

	@Override
	protected boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	protected Object readInternal(Class<? extends Object> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		String apiEncryptedRequest = getBody(inputMessage.getBody());
		Request apiRequest = new Gson().fromJson(apiEncryptedRequest, Request.class);
		HttpHeaders headers = inputMessage.getHeaders();
		String requestId = headers.getFirst("requestid");
		LOGGER.info("Encrypted Key [{}]", requestId);

		String hexval = requestId.split("-")[0];

		byte[] bytes = javax.xml.bind.DatatypeConverter.parseHexBinary(hexval);
		String P = new String(bytes, StandardCharsets.UTF_8);
		int G = findPrimitive(Integer.parseInt(P));
		int a = LocalDateTime.now().getDayOfMonth();
		int b = LocalDateTime.now().getDayOfYear();

		long x = calculatePower(G, a, Integer.parseInt(P));
		long y = calculatePower(G, b, Integer.parseInt(P));
		long kb = calculatePower(y, a, Integer.parseInt(P));

		BigInteger bp = new BigInteger(String.valueOf(P));
		BigInteger bg = new BigInteger(String.valueOf(G));
		BigInteger ba = new BigInteger(String.valueOf(a));
		BigInteger bb = new BigInteger(String.valueOf(b));
		BigInteger bx = bg.modPow(ba, bp);
		BigInteger by = bg.modPow(bb, bp);
		BigInteger bkb = by.modPow(ba, bp);

		LOGGER.info("P[{}] G[{}] a[{}] b[{}] x[{}] y[{}] kb[{}]",bp,bg, ba, bb, bx, by, bkb);

		String key = getSHA256Hash(String.valueOf(bkb));
		String[] saltlist = requestId.split("-");
		int pos = saltlist.length - 1;
		String salt = saltlist[pos];
		//String salt = requestId.split("-")[4];

		LOGGER.info("Encrypted Request [{}] Key[{}] Salt[{}]", apiRequest.getRequest(), key, salt);
		String decryptedRequest = decrypt.decrypt256(apiRequest.getRequest(), key, salt);
		LOGGER.info("DecryptedString [{}]", decryptedRequest);
		ByteArrayInputStream bi = new ByteArrayInputStream(decryptedRequest.getBytes(StandardCharsets.UTF_8));
		return objectMapper.readValue(bi, clazz);
	}

	@Override
	protected void writeInternal(Object t, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {

		LOGGER.info("Class [{}] [{}]", t.getClass().getName());
		String apiJsonResponse = new String(objectMapper.writeValueAsBytes(t));
		LOGGER.info("Clear Response [{}]", apiJsonResponse);
		Gson gson = new GsonBuilder().create();
		if ((t.getClass().getName().startsWith("com.fisglobal.fsg")) ||
				(t.getClass().getName().startsWith("org.springframework.data.domain.PageImpl"))||
				(t.getClass().getName().startsWith("java.util.HashMap"))) {

			int P = generateNumber();
			int G = findPrimitive(P);

			int a = LocalDateTime.now().getDayOfMonth();
			int b = LocalDateTime.now().getDayOfYear();

			long x = calculatePower(G, a, P);
			long y = calculatePower(G, b, P);
			long ka = calculatePower(y, a, P);

			BigInteger bp = new BigInteger(String.valueOf(P));
			BigInteger bg = new BigInteger(String.valueOf(G));
			BigInteger ba = new BigInteger(String.valueOf(a));
			BigInteger bb = new BigInteger(String.valueOf(b));
			BigInteger bx = bg.modPow(ba, bp);
			BigInteger by = bg.modPow(bb, bp);
			BigInteger bka = by.modPow(ba, bp);

			String secretKey = getSHA256Hash(String.valueOf(bka));

			String p = StringUtils.leftPad(String.valueOf(bp), 5, "0");
			String g = StringUtils.leftPad(String.valueOf(bg), 5, "0");

			String requestId = UUID.randomUUID().toString();
			String[] saltlist = requestId.split("-");
			int pos = saltlist.length - 1;
			String salt = saltlist[pos];
			requestId = bytesToHex(String.valueOf(bp).getBytes()) + "-" + requestId;

			LOGGER.info("P[{}] G[{}] a[{}] b[{}] x[{}] y[{}] ka[{}] sha[{}] salt[{}]", bp, bg, ba, bb, bx, by, bka,
					secretKey, salt);

			HttpHeaders headers = outputMessage.getHeaders();

			headers.add("requestid", requestId);

			String encryptedString = encrypt.encryption256(apiJsonResponse, secretKey, salt);
			String hmac = generateHmac(encryptedString, secretKey);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("response", encryptedString);
			responseMap.put("hmac", hmac);

			LOGGER.info("Encrypted JSON Response [{}]", gson.toJson(responseMap));

			outputMessage.getBody().write(gson.toJson(responseMap).getBytes());
		}else {
			outputMessage.getBody().write(objectMapper.writeValueAsString(t).getBytes());
		}
	}

	private String generateHmac(String encryptedInput, String secretKey) {
		byte[] secretKeyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
		Mac mac;
		String hmacHexString = null;
		try {
			mac = Mac.getInstance("HmacSHA256");
			mac.init(new SecretKeySpec(secretKeyBytes, "HmacSHA256"));
			hmacHexString = bytesToBase64(mac.doFinal(encryptedInput.getBytes(StandardCharsets.UTF_8)));
			return hmacHexString;
		} catch (NoSuchAlgorithmException | InvalidKeyException e) {
			throw new RuntimeException(e);
		}
	}

	private String bytesToBase64(byte[] hash) {
		String hexString = Base64.getEncoder().encodeToString(hash);
		return hexString;
	}

	private String getBody(InputStream inputStream) throws IOException {
		String body = null;
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			if (inputStream != null) {
				bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			} else {
				stringBuilder.append("");
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException ex) {
					throw ex;
				}
			}
		}

		body = stringBuilder.toString();
		LOGGER.info("Message Recevied [{}]", body);
		return body;
	}

	private String getSHA256Hash(String data) {
		String result = null;
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(data.getBytes("UTF-8"));
			return bytesToHex(hash); // make it printable
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}

	private String bytesToHex(byte[] hash) {
		return DatatypeConverter.printHexBinary(hash);
	}

	public int generateNumber() {
		int num = 0;
		Random rand = new Random(); // generate a random number
		num = rand.nextInt(1000) + 1;

		while (!isPrime(num)) {
			num = rand.nextInt(1000) + 1;
		}
		return num;
	}

	private boolean isPrime(int inputNum) {
		if (inputNum <= 3 || inputNum % 2 == 0)
			return inputNum == 2 || inputNum == 3; // this returns false if number is <=1 & true if number = 2 or 3
		int divisor = 3;
		while ((divisor <= Math.sqrt(inputNum)) && (inputNum % divisor != 0))
			divisor += 2; // iterates through all possible divisors
		return inputNum % divisor != 0; // returns true/false
	}

	public int findPrimitive(int n) {
		HashSet<Integer> s = new HashSet<Integer>();

		// Check if n is prime or not
		if (isPrime(n) == false) {
			return -1;
		}

		// Find value of Euler Totient function of n
		// Since n is a prime number, the value of Euler
		// Totient function is n-1 as there are n-1
		// relatively prime numbers.
		int phi = n - 1;

		// Find prime factors of phi and store in a set
		findPrimefactors(s, phi);

		// Check for every number from 2 to phi
		for (int r = 2; r <= phi; r++) {
			// Iterate through all prime factors of phi.
			// and check if we found a power with value 1
			boolean flag = false;
			for (Integer a : s) {

				// Check if r^((phi)/primefactors) mod n
				// is 1 or not
				if (power(r, phi / (a), n) == 1) {
					flag = true;
					break;
				}
			}

			// If there was no power with value 1.
			if (flag == false) {
				return r;
			}
		}

		// If no primitive root found
		return -1;
	}

	private void findPrimefactors(HashSet<Integer> s, int n) {
		// Print the number of 2s that divide n
		while (n % 2 == 0) {
			s.add(2);
			n = n / 2;
		}

		// n must be odd at this point. So we can skip
		// one element (Note i = i +2)
		for (int i = 3; i <= Math.sqrt(n); i = i + 2) {
			// While i divides n, print i and divide n
			while (n % i == 0) {
				s.add(i);
				n = n / i;
			}
		}

		// This condition is to handle the case when
		// n is a prime number greater than 2
		if (n > 2) {
			s.add(n);
		}
	}

	private int power(int x, int y, int p) {
		int res = 1; // Initialize result

		x = x % p; // Update x if it is more than or
		// equal to p

		while (y > 0) {
			// If y is odd, multiply x with result
			if (y % 2 == 1) {
				res = (res * x) % p;
			}

			// y must be even now
			y = y >> 1; // y = y/2
			x = (x * x) % p;
		}
		return res;
	}

	public long calculatePower(long x, long y, long P) {
		long result = 0;
		if (y == 1) {
			return x;
		} else {
			result = ((long) Math.pow(x, y)) % P;
			return result;
		}
	}

}
