package com.fisglobal.fsg.backops.core.entity.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.fisglobal.fsg.backops.core.entity.RMS_Error;

public interface RMSErrorRepo extends PagingAndSortingRepository<RMS_Error, String> {

}
