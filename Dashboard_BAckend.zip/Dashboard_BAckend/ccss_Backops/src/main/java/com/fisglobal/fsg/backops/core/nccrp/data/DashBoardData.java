/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fisglobal.fsg.backops.core.common.StatusCount;
import com.fisglobal.fsg.backops.core.common.TxnsCount;

/**
 * @author e5745290
 *
 */
public class DashBoardData {

	private Date LastTxnDt;
	
	private String LastTxnDtAsString;

	private Long noOfAck;

	private Long noOftxn;

	private Long noOfAckProcessed;

	private Long noOfackFailed;

	private Long noOfackSucceeded;

	private Long noOfAccountsHolded;

	private Long noOfackPartiallyCompleted;

	private Long noOftxnProcessed;

	private Long noOfHoldMade;

	private BigDecimal amtOfHoldMade;

	private BigDecimal amtofDisputeMade;

	private String totalCompliantsReceived;

	private Map<String, Long> layersMap;

	private Map<String, Long> channelMap;

	private String freezedAccounts;

	private String openComplaints;

	private String closeComplaints;

	private String successCount;

	private String failureCount;

	private String challengeCount;

	private String debitCreditCard;

	private String phonecalls;

	private String wallet;

	private String ibank;

	private String dematFraud;

	private String debitCreditCardPercentage;

	private String phonecallsPercentage;

	private String walletPercentage;

	private String ibankPercentage;

	private String creditCardFraud;

	private String businessFraud;

	private TxnsCount txnsCount;

	private StatusCount statusCount;

	private String yearWiseRecord;

	private Long digitalBlockCount;

	/**
	 * @return the totalCompliantsReceived
	 */
	public String getTotalCompliantsReceived() {
		return totalCompliantsReceived;
	}

	/**
	 * @param totalCompliantsReceived the totalCompliantsReceived to set
	 */
	public void setTotalCompliantsReceived(String totalCompliantsReceived) {
		this.totalCompliantsReceived = totalCompliantsReceived;
	}

	/**
	 * @return the freezedAccounts
	 */
	public String getFreezedAccounts() {
		return freezedAccounts;
	}

	/**
	 * @param freezedAccounts the freezedAccounts to set
	 */
	public void setFreezedAccounts(String freezedAccounts) {
		this.freezedAccounts = freezedAccounts;
	}

	/**
	 * @return the openComplaints
	 */
	public String getOpenComplaints() {
		return openComplaints;
	}

	/**
	 * @param openComplaints the openComplaints to set
	 */
	public void setOpenComplaints(String openComplaints) {
		this.openComplaints = openComplaints;
	}

	/**
	 * @return the closeComplaints
	 */
	public String getCloseComplaints() {
		return closeComplaints;
	}

	/**
	 * @param closeComplaints the closeComplaints to set
	 */
	public void setCloseComplaints(String closeComplaints) {
		this.closeComplaints = closeComplaints;
	}

	/**
	 * @return the successCount
	 */
	public String getSuccessCount() {
		return successCount;
	}

	/**
	 * @param successCount the successCount to set
	 */
	public void setSuccessCount(String successCount) {
		this.successCount = successCount;
	}

	/**
	 * @return the failureCount
	 */
	public String getFailureCount() {
		return failureCount;
	}

	/**
	 * @param failureCount the failureCount to set
	 */
	public void setFailureCount(String failureCount) {
		this.failureCount = failureCount;
	}

	/**
	 * @return the challengeCount
	 */
	public String getChallengeCount() {
		return challengeCount;
	}

	/**
	 * @param challengeCount the challengeCount to set
	 */
	public void setChallengeCount(String challengeCount) {
		this.challengeCount = challengeCount;
	}

	/**
	 * @return the debitCreditCard
	 */
	public String getDebitCreditCard() {
		return debitCreditCard;
	}

	/**
	 * @param debitCreditCard the debitCreditCard to set
	 */
	public void setDebitCreditCard(String debitCreditCard) {
		this.debitCreditCard = debitCreditCard;
	}

	/**
	 * @return the phonecalls
	 */
	public String getPhonecalls() {
		return phonecalls;
	}

	/**
	 * @param phonecalls the phonecalls to set
	 */
	public void setPhonecalls(String phonecalls) {
		this.phonecalls = phonecalls;
	}

	/**
	 * @return the wallet
	 */
	public String getWallet() {
		return wallet;
	}

	/**
	 * @param wallet the wallet to set
	 */
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	/**
	 * @return the ibank
	 */
	public String getIbank() {
		return ibank;
	}

	/**
	 * @param ibank the ibank to set
	 */
	public void setIbank(String ibank) {
		this.ibank = ibank;
	}

	/**
	 * @return the txnsCount
	 */
	public TxnsCount getTxnsCount() {
		return txnsCount;
	}

	/**
	 * @param txnsCount the txnsCount to set
	 */
	public void setTxnsCount(TxnsCount txnsCount) {
		this.txnsCount = txnsCount;
	}

	/**
	 * @return the statusCount
	 */
	public StatusCount getStatusCount() {
		return statusCount;
	}

	/**
	 * @param statusCount the statusCount to set
	 */
	public void setStatusCount(StatusCount statusCount) {
		this.statusCount = statusCount;
	}

	/**
	 * @return the debitCreditCardPercentage
	 */
	public String getDebitCreditCardPercentage() {
		return debitCreditCardPercentage;
	}

	/**
	 * @param debitCreditCardPercentage the debitCreditCardPercentage to set
	 */
	public void setDebitCreditCardPercentage(String debitCreditCardPercentage) {
		this.debitCreditCardPercentage = debitCreditCardPercentage;
	}

	/**
	 * @return the phonecallsPercentage
	 */
	public String getPhonecallsPercentage() {
		return phonecallsPercentage;
	}

	/**
	 * @param phonecallsPercentage the phonecallsPercentage to set
	 */
	public void setPhonecallsPercentage(String phonecallsPercentage) {
		this.phonecallsPercentage = phonecallsPercentage;
	}

	/**
	 * @return the walletPercentage
	 */
	public String getWalletPercentage() {
		return walletPercentage;
	}

	/**
	 * @param walletPercentage the walletPercentage to set
	 */
	public void setWalletPercentage(String walletPercentage) {
		this.walletPercentage = walletPercentage;
	}

	/**
	 * @return the ibankPercentage
	 */
	public String getIbankPercentage() {
		return ibankPercentage;
	}

	/**
	 * @param ibankPercentage the ibankPercentage to set
	 */
	public void setIbankPercentage(String ibankPercentage) {
		this.ibankPercentage = ibankPercentage;
	}

	/**
	 * @return the dematFraud
	 */
	public String getDematFraud() {
		return dematFraud;
	}

	/**
	 * @param dematFraud the dematFraud to set
	 */
	public void setDematFraud(String dematFraud) {
		this.dematFraud = dematFraud;
	}

	/**
	 * @return the creditCardFraud
	 */
	public String getCreditCardFraud() {
		return creditCardFraud;
	}

	/**
	 * @param creditCardFraud the creditCardFraud to set
	 */
	public void setCreditCardFraud(String creditCardFraud) {
		this.creditCardFraud = creditCardFraud;
	}

	/**
	 * @return the businessFraud
	 */
	public String getBusinessFraud() {
		return businessFraud;
	}

	/**
	 * @param businessFraud the businessFraud to set
	 */
	public void setBusinessFraud(String businessFraud) {
		this.businessFraud = businessFraud;
	}

	/**
	 * @return the yearWiseRecord
	 */
	public String getYearWiseRecord() {
		return yearWiseRecord;
	}

	/**
	 * @param yearWiseRecord the yearWiseRecord to set
	 */
	public void setYearWiseRecord(String yearWiseRecord) {
		this.yearWiseRecord = yearWiseRecord;
	}

	public Long getNoOfAck() {
		return noOfAck;
	}

	public void setNoOfAck(Long noOfAck) {
		this.noOfAck = noOfAck;
	}

	public Long getNoOftxn() {
		return noOftxn;
	}

	public void setNoOftxn(Long noOftxn) {
		this.noOftxn = noOftxn;
	}

	public Long getNoOfAckProcessed() {
		return noOfAckProcessed;
	}

	public void setNoOfAckProcessed(Long noOfAckProcessed) {
		this.noOfAckProcessed = noOfAckProcessed;
	}

	public Long getNoOftxnProcessed() {
		return noOftxnProcessed;
	}

	public void setNoOftxnProcessed(Long noOftxnProcessed) {
		this.noOftxnProcessed = noOftxnProcessed;
	}

	public Long getNoOfHoldMade() {
		return noOfHoldMade;
	}

	public void setNoOfHoldMade(Long noOfHoldMade) {
		this.noOfHoldMade = noOfHoldMade;
	}

	public BigDecimal getAmtOfHoldMade() {
		return amtOfHoldMade;
	}

	public void setAmtOfHoldMade(BigDecimal amtOfHoldMade) {
		this.amtOfHoldMade = amtOfHoldMade;
	}

	public Long getNoOfackFailed() {
		return noOfackFailed;
	}

	public void setNoOfackFailed(Long noOfackFailed) {
		this.noOfackFailed = noOfackFailed;
	}

	public Long getNoOfackSucceeded() {
		return noOfackSucceeded;
	}

	public void setNoOfackSucceeded(Long noOfackSucceeded) {
		this.noOfackSucceeded = noOfackSucceeded;
	}

	public Long getNoOfackPartiallyCompleted() {
		return noOfackPartiallyCompleted;
	}

	public void setNoOfackPartiallyCompleted(Long noOfackPartiallyCompleted) {
		this.noOfackPartiallyCompleted = noOfackPartiallyCompleted;
	}

	public BigDecimal getAmtofDisputeMade() {
		return amtofDisputeMade;
	}

	public void setAmtofDisputeMade(BigDecimal amtofDisputeMade) {
		this.amtofDisputeMade = amtofDisputeMade;
	}

	public Map<String, Long> getLayersMap() {
		return layersMap;
	}

	public void setLayersMap(Map<String, Long> layersMap) {
		this.layersMap = layersMap;
	}

	public Long getNoOfAccountsHolded() {
		return noOfAccountsHolded;
	}

	public void setNoOfAccountsHolded(Long noOfAccountsHolded) {
		this.noOfAccountsHolded = noOfAccountsHolded;
	}

	public Date getLastTxnDt() {
		return LastTxnDt;
	}

	public void setLastTxnDt(Date lastTxnDt) {
		LastTxnDt = lastTxnDt;
	}

	public Map<String, Long> getChannelMap() {
		return channelMap;
	}

	public void setChannelMap(Map<String, Long> channelMap) {
		this.channelMap = channelMap;
	}

	public Long getDigitalBlockCount() {
		return digitalBlockCount;
	}

	public void setDigitalBlockCount(Long digitalBlockCount) {
		this.digitalBlockCount = digitalBlockCount;
	}

	public String getLastTxnDtAsString() {
		return LastTxnDtAsString;
	}

	public void setLastTxnDtAsString(String lastTxnDtAsString) {
		LastTxnDtAsString = lastTxnDtAsString;
	}
	
	

}
