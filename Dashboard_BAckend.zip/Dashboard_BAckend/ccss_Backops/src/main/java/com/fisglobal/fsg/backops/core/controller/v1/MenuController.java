package com.fisglobal.fsg.backops.core.controller.v1;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.common.RMSResponse;
import com.fisglobal.fsg.backops.core.data.v1.MenuRequest;
import com.fisglobal.fsg.backops.core.data.v1.MenuRequestList;
import com.fisglobal.fsg.backops.core.entity.Menu_Master;
import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.repo.MenuRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.PaginationService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping(value = "/app/rest/v1.0/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class MenuController {

	@Inject
	private MenuRepo menuRepo;

	@Inject
	private PaginationService paginationService;

	@RequestMapping(value = "fetch/menu/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getMenuList(@RequestHeader(value = "requestid") String reqId, @PathVariable int pageSize,
			@PathVariable int page) throws Exception {

		Page<Menu_Master> pageResult = paginationService.getMenuList(pageSize, page);

		if (!pageResult.hasContent()) {
			throw new RMSException(RMSConstants.INVALID_REQUEST_CODE, RMSConstants.INVALID_REQUEST_MSG);
		}

		return new ResponseEntity<>(pageResult, HttpStatus.OK);
	}
	
	@RequestMapping(value = "list/menu", method = RequestMethod.GET)
	public ResponseEntity<?> getFullMenuList(@RequestHeader(value = "requestid") String reqId) throws Exception {

		List<Menu_Master> menulist = menuRepo.getMenulist();

		return new ResponseEntity<>(menulist, HttpStatus.OK);
	}
	
	@RequestMapping(value = "list/sidemenu/{menuid}", method = RequestMethod.GET)
	public ResponseEntity<?> getSideMenuList(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String menuid) throws Exception {

		List<Menu_Master> menulist = menuRepo.getSideMenuList(menuid);

		return new ResponseEntity<>(menulist, HttpStatus.OK);
	}

	@RequestMapping(value = "fetch/childmenu/{menuid}", method = RequestMethod.GET)
	public ResponseEntity<?> getChiledMenu(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String menuid) throws Exception {

		List<Menu_Master> childMenuList = menuRepo.getChildMenu(menuid);

		return new ResponseEntity<>(childMenuList, HttpStatus.OK);
	}

	@RequestMapping(value = "save/menu", method = RequestMethod.POST)
	public ResponseEntity<?> updateMenu(@RequestHeader(value = "requestid") String reqId,
			@RequestBody MenuRequestList requestList) throws Exception {
		RMSResponse response = new RMSResponse();

		for (MenuRequest menuRequest : requestList.getMenuRequest()) {
			Menu_Master menuMaster = new Menu_Master();
			BeanUtils.copyProperties(menuMaster, menuRequest);
			menuMaster.setModifiedDate(new java.util.Date(System.currentTimeMillis()));
			menuMaster.setInsertedDate(new java.util.Date(System.currentTimeMillis()));
			menuRepo.save(menuMaster);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
