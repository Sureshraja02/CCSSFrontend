/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author e5745290
 *
 */
@Entity
@Table(name="CCSS_CBS_TRANS_FRAUD_DETAILS")
public class CcssCBSTransactionFraudDetails_DAO {
	
	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "IDCBSFRDSEQ", sequenceName = "IDCBSFRDSEQ", allocationSize = 1)
	@Column(name = "ID")
	private Long id;
	
	
	@Column(name = "ACCOUNT_NO")
	private String accountNo;
	
	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;
	
	@Column(name = "JOB_ID")
	private String jobId;
	
	@Column(name = "FROMDATE")
	private String fromDate;
	
	@Column(name = "TODATE")
	private String toDate;
	
	@Column(name = "TITLE_CODE")
	private String titleCode;
	
	
	@Column(name = "FIRST_NAME")
	private String firstName;
	
	
	@Column(name = "MIDDLE_NAME")
	private String middleName;
	
	@Column(name = "ADDRESS_1")
	private String address1;
	
	@Column(name = "ADDRESS_2")
	private String address2;
	
	@Column(name = "ADDRESS_3")
	private String address3;
	
	@Column(name = "ADDRESS_4")
	private String address4;
	
	
	@Column(name = "LAST_NAME")
	private String lastName;
	
	@Column(name = "PIN_CODE")
	private String pinCode;
	
	@Column(name = "ISD_CODE")
	private String isdCode;
	
	@Column(name = "MOBILE")
	private String mobile;
	
	@Column(name = "EMAIL")
	private String email;
	
	
	
	@Column(name = "AVAILABLE_BALANCE")
	private BigDecimal availableBalance;
	
	@Column(name = "HOLD_AMOUNT")
	private BigDecimal holdAmount;
	
	@Column(name = "UNCLEARED_AMOUNT")
	private BigDecimal unclearedAmount;
	
	@Column(name = "CURRENT_BALANCE")
	private BigDecimal currentBalance;
	
	
	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;
	
	
	
	@Column(name = "NARRATION")
	private String narration;	
	
	@Column(name = "STATUS")
	private String status;
	
	
	@Column(name = "AMOUNT")
	private BigDecimal amount;

	
	@Column(name = "CHEQUE_NUMBER")
	private String cheque_number;
	
	@Column(name = "REMARKS")
	private String remarks;
	

	
	@Column(name = "BALANCE")
	private BigDecimal balance;
	
	@Column(name = "TRANS_REF_NO")
	private String txnRefNo;
	
	@Column(name = "CHANNEL")
	private String channel;	
	
	@Column(name = "MERCHANT_ID")
	private String MerchantId;
	
	@Column(name = "TERMINAL_ID")
	private String terminalId;
	
	@Column(name = "ATM_ID")
	private String atmId;
	
	@Column(name = "TRANS_ID")
	private String tranId;

	
	
	@Column(name = "UPDATE_DATE")
	private Timestamp updateDate;
	
	@Column(name = "CREATED_TIME")
	private Timestamp createdDate;
	
	
	@Column(name = "BENE_NAME")
	private String beneName;
	
	@Column(name = "PAYEE_VPA")
	private String payeeVpa;

	@Column(name = "OPENING_BAL")
	private BigDecimal openingBal;
	
	@Column(name = "CLOSING_BAL")
	private BigDecimal closingBal;
	
	
	@Column(name = "BENE_REMI_ACC_NUM")
	private String BeneRemiAcctNum;	
	
	@Column(name = "BENE_REMI_IFSC")
	private String BeneRemiIfsc;
	
	@Column(name = "BENE_REMI_BANK")
	private String BeneRemiBank;
	
	@Column(name = "TRANSACTION_TIME_HH24MI")
	private String TransactionTimeHH24MI;
	
	@Column(name = "ATM_PLACE")
	private String atmPlace;
	
	@Column(name = "ATM_BRANCH")
	private String atmBranch;
	
	@Column(name = "FRAUD_FG")
	private String fraud_Fg;
	
	@Column(name = "FRAUD_STATUS")
	private String fraudStatus;
	
	@Column(name = "FRAUD_AMOUNT_BALANCE")
	private BigDecimal fraudAmountBalance;
	
	@Column(name = "REM_DISPUTE_AMOUNT")
	private BigDecimal remainingDisputeBalance;
	
	
	@Column(name = "DISPUTE_AMOUNT")
	private BigDecimal disputeBalance;
	
	@Column(name = "COMPLIANT_RRN")
	private String complaintRrn;
	
	
	@Column(name = "TXN_TYPE")
	private String txnType;
	
	@Column(name = "TXN_TYPE_ID")
	private String txn_Type_Id;
	
	@Column(name = "BENE_BANK_CODE")
	private String beneBankCode;
	
	
	

	@Transient
	private String errorFlag;
	
	
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}


	



	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * @return the txnRefNo
	 */
	public String getTxnRefNo() {
		return txnRefNo;
	}

	/**
	 * @param txnRefNo the txnRefNo to set
	 */
	public void setTxnRefNo(String txnRefNo) {
		this.txnRefNo = txnRefNo;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}



	/**
	 * @return the tranId
	 */
	public String getTranId() {
		return tranId;
	}

	/**
	 * @param tranId the tranId to set
	 */
	public void setTranId(String tranId) {
		this.tranId = tranId;
	}

	/**
	 * @return the narration
	 */
	public String getNarration() {
		return narration;
	}

	/**
	 * @param narration the narration to set
	 */
	public void setNarration(String narration) {
		this.narration = narration;
	}

	
	

	/**
	 * @return the availableBalance
	 */
	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}

	/**
	 * @param availableBalance the availableBalance to set
	 */
	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}

	/**
	 * @return the holdAmount
	 */
	public BigDecimal getHoldAmount() {
		return holdAmount;
	}

	/**
	 * @param holdAmount the holdAmount to set
	 */
	public void setHoldAmount(BigDecimal holdAmount) {
		this.holdAmount = holdAmount;
	}

	/**
	 * @return the unclearedAmount
	 */
	public BigDecimal getUnclearedAmount() {
		return unclearedAmount;
	}

	/**
	 * @param unclearedAmount the unclearedAmount to set
	 */
	public void setUnclearedAmount(BigDecimal unclearedAmount) {
		this.unclearedAmount = unclearedAmount;
	}

	/**
	 * @return the currentBalance
	 */
	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	/**
	 * @param currentBalance the currentBalance to set
	 */
	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the updateDate
	 */
	public Timestamp getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the createdDate
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}


	public String getBeneName() {
		return beneName;
	}

	public void setBeneName(String beneName) {
		this.beneName = beneName;
	}

	public String getPayeeVpa() {
		return payeeVpa;
	}

	public void setPayeeVpa(String payeeVpa) {
		this.payeeVpa = payeeVpa;
	}

	public String getTitleCode() {
		return titleCode;
	}

	public void setTitleCode(String titleCode) {
		this.titleCode = titleCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getIsdCode() {
		return isdCode;
	}

	public void setIsdCode(String isdCode) {
		this.isdCode = isdCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getCheque_number() {
		return cheque_number;
	}

	public void setCheque_number(String cheque_number) {
		this.cheque_number = cheque_number;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the openingBal
	 */
	public BigDecimal getOpeningBal() {
		return openingBal;
	}

	/**
	 * @param openingBal the openingBal to set
	 */
	public void setOpeningBal(BigDecimal openingBal) {
		this.openingBal = openingBal;
	}

	/**
	 * @return the closingBal
	 */
	public BigDecimal getClosingBal() {
		return closingBal;
	}

	/**
	 * @param closingBal the closingBal to set
	 */
	public void setClosingBal(BigDecimal closingBal) {
		this.closingBal = closingBal;
	}

	
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public String getBeneRemiAcctNum() {
		return BeneRemiAcctNum;
	}

	public void setBeneRemiAcctNum(String beneRemiAcctNum) {
		BeneRemiAcctNum = beneRemiAcctNum;
	}

	public String getBeneRemiIfsc() {
		return BeneRemiIfsc;
	}

	public void setBeneRemiIfsc(String beneRemiIfsc) {
		BeneRemiIfsc = beneRemiIfsc;
	}

	public String getBeneRemiBank() {
		return BeneRemiBank;
	}

	public void setBeneRemiBank(String beneRemiBank) {
		BeneRemiBank = beneRemiBank;
	}

	public String getTransactionTimeHH24MI() {
		return TransactionTimeHH24MI;
	}

	public void setTransactionTimeHH24MI(String transactionTimeHH24MI) {
		TransactionTimeHH24MI = transactionTimeHH24MI;
	}

	public String getMerchantId() {
		return MerchantId;
	}

	public void setMerchantId(String merchantId) {
		MerchantId = merchantId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getAtmId() {
		return atmId;
	}

	public void setAtmId(String atmId) {
		this.atmId = atmId;
	}

	/**
	 * @return the errorFlag
	 */
	public String getErrorFlag() {
		return errorFlag;
	}

	/**
	 * @param errorFlag the errorFlag to set
	 */
	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	/**
	 * @return the atmPlace
	 */
	public String getAtmPlace() {
		return atmPlace;
	}

	/**
	 * @param atmPlace the atmPlace to set
	 */
	public void setAtmPlace(String atmPlace) {
		this.atmPlace = atmPlace;
	}

	/**
	 * @return the atmBranch
	 */
	public String getAtmBranch() {
		return atmBranch;
	}

	/**
	 * @param atmBranch the atmBranch to set
	 */
	public void setAtmBranch(String atmBranch) {
		this.atmBranch = atmBranch;
	}

	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}

	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the fraud_Fg
	 */
	public String getFraud_Fg() {
		return fraud_Fg;
	}

	/**
	 * @param fraud_Fg the fraud_Fg to set
	 */
	public void setFraud_Fg(String fraud_Fg) {
		this.fraud_Fg = fraud_Fg;
	}

	/**
	 * @return the fraudStatus
	 */
	public String getFraudStatus() {
		return fraudStatus;
	}

	/**
	 * @param fraudStatus the fraudStatus to set
	 */
	public void setFraudStatus(String fraudStatus) {
		this.fraudStatus = fraudStatus;
	}

	/**
	 * @return the fraudAmountBalance
	 */
	public BigDecimal getFraudAmountBalance() {
		return fraudAmountBalance;
	}

	/**
	 * @param fraudAmountBalance the fraudAmountBalance to set
	 */
	public void setFraudAmountBalance(BigDecimal fraudAmountBalance) {
		this.fraudAmountBalance = fraudAmountBalance;
	}

	/**
	 * @return the remainingDisputeBalance
	 */
	public BigDecimal getRemainingDisputeBalance() {
		return remainingDisputeBalance;
	}

	/**
	 * @param remainingDisputeBalance the remainingDisputeBalance to set
	 */
	public void setRemainingDisputeBalance(BigDecimal remainingDisputeBalance) {
		this.remainingDisputeBalance = remainingDisputeBalance;
	}

	public BigDecimal getDisputeBalance() {
		return disputeBalance;
	}

	public void setDisputeBalance(BigDecimal disputeBalance) {
		this.disputeBalance = disputeBalance;
	}

	
	/**
	 * @return the complaintRrn
	 */
	public String getComplaintRrn() {
		return complaintRrn;
	}

	/**
	 * @param complaintRrn the complaintRrn to set
	 */
	public void setComplaintRrn(String complaintRrn) {
		this.complaintRrn = complaintRrn;
	}

	/**
	 * @return the txnType
	 */
	public String getTxnType() {
		return txnType;
	}

	/**
	 * @param txnType the txnType to set
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return the txn_Type_Id
	 */
	public String getTxn_Type_Id() {
		return txn_Type_Id;
	}

	/**
	 * @param txn_Type_Id the txn_Type_Id to set
	 */
	public void setTxn_Type_Id(String txn_Type_Id) {
		this.txn_Type_Id = txn_Type_Id;
	}

	
	/**
	 * @return the beneBankCode
	 */
	public String getBeneBankCode() {
		return beneBankCode;
	}

	/**
	 * @param beneBankCode the beneBankCode to set
	 */
	public void setBeneBankCode(String beneBankCode) {
		this.beneBankCode = beneBankCode;
	}
	

}
