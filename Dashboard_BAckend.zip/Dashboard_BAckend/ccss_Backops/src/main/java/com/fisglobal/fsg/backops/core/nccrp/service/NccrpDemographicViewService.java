package com.fisglobal.fsg.backops.core.nccrp.service;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.nccrp.data.AccounDetailstListReponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.AccountListData;
import com.fisglobal.fsg.backops.core.nccrp.data.DemographicViewResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedChainRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedInterface;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_Account_DetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_SuspectedChainRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_Trans_DetailsRepo;

@Service
public class NccrpDemographicViewService {
	
	@Inject
	private Ccss_Trans_DetailsRepo trans_DetailsRepo;

	@Inject
	private Ccss_SuspectedChainRepo ccss_SuspectedChainRepo;

	@Inject
	private Ccss_Account_DetailsRepo ccss_Account_DetailsRepo;

	public AccounDetailstListReponseData getDemographicViewAccountService(SuspectedChainRequestData suspectedChainRequestData) {
		AccounDetailstListReponseData accounDetailstListReponseData = new AccounDetailstListReponseData();
		List<DemographicViewResponseData> nccrpList = null;
		if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getNewDemographicDetailsByAccountNumber(suspectedChainRequestData.getAcctNo());

		} else if (suspectedChainRequestData.getMobileNo() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getNewSuspectedChainDetailByMobileNo(suspectedChainRequestData.getMobileNo());

		} else if (suspectedChainRequestData.getTransactionId() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getNewDemographicDetailsByRRN(suspectedChainRequestData.getTransactionId());

		} else if (suspectedChainRequestData.getPan() != null) {
			nccrpList = ccss_SuspectedChainRepo.getNewDemographicDetailsByPAN(suspectedChainRequestData.getPan());

		} else if (suspectedChainRequestData.getAcknowledgementNo() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getNewDemographicDetailsByAckNo(suspectedChainRequestData.getAcknowledgementNo());

		}

		List<AccountListData> list = new ArrayList<AccountListData>();
		if (nccrpList != null && !nccrpList.isEmpty()) {
			for (DemographicViewResponseData acc : nccrpList) {
				AccountListData acclists = new AccountListData();
				acclists.setAcctNo(acc.getAcctNo());
				acclists.setCurrency(acc.getCurrency());
				acclists.setCustomerNo(acc.getCustomerNo());
				acclists.setClick(true);
				acclists.setCurrentAmount(acc.getbalance());
				acclists.setShortName(acc.getShortName());

				list.add(acclists);
			}
		}

		accounDetailstListReponseData.setAccountList(list);

		return accounDetailstListReponseData;
	}
}
