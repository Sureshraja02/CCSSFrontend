package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_SUSPECTED_DETAILS_I4C")
@Entity
@DynamicUpdate
public class SuspectDetails_I4C_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "SUSPTIDI4CSEQ", sequenceName = "SUSPTIDI4CSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACCOUNT_NUMBER")
	private String accountNo;
	@Column(name = "IFSC_CODE")
	private String ifscCode;
	@Column(name = "CIN_NUMBER")
	private String cinNumber;
	@Column(name = "ACCOUNT_HOLDER_NAME")
	private String accountHolderName;
	@Column(name = "ACCOUNT_TYPE")
	private String accountType;
	@Column(name = "PAN_NUMBER_OF_COMPANY")
	private String panNoOfCompany;
	@Column(name = "PAN_NUMBER_OF_INDIVIDUAL")
	private String panNoOfIndividual;
	@Column(name = "EMAIL_ADDRESS_OF_SUSPECT")
	private String emailOfSuspect;
	@Column(name = "PHONE_NUMBER_OF_SUSPECT")
	private String phoneNoOfSuspect;
	@Column(name = "GST_NUMBER")
	private String gstNo;
	@Column(name = "DEVICE_ID")
	private String deviceId;
	@Column(name = "WEBSITE")
	private String website;
	@Column(name = "SOURCES")
	private String source;
	@Column(name = "REMARK")
	private String remarks;
	@Column(name = "IPADDRESS")
	private String ipAddress;
	@Column(name = "OTHER_SOURCE")
	private String otherSource;
	@Column(name = "UPI_HANDLES")
	private String upi_handles;
	@Column(name = "UPDATED_TIME")
	private Date updatedTime;
	@Column(name = "CREATED_TIME")
	private Date createdTime;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "INSERTEDBYUSERID")
	private String insertedbyuserid;
	@Column(name = "SUSPECT_SCORE")
	private String suspect_score;
	@Column(name = "REQUEST_RECEIVED_STATUS")
	private String requestReceivedStatus;
	
	
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return the ifscCode
	 */
	public String getIfscCode() {
		return ifscCode;
	}

	/**
	 * @param ifscCode the ifscCode to set
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	/**
	 * @return the cinNumber
	 */
	public String getCinNumber() {
		return cinNumber;
	}

	/**
	 * @param cinNumber the cinNumber to set
	 */
	public void setCinNumber(String cinNumber) {
		this.cinNumber = cinNumber;
	}

	/**
	 * @return the accountHolderName
	 */
	public String getAccountHolderName() {
		return accountHolderName;
	}

	/**
	 * @param accountHolderName the accountHolderName to set
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * @return the panNoOfCompany
	 */
	public String getPanNoOfCompany() {
		return panNoOfCompany;
	}

	/**
	 * @param panNoOfCompany the panNoOfCompany to set
	 */
	public void setPanNoOfCompany(String panNoOfCompany) {
		this.panNoOfCompany = panNoOfCompany;
	}

	/**
	 * @return the panNoOfIndividual
	 */
	public String getPanNoOfIndividual() {
		return panNoOfIndividual;
	}

	/**
	 * @param panNoOfIndividual the panNoOfIndividual to set
	 */
	public void setPanNoOfIndividual(String panNoOfIndividual) {
		this.panNoOfIndividual = panNoOfIndividual;
	}

	/**
	 * @return the emailOfSuspect
	 */
	public String getEmailOfSuspect() {
		return emailOfSuspect;
	}

	/**
	 * @param emailOfSuspect the emailOfSuspect to set
	 */
	public void setEmailOfSuspect(String emailOfSuspect) {
		this.emailOfSuspect = emailOfSuspect;
	}

	/**
	 * @return the phoneNoOfSuspect
	 */
	public String getPhoneNoOfSuspect() {
		return phoneNoOfSuspect;
	}

	/**
	 * @param phoneNoOfSuspect the phoneNoOfSuspect to set
	 */
	public void setPhoneNoOfSuspect(String phoneNoOfSuspect) {
		this.phoneNoOfSuspect = phoneNoOfSuspect;
	}

	/**
	 * @return the gstNo
	 */
	public String getGstNo() {
		return gstNo;
	}

	/**
	 * @param gstNo the gstNo to set
	 */
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

	/**
	 * @return the deviceId
	 */
	public String getDeviceId() {
		return deviceId;
	}

	/**
	 * @param deviceId the deviceId to set
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	/**
	 * @return the website
	 */
	public String getWebsite() {
		return website;
	}

	/**
	 * @param website the website to set
	 */
	public void setWebsite(String website) {
		this.website = website;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the otherSource
	 */
	public String getOtherSource() {
		return otherSource;
	}

	/**
	 * @param otherSource the otherSource to set
	 */
	public void setOtherSource(String otherSource) {
		this.otherSource = otherSource;
	}

	/**
	 * @return the upi_handles
	 */
	public String getUpi_handles() {
		return upi_handles;
	}

	/**
	 * @param upi_handles the upi_handles to set
	 */
	public void setUpi_handles(String upi_handles) {
		this.upi_handles = upi_handles;
	}

	/**
	 * @return the updatedTime
	 */
	public Date getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	/**
	 * @return the createdTime
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the insertedbyuserid
	 */
	public String getInsertedbyuserid() {
		return insertedbyuserid;
	}

	/**
	 * @param insertedbyuserid the insertedbyuserid to set
	 */
	public void setInsertedbyuserid(String insertedbyuserid) {
		this.insertedbyuserid = insertedbyuserid;
	}

	/**
	 * @return the suspect_score
	 */
	public String getSuspect_score() {
		return suspect_score;
	}

	/**
	 * @param suspect_score the suspect_score to set
	 */
	public void setSuspect_score(String suspect_score) {
		this.suspect_score = suspect_score;
	}

	/**
	 * @return the requestReceivedStatus
	 */
	public String getRequestReceivedStatus() {
		return requestReceivedStatus;
	}

	/**
	 * @param requestReceivedStatus the requestReceivedStatus to set
	 */
	public void setRequestReceivedStatus(String requestReceivedStatus) {
		this.requestReceivedStatus = requestReceivedStatus;
	}

	

}
