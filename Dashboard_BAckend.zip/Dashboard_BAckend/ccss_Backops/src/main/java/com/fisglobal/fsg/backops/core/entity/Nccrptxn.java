package com.fisglobal.fsg.backops.core.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "NCCRPTXN")
@Entity
public class Nccrptxn {

	@Column(name = "TS")
	private LocalDateTime ts;

	@Id
	@Column(name = "TXNID")
	private String txnId;

	@Column(name = "TXNTYPE")
	private String txnType;

	@Column(name = "CHANNEL")
	private String channel;

	@Column(name = "PAYERADDR")
	private String payerAddr;

	@Column(name = "PAYEEADDR")
	private String payeeAddr;

	@Column(name = "PAYERNAME")
	private String payerName;

	@Column(name = "PAYEENAME")
	private String payeeName;

	@Column(name = "MOBILENUMBER")
	private String mobileNumber;

	@Column(name = "ACCOUNTTYPE")
	private String accountType;

	@Column(name = "AMT")
	private String amt;

	@Column(name = "STATUS")
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getTs() {
		return ts;
	}

	public void setTs(LocalDateTime ts) {
		this.ts = ts;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getPayerAddr() {
		return payerAddr;
	}

	public void setPayerAddr(String payerAddr) {
		this.payerAddr = payerAddr;
	}

	public String getPayeeAddr() {
		return payeeAddr;
	}

	public void setPayeeAddr(String payeeAddr) {
		this.payeeAddr = payeeAddr;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

}
