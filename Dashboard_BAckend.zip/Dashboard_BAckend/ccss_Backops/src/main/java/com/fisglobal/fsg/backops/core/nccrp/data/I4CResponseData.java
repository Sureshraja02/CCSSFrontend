/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class I4CResponseData {

	
	private Integer sNo;
	
	private String acctNo;
	
	private String mobileNo;
	
	private String responseMsg;
	
	private String responseCode;
	
	private String acknowledgementNo;
	
	private String message;
	

	private String complaintDate;
	
	
	

	public Integer getsNo() {
		return sNo;
	}

	public void setsNo(Integer sNo) {
		this.sNo = sNo;
	}

	/**
	 * @return the acctNo
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * @param acctNo the acctNo to set
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	
	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the complaintDate
	 */
	public String getComplaintDate() {
		return complaintDate;
	}

	/**
	 * @param complaintDate the complaintDate to set
	 */
	public void setComplaintDate(String complaintDate) {
		this.complaintDate = complaintDate;
	}

	
	
	
	
	

	
	
}
