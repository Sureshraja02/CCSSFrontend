package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.Nccrptxn;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Complaint_Details;

public interface Ccss_Complaint_DetailsRepo extends JpaRepository<Ccss_Complaint_Details, String> {

	@Query(value = "select * from CCSS_COMPLAINTS_DETAILS", nativeQuery = true)	
	List<Ccss_Complaint_Details> allDetails();

}
