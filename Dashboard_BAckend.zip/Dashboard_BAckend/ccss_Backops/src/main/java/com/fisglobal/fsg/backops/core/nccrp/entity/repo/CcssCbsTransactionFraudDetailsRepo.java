/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.entity.CcssCBSTransactionFraudDetails_DAO;

/**
 * @author e5745290
 *
 */
public interface CcssCbsTransactionFraudDetailsRepo extends JpaRepository<CcssCBSTransactionFraudDetails_DAO, Long> {

	boolean existsByAcknowledgementNo(String acknowledgementNo);

	boolean existsByComplaintRrn(String complaintRrn);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where COMPLIANT_RRN=?1 and FRAUD_FG=?2", nativeQuery = true)
	CcssCBSTransactionFraudDetails_DAO getByAcknowledgementNoAndFraud_Fg(String ackNo, String fg);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where COMPLIANT_RRN=?1 and ACCOUNT_NO=?2", nativeQuery = true)
	List<CcssCBSTransactionFraudDetails_DAO> getAllFraudDetailsByRrnandAccountNo(String complaintRrn,
			String payerAccno);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where COMPLIANT_RRN=?1 and ACCOUNT_NO=?2", nativeQuery = true)
	List<CcssCBSTransactionFraudDetails_DAO> getAllFraudDetails(String complaintRrn, String payerAccno);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where COMPLIANT_RRN=?1", nativeQuery = true)
	List<CcssCBSTransactionFraudDetails_DAO> getAllFraudDetailsByRrn(String complaintRrn);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where ACKNOWLEDGEMENT_NO=?1", nativeQuery = true)
	List<CcssCBSTransactionFraudDetails_DAO> getAllFraudDetailsByAckno(String ackno);

	@Query(value = "select * from CCSS_CBS_TRANS_FRAUD_DETAILS where COMPLIANT_RRN=?1 or ACCOUNT_NO=?2 or ACKNOWLEDGEMENT_NO=?3", nativeQuery = true)
	List<CcssCBSTransactionFraudDetails_DAO> getFraudDetailByAccntAndRrnAndAckNumber(String complaintRrn,
			String payerAccno, String AckNo);

}
