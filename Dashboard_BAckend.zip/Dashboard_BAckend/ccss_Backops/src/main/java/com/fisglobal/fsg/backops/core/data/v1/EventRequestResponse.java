package com.fisglobal.fsg.backops.core.data.v1;

import java.util.List;

public class EventRequestResponse {

	private String EVENT_TYPE;

	private String EVENT_NAME;

	private List<EventTagDetails> eventTagDetails;

	public String getEVENT_TYPE() {
		return EVENT_TYPE;
	}

	public void setEVENT_TYPE(String eVENT_TYPE) {
		EVENT_TYPE = eVENT_TYPE;
	}

	public String getEVENT_NAME() {
		return EVENT_NAME;
	}

	public void setEVENT_NAME(String eVENT_NAME) {
		EVENT_NAME = eVENT_NAME;
	}

	public List<EventTagDetails> getEventTagDetails() {
		return eventTagDetails;
	}

	public void setEventTagDetails(List<EventTagDetails> eventTagDetails) {
		this.eventTagDetails = eventTagDetails;
	}

}
