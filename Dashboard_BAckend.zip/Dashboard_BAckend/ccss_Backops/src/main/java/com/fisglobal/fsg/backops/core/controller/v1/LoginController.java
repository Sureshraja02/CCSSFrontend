package com.fisglobal.fsg.backops.core.controller.v1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.config.RMS_Config_Map;
import com.fisglobal.fsg.backops.core.data.v1.ChangePasswordRequest;
import com.fisglobal.fsg.backops.core.data.v1.ChangePasswordResponse;
import com.fisglobal.fsg.backops.core.data.v1.LoginResponseData;
import com.fisglobal.fsg.backops.core.data.v1.MenuData;
import com.fisglobal.fsg.backops.core.data.v1.UserDetails;
import com.fisglobal.fsg.backops.core.entity.Instid_Master;
import com.fisglobal.fsg.backops.core.entity.Menu_Master;
import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.repo.InstitutionRepo;
import com.fisglobal.fsg.backops.core.entity.repo.MenuMasterRepo;
import com.fisglobal.fsg.backops.core.entity.repo.RMSConfigRepo;
import com.fisglobal.fsg.backops.core.entity.repo.UserMasterRepo;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.service.v1.JwtService;
import com.fisglobal.fsg.backops.core.utils.UserMasterUtils;

@RestController
@RequestMapping(value = "/app/rest/v1.0/service/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class LoginController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@Inject
	private UserMasterRepo userMasterRepo;

	@Inject
	private MenuMasterRepo menuMasterRepo;

	@Inject
	private UserMasterUtils userMasterUtils;

	@Inject
	private RMSConfigRepo rmsConfigRepo;

	@Inject
	private RMS_Config_Map configMap;

	@Inject
	private InstitutionRepo institutionRepo;

	@Inject
	private JwtService tokenService;

	@RequestMapping(value = "changepassword", method = RequestMethod.POST)
	public ResponseEntity<ChangePasswordResponse> changePassword(@RequestHeader(value = "requestid") String reqId,
			@RequestBody ChangePasswordRequest request) throws RMSException {
		ChangePasswordResponse response = new ChangePasswordResponse();
		User_Master userMaster = userMasterRepo.getLoginData(request.getUserId(), request.getOldpassword());
		if (userMaster != null) {
			userMaster.setPassword(request.getNewpassword());
			userMaster.setPasswordDate(LocalDateTime.now());
			userMasterRepo.save(userMaster);
			response.setErrorcode("00");
			response.setStatus("Success");
		} else {
			LOGGER.info("User Not Found [{}] errorCode[{}] message[{}]", request.getUserId(),
					RMSConstants.INVALID_CREDENTIALS_CODE, RMSConstants.INVALID_CREDENTIALS_MSG);
			throw new RMSException(RMSConstants.INVALID_CREDENTIALS_CODE, RMSConstants.INVALID_CREDENTIALS_MSG);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "login/{email}/{password}", method = RequestMethod.GET)
	public ResponseEntity<LoginResponseData> login(@RequestHeader(value = "requestid") String reqId,
			@PathVariable String email, @PathVariable String password) throws RMSException {
		List<String> moduleName = new ArrayList<String>();
		HashMap<String, String> moduleList = new HashMap<String, String>();
		LoginResponseData response = new LoginResponseData();

		System.out.println(password);

		User_Master userMaster = userMasterRepo.getLoginData(email, password);

		LOGGER.info("into user login [{}] ", userMaster);

		if (userMaster != null) {
			Optional<Instid_Master> instDetails = institutionRepo.findById(Long.parseLong(userMaster.getInstID()));
			LOGGER.info("User Found [{}]", email);
			boolean passwordStatus = userMasterUtils.checkpassworddate(userMaster.getPasswordDate());
			UserDetails userDetails = new UserDetails();
			if (passwordStatus) {
				userDetails.setPasswordExpired(true);
			}

			if ("1".equals(userMaster.getStatus())) {
				userDetails.setFirstTimeLogin(true);
			}

			userDetails.setGroupID(userMaster.getGroupID());
			userDetails.setPasswordDate(userMaster.getPasswordDate().toString());
			userDetails.setUserType(userMaster.getUserType());

			userDetails.setUserName(userMaster.getUserName());

			if (instDetails.isPresent()) {
				userDetails.setAppDangerColor(instDetails.get().getAppDangerColor());
				userDetails.setAppInfoColor(instDetails.get().getAppInfoColor());
				// userDetails.setAppLogo(instDetails.get().getOrgLogo());
				userDetails.setAppPrimaryColor(instDetails.get().getOrgPrimaryColor());
				userDetails.setAppSecondaryColor(instDetails.get().getOrgSecondaryColor());
				userDetails.setAppSuccessColor(instDetails.get().getAppSuccessColor());
				userDetails.setAppWarningColor(instDetails.get().getAppWarningColor());
			}

			// Get Menu Details
			LOGGER.info("Fetching menu list for user [{}]", userDetails.getUserName());
			List<Menu_Master> menulist = menuMasterRepo.getmenuData(userMaster.getGroupID());
			LOGGER.info("[{}] No of menu linked for this user [{}]", menulist.size(), userDetails.getUserName());
			LOGGER.info("[{}] Size", configMap.rmsConfigMap.size());
			List<MenuData> list = new ArrayList<MenuData>();
			for (Menu_Master master : menulist) {
				MenuData menuData = new MenuData();
				menuData.setTid(master.getMenuID());

				menuData.setLabel(master.getMenuName());
				menuData.setPage(master.getPage());
				menuData.setPath(master.getPath());
				menuData.setSid(master.getSid());
				menuData.setSubmenu(master.getSubMenu());
				menuData.setIcon(master.getIcons());
				if (!master.getMenuID().equals(master.getParentMenuID())) {
					menuData.setParentTId(master.getParentMenuID());
				}

				System.out.println("module name : " + master.getModule());

				menuData.setModule(configMap.rmsConfigMap.get(String.valueOf(master.getModule())));
				moduleList.put(String.valueOf(master.getModule()),
						configMap.rmsConfigMap.get(String.valueOf(master.getModule())));
				list.add(menuData);
			}

			LOGGER.info("Fetching modules list for user [{}]", userDetails.getUserName());

			List<String> listModules = new ArrayList<String>(moduleList.values());

			for (String module : listModules) {
				moduleName.add(module);
			}

			response.setMenu(list);
			response.setModules(listModules);
			response.setUserDetails(userDetails);

			// Creating Token
			response.setAuthToken(tokenService.GenerateToken(email));

			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			LOGGER.info("User Not Found [{}] errorCode[{}] message[{}]", email, RMSConstants.INVALID_CREDENTIALS_CODE,
					RMSConstants.INVALID_CREDENTIALS_MSG);
			throw new RMSException(RMSConstants.INVALID_CREDENTIALS_CODE, RMSConstants.INVALID_CREDENTIALS_MSG);
		}

		// Creating Token
		// response.setAuthToken(tokenService.GenerateToken(email));

//		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
