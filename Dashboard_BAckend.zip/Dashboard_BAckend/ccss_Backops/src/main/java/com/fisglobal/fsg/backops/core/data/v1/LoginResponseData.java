package com.fisglobal.fsg.backops.core.data.v1;

import java.util.List;

public class LoginResponseData {

	private UserDetails userDetails;

	private List<MenuData> menu;

	private List<String> modules;

	private String authToken;

	public List<String> getModules() {
		return modules;
	}

	public void setModules(List<String> modules) {
		this.modules = modules;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public List<MenuData> getMenu() {
		return menu;
	}

	public void setMenu(List<MenuData> menu) {
		this.menu = menu;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

}
