/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.Nccrptxn;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Trans_Details;

/**
 * @author e5745290
 *
 */
public interface Ccss_Trans_DetailsRepo extends JpaRepository<Ccss_Trans_Details, String> {

	@Query(value = "select * from CCSS_TRANS_DETAILS", nativeQuery = true)	
	List<Nccrptxn> allDetails();

}
