/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_CBS_Account_Details;

/**
 * @author e5745290
 *
 */
public interface Ccss_CBS_Account_DetailsRepo extends JpaRepository<Ccss_CBS_Account_Details, String> {

}
