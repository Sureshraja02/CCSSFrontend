package com.fisglobal.fsg.backops.core.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RMS_RULE_TABLE")
public class RMS_Rule {

	@Id
	@Column(name = "RULE_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ruleId;

	@Column(name = "EVENTDATA")
	private String eventName;

	@Column(name = "CONDITION")
	private String condition;

	@Column(name = "ACTION")
	private String action;

	@Column(name = "PRIORITY")
	private int priority;

	@Column(name = "DESCRIPTION")
	private String desc;

	@Column(name = "EVENTTYPE")
	private String eventType;

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public long getRuleId() {
		return ruleId;
	}

	public void setRuleId(long ruleId) {
		this.ruleId = ruleId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
