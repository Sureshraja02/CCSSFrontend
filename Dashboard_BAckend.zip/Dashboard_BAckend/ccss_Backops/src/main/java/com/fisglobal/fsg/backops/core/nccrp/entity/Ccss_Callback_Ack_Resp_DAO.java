package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;

@Table(name = "CCSS_CALLBACK_ACK_RESP")
@Entity
@DynamicUpdate
public class Ccss_Callback_Ack_Resp_DAO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "CLBKACKRSPIDSEQ", sequenceName = "CLBKACKRSPIDSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Column(name = "JOBID")
	private String jobId;

	@Column(name = "RESP_CODE")
	private String respCode;
	
	@Column(name = "RESP_MSG")
	private String respMsg;
	@Column(name = "STATUS_CODE")
	private String statusCode;
	@Column(name = "STATUS_MSG")
	private String statusMsg;
	@Column(name = "MESSAGE")
	private String message;
	@Column(name = "DATE_TIME")
	private String dateWithTime;

	@Column(name = "ENC_I4C_ACK_RESP")
	private Blob encI4cAckResp;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ENTRY_DATETIME", columnDefinition = "TIMESTAMP")
	private Date entryDateTime;

	@Column(name = "REMARKS")
	private String remarks;
	
	@Column(name = "ACK_TYPE")
	private String ackType;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public Date getEntryDateTime() {
		return entryDateTime;
	}

	public void setEntryDateTime(Date entryDateTime) {
		this.entryDateTime = entryDateTime;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDateWithTime() {
		return dateWithTime;
	}

	public void setDateWithTime(String dateWithTime) {
		this.dateWithTime = dateWithTime;
	}

	public Blob getEncI4cAckResp() {
		return encI4cAckResp;
	}

	public void setEncI4cAckResp(Blob encI4cAckResp) {
		this.encI4cAckResp = encI4cAckResp;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAckType() {
		return ackType;
	}

	public void setAckType(String ackType) {
		this.ackType = ackType;
	}
}
