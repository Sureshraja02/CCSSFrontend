/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_UPLOAD_COMPLAINT_FILE_DETAILS")
@Entity
public class Ccss_FileUploadData {


		@Id
		@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
		@SequenceGenerator(name = "IDFILESEQ", sequenceName = "IDFILESEQ", allocationSize = 1)
		private String Id;
		
		
		
		

		@Column(name = "USERNAME")
		private String username;

		@Column(name = "FILENAME")
		private String fileName;

		@Column(name = "UPLOAD_DATE")
		private String uploadDate;	
		
		
		@Column(name = "REQUESTOR")
		private String requestor;

		@Column(name = "UPLOAD_FILE_ID")
		private String uploadFileId;

		/**
		 * @return the id
		 */
		public String getId() {
			return Id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			Id = id;
		}

		/**
		 * @return the username
		 */
		public String getUsername() {
			return username;
		}

		/**
		 * @param username the username to set
		 */
		public void setUsername(String username) {
			this.username = username;
		}

		/**
		 * @return the fileName
		 */
		public String getFileName() {
			return fileName;
		}

		/**
		 * @param fileName the fileName to set
		 */
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		/**
		 * @return the uploadDate
		 */
		public String getUploadDate() {
			return uploadDate;
		}

		/**
		 * @param uploadDate the uploadDate to set
		 */
		public void setUploadDate(String uploadDate) {
			this.uploadDate = uploadDate;
		}

		/**
		 * @return the requestor
		 */
		public String getRequestor() {
			return requestor;
		}

		/**
		 * @param requestor the requestor to set
		 */
		public void setRequestor(String requestor) {
			this.requestor = requestor;
		}

		/**
		 * @return the uploadFileId
		 */
		public String getUploadFileId() {
			return uploadFileId;
		}

		/**
		 * @param uploadFileId the uploadFileId to set
		 */
		public void setUploadFileId(String uploadFileId) {
			this.uploadFileId = uploadFileId;
		}
		
		
		
}
