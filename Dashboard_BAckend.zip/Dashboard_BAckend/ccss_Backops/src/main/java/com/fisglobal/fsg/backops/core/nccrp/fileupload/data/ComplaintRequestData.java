/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.fileupload.data;

/**
 * @author e5745290
 *
 */
public class ComplaintRequestData {

	private String filename;
	
	private String fileType;
	
	private String uploadtype;

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * @return the uploadtype
	 */
	public String getUploadtype() {
		return uploadtype;
	}

	/**
	 * @param uploadtype the uploadtype to set
	 */
	public void setUploadtype(String uploadtype) {
		this.uploadtype = uploadtype;
	}
	
	
	
}
