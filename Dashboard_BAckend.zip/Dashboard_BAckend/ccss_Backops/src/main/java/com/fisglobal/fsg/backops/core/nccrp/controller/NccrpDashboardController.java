/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.controller;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.nccrp.data.AccounDetailstListReponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.DashBoardData;
import com.fisglobal.fsg.backops.core.nccrp.data.IfscCodeBankDetails;
import com.fisglobal.fsg.backops.core.nccrp.data.IfsccodeSearchRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.IfsccodeSearchResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedChainRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedChainResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchResponseData;
import com.fisglobal.fsg.backops.core.nccrp.entity.CcssEmailCaseList;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Trans_Details;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadResponseData;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.service.FileDownloadService;
import com.fisglobal.fsg.backops.core.nccrp.service.NccrpDashboardService;
import com.fisglobal.fsg.backops.core.nccrp.service.NccrpDemographicViewService;
import com.fisglobal.fsg.backops.core.nccrp.service.NccrpSuspectedChainService;
import com.fisglobal.fsg.backops.core.nccrp.service.NccrpTransactionService;

/**
 * @author e5745290
 *
 */

@RestController
@RequestMapping(value = "/app/rest/v1.0/service/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin
public class NccrpDashboardController {

	@Inject
	private NccrpDashboardService dashboardService;

	@Inject
	private NccrpSuspectedChainService nccrpSuspectedChainService;

	@Inject
	private NccrpTransactionService nccrpTransactionService;

	@Inject
	private NccrpDemographicViewService nccrpDemographicViewService;
	
	 @Autowired
	 FileDownloadService fileDownloadService;
	
	 private final Path fileStorageLocation = Paths.get("Report_Download").toAbsolutePath().normalize();

	@RequestMapping(value = "nccrpdashboard", method = RequestMethod.GET)
	public ResponseEntity<?> dashboard(@RequestParam(name = "timeline", required = false) String timeline) {

		if (timeline == null)
			timeline = "TODAY";
		DashBoardData response = dashboardService.getDashboardDetails(timeline);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpsuspectedChain", method = RequestMethod.POST)
	public ResponseEntity<?> suspectedChain(@RequestBody SuspectedChainRequestData data) {

		SuspectedChainResponseData response = nccrpSuspectedChainService.getSuspectedChainDetails(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpsuspectedChainv2", method = RequestMethod.POST)
	public ResponseEntity<?> suspectedChainv2(@RequestBody SuspectedChainRequestData data) throws RMSException {

		SuspectedChainResponseData response = nccrpSuspectedChainService.getSuspectedChainDetailsv2(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpsuspectedChainForRoot", method = RequestMethod.POST)
	public ResponseEntity<?> suspectedChainforRoot(@RequestBody SuspectedChainRequestData data) throws RMSException {

		SuspectedChainResponseData response = nccrpSuspectedChainService.getSuspectedDetailForRoot(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpgetsupsectedHoldstatus", method = RequestMethod.POST)
	public ResponseEntity<?> nccrpgetsupsectedHoldstatus(@RequestBody SuspectedChainRequestData data)
			throws RMSException {

		SuspectedChainResponseData response = nccrpSuspectedChainService.getSuspectedDetailForRoot(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpdemographicView", method = RequestMethod.POST)
	public ResponseEntity<?> getSuspectedChainByMobileNumber(@RequestBody SuspectedChainRequestData data) {

		AccounDetailstListReponseData response = nccrpSuspectedChainService.getDemographicDetails(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpdemographicAccountInfo", method = RequestMethod.POST)
	public ResponseEntity<?> getDemographicAccountInfo(@RequestBody SuspectedChainRequestData data) {

		AccounDetailstListReponseData response = nccrpSuspectedChainService.getDemographicAccountInfo(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpTransactionHistory/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getNccrp(@PathVariable int pageSize, @PathVariable int page) {
		Page<Ccss_Trans_Details> response = nccrpTransactionService.getTransactionHistory(pageSize, page);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "save/email", method = RequestMethod.POST)
	public ResponseEntity<?> getNccrpEmailsave(@RequestBody CcssEmailCaseList emailCase) {
		CcssEmailCaseList response = nccrpTransactionService.storeEmailCaseList(emailCase);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrp/email/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getNccrpEmail(@PathVariable int pageSize, @PathVariable int page) {
		Page<CcssEmailCaseList> response = nccrpTransactionService.getEmailCaseList(pageSize, page);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpComplaintHistory/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getNccrpComplainHistory(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "acknowledgementNo", required = false) String requestData) {

		if (requestData != null) {
			return new ResponseEntity<>(nccrpTransactionService.getNccrpComplaintHistory(pageSize, page, requestData),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<>(nccrpTransactionService.getNccrpComplaintHistory(pageSize, page),
					HttpStatus.OK);
		}

	}

	@RequestMapping(value = "nccrpComplaintstatus/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getNccrpComplainstatus(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "acknowledgementNo", required = false) String requestData) {

		if (requestData != null) {
			return new ResponseEntity<>(nccrpTransactionService.getNccrpComplaintstatus(pageSize, page, requestData),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<>(nccrpTransactionService.getNccrpComplaintstatus(pageSize, page, null),
					HttpStatus.OK);
		}

	}

	@RequestMapping(value = "ccsssuspectedChain", method = RequestMethod.POST)
	public ResponseEntity<?> ccsssuspectedChain(@RequestBody TransactionSearchRequestData data) {

		TransactionSearchResponseData response = nccrpSuspectedChainService
				.getSuspectedChainDetailsByAccountorRRN(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "transactionSearchPage", method = RequestMethod.POST)
	public ResponseEntity<TransactionSearchResponseData> transactionSearchPage(
			@RequestBody TransactionSearchRequestData data) throws JsonProcessingException {

		TransactionSearchResponseData response = nccrpTransactionService.transactionSearchPage(data);
		ObjectMapper objectMapper = new ObjectMapper();

		return new ResponseEntity<TransactionSearchResponseData>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "nccrpDemographicView", method = RequestMethod.POST)
	public ResponseEntity<?> nccrpDemographicView(@RequestBody SuspectedChainRequestData data) {

		AccounDetailstListReponseData response = nccrpDemographicViewService.getDemographicViewAccountService(data);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "ifsccodesearch", method = RequestMethod.POST)
	public ResponseEntity<IfsccodeSearchResponseData> ifsccodesearch(@RequestBody IfsccodeSearchRequestData request)
			throws JsonProcessingException {

		IfsccodeSearchResponseData response = nccrpTransactionService.ifsccodesearch(request);
		return new ResponseEntity<IfsccodeSearchResponseData>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "getFullySuccessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getFullySuccessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getFullySuccessRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	
	@RequestMapping(value = "getDigitalBlockRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getDigitalBlockRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getDigitalBlockRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	@RequestMapping(value = "getFullyFailedRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getFullyFailedRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getFullyFailedRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	@RequestMapping(value = "getPartialSuccessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getPartialSuccessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getPartialSuccessRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	@RequestMapping(value = "downlaodPartialSuccessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downlaodPartialSuccessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData = nccrpTransactionService.downlaodPartialSuccessRecord(pageSize, page, timeline);
			    return new ResponseEntity<>(responseData, HttpStatus.OK);
			
		}

	}
	@RequestMapping(value = "downloadFullyFailedRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadFullyFailedRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData=nccrpTransactionService.downloadFullyFailedRecord(pageSize, page, timeline);
			 return new ResponseEntity<>(responseData,HttpStatus.OK);
		}

	}
	
	@RequestMapping(value = "downlaodFullySuccessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downlaodFullySuccessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData=nccrpTransactionService.downlaodFullySuccessRecord(pageSize, page, timeline);
			 return new ResponseEntity<>(responseData,HttpStatus.OK);
		}

	}
	
	@RequestMapping(value = "downlaodDigitalRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downlaodDigitalRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData=nccrpTransactionService.downlaodDigitalBlockRecords(pageSize, page, timeline);
			 return new ResponseEntity<>(responseData,HttpStatus.OK);
		}
		 
	}
	
	@RequestMapping(value = "ifscCodeInsertApi", method = RequestMethod.POST)
	public ResponseEntity<?> ifscCodeInsertApi(@RequestBody IfscCodeBankDetails data) {
 
		String response = dashboardService.insertIfscCode(data);
 
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "getFullyFailedTechnicalRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getFullyFailedTechnicalRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getFullyFailedTechnicalRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	@RequestMapping(value = "getPartialSuccessTechnicalRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getPartialSuccessTechnicalRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getPartialSuccessTechnicalRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	
	@RequestMapping(value = "getFullyFailedBusinessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getFullyFailedBusinessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getFullyFailedBusinessRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	@RequestMapping(value = "getPartialSuccessBusinessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> getPartialSuccessBusinessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			return new ResponseEntity<>(nccrpTransactionService.getPartialSuccessBusinessRecord(pageSize, page, timeline),
					HttpStatus.OK);
		}

	}
	
	@RequestMapping(value = "downloadFullyFailedTechnicalRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadFullyFailedTechnicalRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData=nccrpTransactionService.downloadFullyFailedTechnicalRecord(pageSize, page, timeline);
			 return new ResponseEntity<>(responseData,HttpStatus.OK);
		}

	}
	
	
	
	@RequestMapping(value = "downloadFullyFailedBusinessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadFullyFailedBusinessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData=nccrpTransactionService.downloadFullyFailedBusinessRecord(pageSize, page, timeline);
			 return new ResponseEntity<>(responseData,HttpStatus.OK);
		}

	}
	

	@RequestMapping(value = "downlaodPartialSuccessTechnicalRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downlaodPartialSuccessTechnicalRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData = nccrpTransactionService.downlaodPartialSuccessTechnicalRecord(pageSize, page, timeline);
			    return new ResponseEntity<>(responseData, HttpStatus.OK);
			
		}

	}
	
	@RequestMapping(value = "downlaodPartialSuccessBusinessRecord/{pageSize}/{page}", method = RequestMethod.GET)
	public ResponseEntity<?> downlaodPartialSuccessBusinessRecord(@PathVariable int pageSize, @PathVariable int page,
			@RequestParam(name = "timeline", required = false) String timeline) {

		 {
			 DownloadResponseData responseData = nccrpTransactionService.downlaodPartialSuccessBusinessRecord(pageSize, page, timeline);
			    return new ResponseEntity<>(responseData, HttpStatus.OK);
			
		}

	}
	
}
