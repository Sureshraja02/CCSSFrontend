/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.fileupload.data;

/**
 * @author e5745290
 *
 */
public class BeneficiaryData {

	private String recordFg;
	
	private String csvContent;
	
	private String status;
	
	private String fileName;

	/**
	 * @return the recordFg
	 */
	public String getRecordFg() {
		return recordFg;
	}

	/**
	 * @param recordFg the recordFg to set
	 */
	public void setRecordFg(String recordFg) {
		this.recordFg = recordFg;
	}

	/**
	 * @return the csvContent
	 */
	public String getCsvContent() {
		return csvContent;
	}

	/**
	 * @param csvContent the csvContent to set
	 */
	public void setCsvContent(String csvContent) {
		this.csvContent = csvContent;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	

}
