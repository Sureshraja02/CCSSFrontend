/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

/**
 * @author e5745290
 *
 */
public class IfsccodeSearchResponseData {

	private List<BankDetailsData> bankDetails;

	/**
	 * @return the bankDetails
	 */
	public List<BankDetailsData> getBankDetails() {
		return bankDetails;
	}

	/**
	 * @param bankDetails the bankDetails to set
	 */
	public void setBankDetails(List<BankDetailsData> bankDetails) {
		this.bankDetails = bankDetails;
	}
	
	

	
	
	
}
