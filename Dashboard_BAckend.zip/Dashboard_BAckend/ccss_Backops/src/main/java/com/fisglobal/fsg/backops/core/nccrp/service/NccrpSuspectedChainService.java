/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.expection.RMSException;
import com.fisglobal.fsg.backops.core.nccrp.data.AccounDetailstListReponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.AccountListData;
import com.fisglobal.fsg.backops.core.nccrp.data.ChannelStatisticsData;
import com.fisglobal.fsg.backops.core.nccrp.data.I4CCallBackRequest;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedChainRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedChainResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.SuspectedInterface;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchResponseData;
import com.fisglobal.fsg.backops.core.nccrp.entity.CcssCBSTransactionFraudDetails_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssCbsTransactionFraudDetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_Account_DetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_SuspectedChainRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_Trans_DetailsRepo;

/**
 * @author e5745290
 *
 */
@Service
public class NccrpSuspectedChainService {

	@Inject
	private Ccss_Trans_DetailsRepo trans_DetailsRepo;

	@Inject
	private Ccss_SuspectedChainRepo ccss_SuspectedChainRepo;

	@Inject
	private Ccss_Account_DetailsRepo ccss_Account_DetailsRepo;

	@Inject
	private CcssCbsTransactionFraudDetailsRepo fraudDetailsRepo;
	
	
	public SuspectedChainResponseData nccrpgetsupsectedHoldstatus(SuspectedChainRequestData suspectedChainRequestData) throws RMSException {
		SuspectedChainResponseData suspectedChainResponseData = new SuspectedChainResponseData();

		if (suspectedChainRequestData.getRrn() != null) {
			// check acknowledgment Exists
			boolean fraudisPresent = fraudDetailsRepo.existsByComplaintRrn(suspectedChainRequestData.getRrn());

			// if not present return
			if (!fraudisPresent)
				throw new RMSException(RMSConstants.VALIDATION_ERROR_CODE, RMSConstants.VALIDATION_ERROR_MSG);

			CcssCBSTransactionFraudDetails_DAO fraudDetails = fraudDetailsRepo
					.getByAcknowledgementNoAndFraud_Fg(suspectedChainRequestData.getRrn(), "R");
			suspectedChainResponseData.setFraudDetail(fraudDetails);
			return suspectedChainResponseData;

		}
		return suspectedChainResponseData;
		
	}

	public SuspectedChainResponseData getSuspectedDetailForRoot(SuspectedChainRequestData suspectedChainRequestData)
			throws RMSException {

		SuspectedChainResponseData suspectedChainResponseData = new SuspectedChainResponseData();

		if (suspectedChainRequestData.getRrn() != null) {
			// check acknowledgment Exists
			boolean fraudisPresent = fraudDetailsRepo.existsByComplaintRrn(suspectedChainRequestData.getRrn());

			// if not present return
			if (!fraudisPresent)
				throw new RMSException(RMSConstants.VALIDATION_ERROR_CODE, RMSConstants.VALIDATION_ERROR_MSG);

			CcssCBSTransactionFraudDetails_DAO fraudDetails = fraudDetailsRepo
					.getByAcknowledgementNoAndFraud_Fg(suspectedChainRequestData.getRrn(), "R");
			suspectedChainResponseData.setFraudDetail(fraudDetails);
			return suspectedChainResponseData;

		}
		return suspectedChainResponseData;
	}

	public SuspectedChainResponseData getSuspectedChainDetailsv2(SuspectedChainRequestData suspectedChainRequestData)
			throws RMSException {
		SuspectedChainResponseData suspectedChainResponseData = new SuspectedChainResponseData();
		List<SuspectedInterface> nccrpList = null;

		if (suspectedChainRequestData.getAcknowledgementNo() != null) {

			// check acknowledgment Exists
			boolean fraudisPresent = fraudDetailsRepo
					.existsByAcknowledgementNo(suspectedChainRequestData.getAcknowledgementNo());

			// if not present return
			if (!fraudisPresent)
				throw new RMSException(RMSConstants.VALIDATION_ERROR_CODE, RMSConstants.VALIDATION_ERROR_MSG);

			List<CcssCBSTransactionFraudDetails_DAO> fraudDetails = fraudDetailsRepo
					.getAllFraudDetailsByAckno(suspectedChainRequestData.getAcknowledgementNo());
			suspectedChainResponseData.setFraudDetails(fraudDetails);
			return suspectedChainResponseData;

		} else if (suspectedChainRequestData.getRrn() != null) {
			// check acknowledgment Exists
			boolean fraudisPresent = fraudDetailsRepo.existsByComplaintRrn(suspectedChainRequestData.getRrn());

			// if not present return
			if (!fraudisPresent)
				throw new RMSException(RMSConstants.VALIDATION_ERROR_CODE, RMSConstants.VALIDATION_ERROR_MSG);

			List<CcssCBSTransactionFraudDetails_DAO> fraudDetails = fraudDetailsRepo
					.getAllFraudDetailsByRrn(suspectedChainRequestData.getRrn());
			suspectedChainResponseData.setFraudDetails(fraudDetails);
			return suspectedChainResponseData;

		} else if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainByAccountNo(suspectedChainRequestData.getAcctNo());

		} else {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainBymobileNo(suspectedChainRequestData.getMobileNo());

		}
		suspectedChainResponseData.setSuspectedInterface(nccrpList);

		return suspectedChainResponseData;
	}

	public SuspectedChainResponseData getSuspectedChainDetails(SuspectedChainRequestData suspectedChainRequestData) {

		SuspectedChainResponseData suspectedChainResponseData = new SuspectedChainResponseData();
		List<SuspectedInterface> nccrpList = null;
		if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainByAccountNo(suspectedChainRequestData.getAcctNo());

		} else {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainBymobileNo(suspectedChainRequestData.getMobileNo());

		}

		suspectedChainResponseData.setSuspectedInterface(nccrpList);

		return suspectedChainResponseData;
	}

	public AccounDetailstListReponseData getDemographicDetails(SuspectedChainRequestData suspectedChainRequestData) {
		AccounDetailstListReponseData accounDetailstListReponseData = new AccounDetailstListReponseData();
		List<SuspectedInterface> nccrpList = null;
		if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getDemographicDetailsByAccountNo(suspectedChainRequestData.getAcctNo());

		} else if (suspectedChainRequestData.getMobileNo() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getDemographicDetailsByMobileNo(suspectedChainRequestData.getMobileNo());

		} else if (suspectedChainRequestData.getTransactionId() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getDemographicDetailsByTransactionId(suspectedChainRequestData.getTransactionId());

		} else if (suspectedChainRequestData.getPan() != null) {
			nccrpList = ccss_SuspectedChainRepo.getDemographicDetailsByPAN(suspectedChainRequestData.getPan());

		} else if (suspectedChainRequestData.getAcknowledgementNo() != null) {
			nccrpList = ccss_SuspectedChainRepo
					.getDemographicDetailsByAcknowledgement(suspectedChainRequestData.getAcknowledgementNo());

		}

		List<AccountListData> list = new ArrayList<AccountListData>();
		if (nccrpList != null && !nccrpList.isEmpty()) {
			for (SuspectedInterface acc : nccrpList) {
				AccountListData acclists = new AccountListData();
				acclists.setAcctNo(acc.getAcctNo());
				acclists.setCurrency(acc.getCurrency());
				acclists.setCustomerNo(acc.getCustomerNo());
				acclists.setClick(true);
				acclists.setCurrentAmount(acc.getbalance());
				acclists.setShortName(acc.getShortName());

				list.add(acclists);
			}
		}

		accounDetailstListReponseData.setAccountList(list);

		return accounDetailstListReponseData;
	}

	public AccounDetailstListReponseData getDemographicAccountInfo(
			SuspectedChainRequestData suspectedChainRequestData) {
		AccounDetailstListReponseData accounDetailstListReponseData = new AccounDetailstListReponseData();
		List<SuspectedInterface> nccrpList = null;
		List<ChannelStatisticsData> channelStatisticsListData = new ArrayList<>();
		Double totalDebit = 0.0d;
		ChannelStatisticsData channelStatisticsData = new ChannelStatisticsData();
		Double totalCredit = 0.0d;

		Long totalCreditCount = 0L;

		Long totalDebitCount = 0L;
		if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getDemographicAccountInfo(suspectedChainRequestData.getAcctNo());

		}

		List<AccountListData> list = new ArrayList<AccountListData>();

		if (nccrpList != null && !nccrpList.isEmpty()) {

			for (SuspectedInterface acc : nccrpList) {
				if (acc.getRootAccountNumber() != null && acc.getRootAccountNumber().equals(acc.getAcctNo())
						&& acc.getAmount() != null) {
					totalDebit += Double.parseDouble(acc.getAmount());
					totalDebitCount += 1L;
				}
				if (acc.getPayeeAcctNumber() != null && acc.getPayeeAcctNumber().equals(acc.getAcctNo())
						&& acc.getAmount() != null) {
					totalCredit += Double.parseDouble(acc.getAmount());
					totalCreditCount += 1L;
				}

			}

			long atmChannelCount = nccrpList.stream()
					.filter(c -> c.getTxnType().contains("ATM") || c.getTxnType().contains("Debit")).count();

			long ibChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("Internet")).count();

			long fraudChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("Call")).count();

			long creditChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("Credit")).count();

			long businessChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("Business")).count();

			long ewalletChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("E-Wallet")).count();

			long dematChannelCount = nccrpList.stream().filter(c -> c.getTxnType().contains("Demat")).count();

			long totalChannelCount = nccrpList.stream()
					.filter(c -> c.getTxnType().contains("Credit") || c.getTxnType().contains("Call")
							|| c.getTxnType().contains("Business") || c.getTxnType().contains("E-Wallet")
							|| c.getTxnType().contains("Demat") || c.getTxnType().contains("Internet")
							|| c.getTxnType().contains("Debit"))
					.count();

			long upiChannelCount = 0L;
			channelStatisticsData.setTxnType("Debit Card Fraud");
			channelStatisticsData.setTotalCount(String.valueOf(atmChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setPending(String.valueOf(atmChannelCount));
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);
			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("Internet Banking");
			channelStatisticsData.setTotalCount(String.valueOf(ibChannelCount));
			channelStatisticsData.setPending(String.valueOf(ibChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);
			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("Fraud Call");
			channelStatisticsData.setTotalCount(String.valueOf(fraudChannelCount));
			channelStatisticsData.setPending(String.valueOf(fraudChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);
			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("E-Wallet");
			channelStatisticsData.setTotalCount(String.valueOf(ewalletChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setPending(String.valueOf(ewalletChannelCount));
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);
			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("Business Email");
			channelStatisticsData.setTotalCount(String.valueOf(businessChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setPending(String.valueOf(businessChannelCount));
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);

			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("Demat /Depository Fraud");
			channelStatisticsData.setTotalCount(String.valueOf(dematChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setPending(String.valueOf(dematChannelCount));
			channelStatisticsData.setFailure("0");
			channelStatisticsListData.add(channelStatisticsData);

			channelStatisticsData = new ChannelStatisticsData();
			channelStatisticsData.setTxnType("Credit Card Fraud");
			channelStatisticsData.setTotalCount(String.valueOf(creditChannelCount));
			channelStatisticsData.setSuccess("0");
			channelStatisticsData.setFailure("0");
			channelStatisticsData.setPending(String.valueOf(creditChannelCount));
			channelStatisticsListData.add(channelStatisticsData);

			float monthlySpend = Math.round(totalDebit / totalDebitCount);
			float monthincome = Math.round(totalCredit / totalCreditCount);

			SuspectedInterface maxTxn = nccrpList.stream().max(Comparator.comparing(SuspectedInterface::getAmount))
					.orElseThrow(NoSuchElementException::new);
			System.out.println("------>" + maxTxn.getAmount());

			for (SuspectedInterface acc : nccrpList) {
				AccountListData acclists = new AccountListData();
				acclists.setAcctNo(acc.getAcctNo());
				acclists.setCurrency(acc.getCurrency());
				acclists.setCustomerNo(acc.getCustomerNo());
				acclists.setClick(true);
				acclists.setCurrentAmount(acc.getbalance());
				acclists.setShortName(acc.getShortName());

				acclists.setPan(acc.getPan());
				acclists.setAadhar(acc.getAadharNo());
				acclists.setMobileNo(acc.getMobileNo());

				acclists.setName(acc.getName());
				acclists.setAddress(acc.getAddress());
				acclists.setAmount(acc.getAmount());
				acclists.setEmailaddress(acc.getEmailAddress());
				acclists.setIncome(acc.getIncome());
				acclists.setBranchCode(acc.getBranchCode());
				acclists.setBalance(acc.getbalance());
				acclists.setOpenDate(acc.getOpenDate());
				if (acc.getStatus() != null) {
					if (acc.getStatus().equals("00") || acc.getStatus().equals("0")) {
						acclists.setStatus("Active");
					}

				}

				acclists.setTotalCredit(String.valueOf(totalCredit));
				acclists.setTotalDebit(String.valueOf(totalDebit));
				acclists.setAverageMonthlySpending(String.valueOf(monthlySpend));
				acclists.setAverageMontlyincome(String.valueOf(monthincome));
				acclists.setChannelCount(String.valueOf(totalChannelCount));
				acclists.setTxnCount(String.valueOf(nccrpList.size()));
				acclists.setAcctType(acc.getAcctType());
				if (maxTxn != null && maxTxn.getAmount() != null) {
					acclists.setMaximumTxnAmout(String.valueOf(maxTxn.getAmount()));
				}
				acclists.setChannelStatisticsListData(channelStatisticsListData);
				list.add(acclists);
			}
		}

		accounDetailstListReponseData.setAccountList(list);

		return accounDetailstListReponseData;
	}

	public SuspectedChainResponseData getCcssSuspectedChainDetails(
			SuspectedChainRequestData suspectedChainRequestData) {

		SuspectedChainResponseData suspectedChainResponseData = new SuspectedChainResponseData();
		List<SuspectedInterface> nccrpList = null;
		if (suspectedChainRequestData.getAcctNo() != null) {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainByAccountNo(suspectedChainRequestData.getAcctNo());

		} else {
			nccrpList = ccss_SuspectedChainRepo.getSuspectedChainBymobileNo(suspectedChainRequestData.getMobileNo());

		}

		suspectedChainResponseData.setSuspectedInterface(nccrpList);

		return suspectedChainResponseData;
	}

	public TransactionSearchResponseData getSuspectedChainDetailsByAccountorRRN(
			TransactionSearchRequestData transactionSearchRequestData) {

		int recordSize = 1;
		TransactionSearchResponseData response = new TransactionSearchResponseData();
		List<I4CCallBackRequest> i4CCallBackRequest = new ArrayList<I4CCallBackRequest>();
		List<CcssCBSTransactionFraudDetails_DAO> CcssCBSTransactionFraudDetails = fraudDetailsRepo
				.getFraudDetailByAccntAndRrnAndAckNumber(transactionSearchRequestData.getTransactionId(),
						transactionSearchRequestData.getAcctNo(), transactionSearchRequestData.getAcknowledgementNo());
		if (!CcssCBSTransactionFraudDetails.isEmpty()) {
			for (CcssCBSTransactionFraudDetails_DAO fraudDao : CcssCBSTransactionFraudDetails) {
				I4CCallBackRequest callbackRequest = new I4CCallBackRequest();
				callbackRequest.setsNo(recordSize);
				callbackRequest.setAcctNo(fraudDao.getAccountNo());
				callbackRequest.setAcknowledgementNo(fraudDao.getAcknowledgementNo());
				callbackRequest.setAmount(fraudDao.getAmount());
				callbackRequest.setAtmBranch(fraudDao.getAtmBranch());
				callbackRequest.setAtmId(fraudDao.getAtmId());
				callbackRequest.setAtmPlace(fraudDao.getAtmPlace());
				callbackRequest.setBeneName(fraudDao.getBeneName());
				callbackRequest.setBeneRemiAcctNum(fraudDao.getBeneRemiAcctNum());
				callbackRequest.setBeneRemiBank(fraudDao.getBeneRemiBank());
				callbackRequest.setBeneRemiIfsc(fraudDao.getBeneRemiIfsc());
				callbackRequest.setBeneBankCode(fraudDao.getBeneBankCode());
				callbackRequest.setChannel(fraudDao.getChannel());
				callbackRequest.setComplaintRrn(fraudDao.getComplaintRrn());
				callbackRequest.setDisputeBalance(fraudDao.getDisputeBalance());
				callbackRequest.setFraud_Fg(fraudDao.getFraud_Fg());
				callbackRequest.setFraudStatus(fraudDao.getFraudStatus());
				callbackRequest.setMerchantId(fraudDao.getMerchantId());
				callbackRequest.setRemarks(fraudDao.getRemarks());
				i4CCallBackRequest.add(callbackRequest);
				recordSize++;

			}
			response.setI4CCallBackRequest(i4CCallBackRequest);
		}
		return response;
	}

}
