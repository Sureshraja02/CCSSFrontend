/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_COMPLAINTS_STATUS")
@Entity
public class Ccss_Complaint_Status {

	@Id
	@Column(name = "COMPLAINT_ID")
	private String Id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;


	@Column(name = "STATUS")
	private String status;

	@Column(name = "AGING")
	private String freezedAccount;

	@Column(name = "DATE_TIME")
	private String dateTime;

	@Column(name = "REMARKS")
	private String remarks;

	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}

	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the freezedAccount
	 */
	public String getFreezedAccount() {
		return freezedAccount;
	}

	/**
	 * @param freezedAccount the freezedAccount to set
	 */
	public void setFreezedAccount(String freezedAccount) {
		this.freezedAccount = freezedAccount;
	}

	

	/**
	 * @return the dateTime
	 */
	public String getDateTime() {
		return dateTime;
	}

	/**
	 * @param dateTime the dateTime to set
	 */
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}
