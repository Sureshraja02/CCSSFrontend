/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_CFTD")
@Entity
public class Ccss_Cftd_Details {

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "IDSEQ", sequenceName = "IDSEQ", allocationSize = 1)
	private String Id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Column(name = "SUB_CATEGORY")
	private String subCategory;

	@Column(name = "MODE_OF_PAYMENT")
	private String modeOfPayment;

	@Column(name = "REQUESTOR")
	private String requestor;

	@Column(name = "TRANSACTION_ID")
	private String transactionId;

	@Column(name = "PAYER_BANK_CODE")
	private Integer payerBankCode;

	@Column(name = "CALL_BACK_STATUS")
	private String callBackStatus;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "TRANSACTION_DATE")
	private String transactionDate;

	@Column(name = "COMPLAINT_DATE")
	private String complaintDate;

	@Column(name = "AMOUNT")
	private String amount;

	@Column(name = "PAYER_BANK")
	private String payerBank;

	@Column(name = "STATE")
	private String state;

	@Column(name = "DISTRICT")
	private String district;

	@Column(name = "FIRST_6_DIGIT")
	private String first6Digit;

	@Column(name = "LAST_4_DIGIT")
	private String last4Digit;

	@Column(name = "CARD_LENGTH")
	private String cardLength;

	@Column(name = "RRN")
	private String rrn;

	@Column(name = "LAYER")
	private String layer;

	@Column(name = "WALLET")
	private String wallet;

	@Column(name = "DISPUTED_AMOUNT")
	private BigDecimal disputedAmount;

	@Column(name = "PAYER_MOBILE_NUMBER")
	private String payerMobileNumber;

	@Column(name = "PAYER_ACCOUNT_NUMBER")
	private String payerAccountNumber;

	@Column(name = "TRANSACTION_TIME")
	private String transactionTime;
	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ENTRY_DATE", columnDefinition = "TIMESTAMP")
	private Date entryDate;

	@Column(name = "ENTRY_BY")
	private String entryBy;

	@Column(name = "JOBID")
	private String jobId;

	@Column(name = "MID_API_CALL_STATUS")
	private String middlewareAPICallStatus;

	@Column(name = "MID_STATUS_CODE")
	private String middleStatusCode;

	@Column(name = "RECORD_TYPE")
	private String recordType;

	@Column(name = "HOLD_STATUS")
	private String holdStatus;

	@Column(name = "COMP_DT")
	private Date ComplaintDt;

	@Column(name = "CHANNEL")
	private String Channel;

	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}

	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	/**
	 * @return the subCategory
	 */
	public String getSubCategory() {
		return subCategory;
	}

	/**
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	/**
	 * @return the modeOfPayment
	 */
	public String getModeOfPayment() {
		return modeOfPayment;
	}

	/**
	 * @param modeOfPayment the modeOfPayment to set
	 */
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the callBackStatus
	 */
	public String getCallBackStatus() {
		return callBackStatus;
	}

	/**
	 * @param callBackStatus the callBackStatus to set
	 */
	public void setCallBackStatus(String callBackStatus) {
		this.callBackStatus = callBackStatus;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the payerMobileNumber
	 */
	public String getPayerMobileNumber() {
		return payerMobileNumber;
	}

	/**
	 * @param payerMobileNumber the payerMobileNumber to set
	 */
	public void setPayerMobileNumber(String payerMobileNumber) {
		this.payerMobileNumber = payerMobileNumber;
	}

	/**
	 * @return the payerAccountNumber
	 */
	public String getPayerAccountNumber() {
		return payerAccountNumber;
	}

	/**
	 * @param payerAccountNumber the payerAccountNumber to set
	 */
	public void setPayerAccountNumber(String payerAccountNumber) {
		this.payerAccountNumber = payerAccountNumber;
	}

	/**
	 * @return the transactionDate
	 */
	public String getTransactionDate() {
		return transactionDate;
	}

	/**
	 * @param transactionDate the transactionDate to set
	 */
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * @return the rrn
	 */
	public String getRrn() {
		return rrn;
	}

	/**
	 * @param rrn the rrn to set
	 */
	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	/**
	 * @return the payerBank
	 */
	public String getPayerBank() {
		return payerBank;
	}

	/**
	 * @param payerBank the payerBank to set
	 */
	public void setPayerBank(String payerBank) {
		this.payerBank = payerBank;
	}

	/**
	 * @return the requestor
	 */
	public String getRequestor() {
		return requestor;
	}

	/**
	 * @param requestor the requestor to set
	 */
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	/**
	 * @return the payerBankCode
	 */
	public Integer getPayerBankCode() {
		return payerBankCode;
	}

	/**
	 * @param payerBankCode the payerBankCode to set
	 */
	public void setPayerBankCode(Integer payerBankCode) {
		this.payerBankCode = payerBankCode;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the first6Digit
	 */
	public String getFirst6Digit() {
		return first6Digit;
	}

	/**
	 * @param first6Digit the first6Digit to set
	 */
	public void setFirst6Digit(String first6Digit) {
		this.first6Digit = first6Digit;
	}

	/**
	 * @return the last4Digit
	 */
	public String getLast4Digit() {
		return last4Digit;
	}

	/**
	 * @param last4Digit the last4Digit to set
	 */
	public void setLast4Digit(String last4Digit) {
		this.last4Digit = last4Digit;
	}

	/**
	 * @return the cardLength
	 */
	public String getCardLength() {
		return cardLength;
	}

	/**
	 * @param cardLength the cardLength to set
	 */
	public void setCardLength(String cardLength) {
		this.cardLength = cardLength;
	}

	/**
	 * @return the layer
	 */
	public String getLayer() {
		return layer;
	}

	/**
	 * @param layer the layer to set
	 */
	public void setLayer(String layer) {
		this.layer = layer;
	}

	/**
	 * @return the wallet
	 */
	public String getWallet() {
		return wallet;
	}

	/**
	 * @param wallet the wallet to set
	 */
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	/**
	 * @return the disputedAmount
	 */
	public BigDecimal getDisputedAmount() {
		return disputedAmount;
	}

	/**
	 * @param disputedAmount the disputedAmount to set
	 */
	public void setDisputedAmount(BigDecimal disputedAmount) {
		this.disputedAmount = disputedAmount;
	}

	/**
	 * @return the transactionTime
	 */
	public String getTransactionTime() {
		return transactionTime;
	}

	/**
	 * @param transactionTime the transactionTime to set
	 */
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the entryDate
	 */
	public Date getEntryDate() {
		return entryDate;
	}

	/**
	 * @param entryDate the entryDate to set
	 */
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	/**
	 * @return the entryBy
	 */
	public String getEntryBy() {
		return entryBy;
	}

	/**
	 * @param entryBy the entryBy to set
	 */
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}

	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}

	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the middlewareAPICallStatus
	 */
	public String getMiddlewareAPICallStatus() {
		return middlewareAPICallStatus;
	}

	/**
	 * @param middlewareAPICallStatus the middlewareAPICallStatus to set
	 */
	public void setMiddlewareAPICallStatus(String middlewareAPICallStatus) {
		this.middlewareAPICallStatus = middlewareAPICallStatus;
	}

	/**
	 * @return the middleStatusCode
	 */
	public String getMiddleStatusCode() {
		return middleStatusCode;
	}

	/**
	 * @param middleStatusCode the middleStatusCode to set
	 */
	public void setMiddleStatusCode(String middleStatusCode) {
		this.middleStatusCode = middleStatusCode;
	}

	/**
	 * @return the complaintDate
	 */
	public String getComplaintDate() {
		return complaintDate;
	}

	/**
	 * @param complaintDate the complaintDate to set
	 */
	public void setComplaintDate(String complaintDate) {
		this.complaintDate = complaintDate;
	}

	/**
	 * @return the recordType
	 */
	public String getRecordType() {
		return recordType;
	}

	/**
	 * @param recordType the recordType to set
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	/**
	 * @return the holdStatus
	 */
	public String getHoldStatus() {
		return holdStatus;
	}

	/**
	 * @param holdStatus the holdStatus to set
	 */
	public void setHoldStatus(String holdStatus) {
		this.holdStatus = holdStatus;
	}

	public Date getComplaintDt() {
		return ComplaintDt;
	}

	public void setComplaintDt(Date complaintDt) {
		ComplaintDt = complaintDt;
	}

	public String getChannel() {
		return Channel;
	}

	public void setChannel(String channel) {
		Channel = channel;
	}

}
