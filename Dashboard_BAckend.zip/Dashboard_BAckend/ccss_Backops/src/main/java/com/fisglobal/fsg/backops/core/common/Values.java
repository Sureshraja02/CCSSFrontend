
package com.fisglobal.fsg.backops.core.common;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Atm",
    "POS",
    "IB",
    "MB"
})
@Generated("jsonschema2pojo")
public class Values {

    @JsonProperty("Atm")
    private String atm;
    @JsonProperty("POS")
    private String pos;
    @JsonProperty("IB")
    private String ib;
    @JsonProperty("MB")
    private String mb;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("Atm")
    public String getAtm() {
        return atm;
    }

    @JsonProperty("Atm")
    public void setAtm(String atm) {
        this.atm = atm;
    }

    @JsonProperty("POS")
    public String getPos() {
        return pos;
    }

    @JsonProperty("POS")
    public void setPos(String pos) {
        this.pos = pos;
    }

    @JsonProperty("IB")
    public String getIb() {
        return ib;
    }

    @JsonProperty("IB")
    public void setIb(String ib) {
        this.ib = ib;
    }

    @JsonProperty("MB")
    public String getMb() {
        return mb;
    }

    @JsonProperty("MB")
    public void setMb(String mb) {
        this.mb = mb;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
