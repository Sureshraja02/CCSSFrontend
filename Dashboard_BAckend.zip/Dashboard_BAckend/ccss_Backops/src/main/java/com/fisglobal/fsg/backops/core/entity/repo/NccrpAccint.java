package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.NccrpAcc;
import com.fisglobal.fsg.backops.core.entity.Nccrptxn;

public interface NccrpAccint extends JpaRepository<NccrpAcc, String> {

	@Query(value = "select * from NCCRPACC where ACCOUNTSTATUS='Freeze'", nativeQuery = true)	
	List<Nccrptxn> freezeAcc();

}
