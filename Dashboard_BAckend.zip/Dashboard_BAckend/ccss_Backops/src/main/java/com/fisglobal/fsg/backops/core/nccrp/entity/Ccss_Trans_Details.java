/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_TRANS_DETAILS")
@Entity
public class Ccss_Trans_Details {



	@Id
	@Column(name = "ID")
	private String Id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgementNo;

	@Column(name = "RRN")
	private String rrn;

	@Column(name = "PAYEE_ACCOUNT_NUMBER")
	private String payeeAccountNumber;

	@Column(name = "ROOT_ACCOUNT_NUMBER")
	private String rootAccountNumber;

	@Column(name = "REMARKS")
	private String remarks;
	
	@Column(name = "DISPUTED_AMOUNT")
	private String disputedAmount;
	
	@Column(name = "TRANSACTION_ID")
	private String transactionId;
	
	@Column(name = "MERCHANT_NAME")
	private String merchantName;
	
		
	@Column(name = "PAYEE_BANK")
	private String payeeBank;
	
	@Column(name = "PAYEE_VPA")
	private String payeeVpa;
	
	@Column(name = "IFSC_CODE")
	private String ifscCode;
	
	@Column(name = "AMOUNT")
	private String amount;
	
	@Column(name = "TXN_TYPE")
	private String txnType;
	
	@Column(name = "TRANSACTION_DATETIME")
	private String transactionDateTime;

	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}

	/**
	 * @return the acknowledgementNo
	 */
	public String getAcknowledgementNo() {
		return acknowledgementNo;
	}

	/**
	 * @param acknowledgementNo the acknowledgementNo to set
	 */
	public void setAcknowledgementNo(String acknowledgementNo) {
		this.acknowledgementNo = acknowledgementNo;
	}

	/**
	 * @return the rrn
	 */
	public String getRrn() {
		return rrn;
	}

	/**
	 * @param rrn the rrn to set
	 */
	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	/**
	 * @return the payeeAccountNumber
	 */
	public String getPayeeAccountNumber() {
		return payeeAccountNumber;
	}

	/**
	 * @param payeeAccountNumber the payeeAccountNumber to set
	 */
	public void setPayeeAccountNumber(String payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}

	/**
	 * @return the rootAccountNumber
	 */
	public String getRootAccountNumber() {
		return rootAccountNumber;
	}

	/**
	 * @param rootAccountNumber the rootAccountNumber to set
	 */
	public void setRootAccountNumber(String rootAccountNumber) {
		this.rootAccountNumber = rootAccountNumber;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the disputedAmount
	 */
	public String getDisputedAmount() {
		return disputedAmount;
	}

	/**
	 * @param disputedAmount the disputedAmount to set
	 */
	public void setDisputedAmount(String disputedAmount) {
		this.disputedAmount = disputedAmount;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the merchantName
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * @param merchantName the merchantName to set
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	

	/**
	 * @return the payeeBank
	 */
	public String getPayeeBank() {
		return payeeBank;
	}

	/**
	 * @param payeeBank the payeeBank to set
	 */
	public void setPayeeBank(String payeeBank) {
		this.payeeBank = payeeBank;
	}

	/**
	 * @return the payeeVpa
	 */
	public String getPayeeVpa() {
		return payeeVpa;
	}

	/**
	 * @param payeeVpa the payeeVpa to set
	 */
	public void setPayeeVpa(String payeeVpa) {
		this.payeeVpa = payeeVpa;
	}

	/**
	 * @return the ifscCode
	 */
	public String getIfscCode() {
		return ifscCode;
	}

	/**
	 * @param ifscCode the ifscCode to set
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the txnType
	 */
	public String getTxnType() {
		return txnType;
	}

	/**
	 * @param txnType the txnType to set
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return the transactionDateTime
	 */
	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	/**
	 * @param transactionDateTime the transactionDateTime to set
	 */
	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	
	
	
}

