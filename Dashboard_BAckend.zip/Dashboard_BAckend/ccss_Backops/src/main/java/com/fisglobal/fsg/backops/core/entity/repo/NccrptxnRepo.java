package com.fisglobal.fsg.backops.core.entity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.entity.Nccrptxn;

public interface NccrptxnRepo extends JpaRepository<Nccrptxn, String>  {
	
	@Query(value = "select distinct payeraddr,payeeaddr from NCCRPTXN where MOBILENUMBER=?1", nativeQuery = true)	
	List<Nccrptxn> suspectedChain(String mobileNumber);

}
