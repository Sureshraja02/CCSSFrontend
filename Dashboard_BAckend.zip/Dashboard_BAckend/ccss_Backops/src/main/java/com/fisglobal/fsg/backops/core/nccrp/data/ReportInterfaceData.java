package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.Date;

public interface ReportInterfaceData {

	String getAcknowledgementNo();
	
	String getPayerAccountNumber();
	
	String getTransTIme();
	
	String getAmount();
	
	Date getEntryDate();
	
	String getRrn();
	
	String getPatialSuccess();
	
	String getTransDate();
	
	String getDisputedAmount();
	
	 String getStatus();
	 
	 String getStatusReason();
	 
	 String getComplaintDate();
	 
	 Date getEntryDates();
}
