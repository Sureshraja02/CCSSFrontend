package com.fisglobal.fsg.backops.core.nccrp.entity.repo;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fisglobal.fsg.backops.core.nccrp.data.ReportInterfaceData;
import com.fisglobal.fsg.backops.core.nccrp.entity.CCSS_REQ_Audit_DAO;

public interface CCSSReqAuditRepo extends JpaRepository<CCSS_REQ_Audit_DAO, String> {

	@Query(value = "SELECT sum(count(1)) from CCSS_REQ_AUDIT where status IS NOT NULL and FULLY_SUCCESS=1 and status ='00' and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by ACKNOWLEDGEMENT_NO,RRN, PAYER_ACCOUNT_NUMBER,AMOUNT, DISPUTED_AMOUNT", nativeQuery = true)
	Long readFullySuccessCount(Date startDate, Date endDate);

	@Query(value = "SELECT sum(count(1)) from CCSS_REQ_AUDIT where FULLY_FAILED=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by ACKNOWLEDGEMENT_NO,RRN, PAYER_ACCOUNT_NUMBER,AMOUNT, DISPUTED_AMOUNT", nativeQuery = true)
	Long readFullyFailedCount(Date startDate, Date endDate);

	@Query(value = "SELECT sum(count(1)) from CCSS_REQ_AUDIT where PARTIAL_SUCCESS=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2  group by ACKNOWLEDGEMENT_NO,RRN, PAYER_ACCOUNT_NUMBER,AMOUNT, DISPUTED_AMOUNT", nativeQuery = true)
	Long readPartialSuccessCount(Date startDate, Date endDate);

	@Query(value = "SELECT sum(count(1)) from CCSS_REQ_AUDIT where  status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by ACKNOWLEDGEMENT_NO,RRN, PAYER_ACCOUNT_NUMBER,AMOUNT, DISPUTED_AMOUNT", nativeQuery = true)
	Long readTotalAckReceived(Date startDate, Date endDate);

	@Query(value = "SELECT sum(count(1)) from CCSS_REQ_AUDIT where status IS NOT NULL and status !='15' and  ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by ACKNOWLEDGEMENT_NO,RRN, PAYER_ACCOUNT_NUMBER,AMOUNT, DISPUTED_AMOUNT", nativeQuery = true)
	Long readTotalAckProcessed(Date startDate, Date endDate);

	@Query(countQuery = "select count(1) as success from (SELECT count(1) from CCSS_REQ_AUDIT where FULLY_SUCCESS=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE,ACKNOWLEDGEMENT_NO, PAYER_ACCOUNT_NUMBER,RRN,  AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT where \r\n"
			+ "(FULLY_SUCCESS=1 and status ='00' and status !='15')  and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	Page<HashMap<String, Object>> readFullySuccessCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);
	
	@Query(countQuery = "select count(1) from CCSS_CIF_DIGITAL_CHNL_BLOCK where ENTRYDATE  >?1 and  ENTRYDATE <= ?2 and RESP_CODE='200' and RESP_MSG='ERR 4945 00 CUSTOMER ALREADY BLOCKED'", 
			value = "select  ACCOUNT_NO as dummy, ACCOUNT_NO,MOBILE_NUMBER,ACKNOWLEDGEMENT_NO,COMPLAINT_RRN  from CCSS_CIF_DIGITAL_CHNL_BLOCK where ENTRYDATE  >?1 and  ENTRYDATE <= ?2 and RESP_CODE='200' and RESP_MSG='ERR 4945 00 CUSTOMER ALREADY BLOCKED'", nativeQuery = true)
	Page<HashMap<String, Object>> readDigitalBlockCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);

	@Query(countQuery = "select count(1) as fullyFailed from (SELECT count(1) from CCSS_REQ_AUDIT where FULLY_FAILED=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE, ACKNOWLEDGEMENT_NO, PAYER_ACCOUNT_NUMBER,RRN,  AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	Page<HashMap<String, Object>> readFullyFailedCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);
	
	@Query(countQuery = "select count(1) as fullyFailed from (SELECT count(1) from CCSS_REQ_AUDIT where FULLY_FAILED=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE, ACKNOWLEDGEMENT_NO, PAYER_ACCOUNT_NUMBER,RRN,  AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and STATUS in('60001','60002','60003') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	Page<HashMap<String, Object>> readFullyFailedTechnicalCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);
	
	@Query(countQuery = "select count(1) as fullyFailed from (SELECT count(1) from CCSS_REQ_AUDIT where FULLY_FAILED=1 and status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE, ACKNOWLEDGEMENT_NO, PAYER_ACCOUNT_NUMBER,RRN,  AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and STATUS in('40001','50003','50006','70008','70009','2') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	Page<HashMap<String, Object>> readFullyFailedBusinessCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);

	@Query(countQuery = "select count(1) as partialSuccess from (SELECT count(1) from CCSS_REQ_AUDIT where status !='00' and status !='15' and PARTIAL_SUCCESS=1 and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2  group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE,ACKNOWLEDGEMENT_NO,PAYER_ACCOUNT_NUMBER, RRN, AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	Page<HashMap<String, Object>> readPartialSuccessCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);

	
	@Query(countQuery = "select count(1) as partialSuccess from (SELECT count(1) from CCSS_REQ_AUDIT where status !='00' and status !='15' and PARTIAL_SUCCESS=1 and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2  group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE,ACKNOWLEDGEMENT_NO,PAYER_ACCOUNT_NUMBER, RRN, AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('60001','60002','60003') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	Page<HashMap<String, Object>> readPartialSuccessTechnicalCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);
	
	@Query(countQuery = "select count(1) as partialSuccess from (SELECT count(1) from CCSS_REQ_AUDIT where status !='00' and status !='15' and PARTIAL_SUCCESS=1 and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2  group by jobid)", value = "SELECT ENTRY_DATE as dummy,ENTRY_DATE,ACKNOWLEDGEMENT_NO,PAYER_ACCOUNT_NUMBER, RRN, AMOUNT, DISPUTED_AMOUNT, TRANSACTION_DATE, \r\n"
			+ "TRANSACTION_TIME,status,STATUS_REASON as status_reason from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('40001','50003','50006','70008','70009','2') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	Page<HashMap<String, Object>> readPartialSuccessBusinessCountDetails(Date startDate, Date endDate,
			org.springframework.data.domain.Pageable paging);
	
	@Query(value = "select count(1) from (SELECT count(1) from CCSS_REQ_AUDIT where  status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by rrn)", nativeQuery = true)
	Long readTotalRRNCount(Date startDate, Date endDate);

	@Query(value = "select count(1) from (SELECT count(1) from CCSS_REQ_AUDIT where status IS NOT NULL and  status !='15' and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 group by rrn)", nativeQuery = true)
	Long readTotalRRNProceedCount(Date startDate, Date endDate);

	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	List<ReportInterfaceData> downloadPartialSuccessCountDetails(Date startDate, Date endDate);

	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	List<ReportInterfaceData> downloadFullyFailedCountDetails(Date startDate, Date endDate);

	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_SUCCESS=1 and   status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	List<ReportInterfaceData> downloadFullySuccessCountDetails(Date startDate, Date endDate);

	
	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('60001','60002','60003') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	List<ReportInterfaceData> downloadPartialSuccessTechnicalCountDetails(Date startDate, Date endDate);

	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and  STATUS in('60001','60002','60003') order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	List<ReportInterfaceData> downloadFullyFailedTechnicalCountDetails(Date startDate, Date endDate);


	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (status !='00' and PARTIAL_SUCCESS=1 and status !='15')\r\n"
			+ "and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('40001','50003','50006','70008','70009','2') order by ACKNOWLEDGEMENT_NO", nativeQuery = true)
	List<ReportInterfaceData> downloadPartialSuccessBusinessCountDetails(Date startDate, Date endDate);

	@Query(value = "SELECT ENTRY_DATE as entryDate, ACKNOWLEDGEMENT_NO as acknowledgementNo, PAYER_ACCOUNT_NUMBER as payerAccountNumber,RRN as rrn,  AMOUNT as amount, DISPUTED_AMOUNT as disputedAmount, TRANSACTION_DATE as transDate,TRANSACTION_TIME as transTIme,status as status,STATUS_REASON AS statusReason,PARTIAL_SUCCESS as patialSuccess from CCSS_REQ_AUDIT \r\n"
			+ "where (FULLY_FAILED=1 and status !='00' and status !='15') and ENTRY_DATE > ?1  AND ENTRY_DATE <= ?2 and STATUS in('40001','50003','50006','70008','70009','2') order by ACKNOWLEDGEMENT_NO ", nativeQuery = true)
	List<ReportInterfaceData> downloadFullyFailedBusinessCountDetails(Date startDate, Date endDate);

}
