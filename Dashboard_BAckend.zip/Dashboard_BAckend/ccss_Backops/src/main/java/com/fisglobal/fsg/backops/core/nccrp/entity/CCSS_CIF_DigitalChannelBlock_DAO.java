package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "CCSS_CIF_DIGITAL_CHNL_BLOCK")
@Entity
public class CCSS_CIF_DigitalChannelBlock_DAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ID", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "IDCIFSEQ", sequenceName = "IDCIFSEQ", allocationSize = 1)
	private String id;

	@Column(name = "ACKNOWLEDGEMENT_NO")
	private String acknowledgement_no;

	@Column(name = "MOBILE_NUMBER")
	private String mobileNumber;

	@Column(name = "ACCOUNT_NO")
	private String accountNo;

	@Column(name = "COMPLAINT_RRN")
	private String complaintRRN;

	@Column(name = "API_STATUS")
	private String apiStatus;

	@Column(name = "RESP_CODE")
	private String respCode;

	@Column(name = "RESP_MSG")
	private String respMsg;

	@Column(name = "ENTRYDATE")
	private Timestamp entryDate;

	@Column(name = "UPDATEDDATE")
	private Timestamp updateDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAcknowledgement_no() {
		return acknowledgement_no;
	}

	public void setAcknowledgement_no(String acknowledgement_no) {
		this.acknowledgement_no = acknowledgement_no;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getComplaintRRN() {
		return complaintRRN;
	}

	public void setComplaintRRN(String complaintRRN) {
		this.complaintRRN = complaintRRN;
	}

	public String getApiStatus() {
		return apiStatus;
	}

	public void setApiStatus(String apiStatus) {
		this.apiStatus = apiStatus;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	public Timestamp getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Timestamp entryDate) {
		this.entryDate = entryDate;
	}

	public Timestamp getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

}
