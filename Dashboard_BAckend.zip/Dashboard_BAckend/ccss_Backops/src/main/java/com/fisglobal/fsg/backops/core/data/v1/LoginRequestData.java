package com.fisglobal.fsg.backops.core.data.v1;

public class LoginRequestData {

}
