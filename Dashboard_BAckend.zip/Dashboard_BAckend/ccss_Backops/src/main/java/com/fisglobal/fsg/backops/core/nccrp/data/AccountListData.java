package com.fisglobal.fsg.backops.core.nccrp.data;

import java.util.List;

public class AccountListData {

	private String acctNo;
	private String customerNo;
	private String shortName;
	private String currentAmount;
	private String currency;
	
	private String acctType;
	private String status;
	private String pan;
	private String mobileNo;
	private String address;
	
	private String openDate;
	private String income;
	private String emailaddress;
	private String name;
	private String amount;
	private String balance;
	private String branchCode;
	private String totalDebit;
	private String totalCredit;
	private String averageMonthlySpending;
	private String averageMontlyincome;
	private String txnCount;
	private String channelCount;
	private String maximumTxnAmout;
	private String aadhar;
	
	private List<ChannelStatisticsData> channelStatisticsListData;
	
	
	private boolean click;
	/**
	 * @return the acctNo
	 */
	public String getAcctNo() {
		return acctNo;
	}
	/**
	 * @param acctNo the acctNo to set
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	/**
	 * @return the customerNo
	 */
	public String getCustomerNo() {
		return customerNo;
	}
	/**
	 * @param customerNo the customerNo to set
	 */
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	/**
	 * @return the shortName
	 */
	public String getShortName() {
		return shortName;
	}
	/**
	 * @param shortName the shortName to set
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	/**
	 * @return the currentAmount
	 */
	public String getCurrentAmount() {
		return currentAmount;
	}
	/**
	 * @param currentAmount the currentAmount to set
	 */
	public void setCurrentAmount(String currentAmount) {
		this.currentAmount = currentAmount;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the click
	 */
	public boolean isClick() {
		return click;
	}
	/**
	 * @param click the click to set
	 */
	public void setClick(boolean click) {
		this.click = click;
	}
	/**
	 * @return the acctType
	 */
	public String getAcctType() {
		return acctType;
	}
	/**
	 * @param acctType the acctType to set
	 */
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}
	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the openDate
	 */
	public String getOpenDate() {
		return openDate;
	}
	/**
	 * @param openDate the openDate to set
	 */
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	/**
	 * @return the income
	 */
	public String getIncome() {
		return income;
	}
	/**
	 * @param income the income to set
	 */
	public void setIncome(String income) {
		this.income = income;
	}
	/**
	 * @return the emailaddress
	 */
	public String getEmailaddress() {
		return emailaddress;
	}
	/**
	 * @param emailaddress the emailaddress to set
	 */
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}
	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}
	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}
	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	/**
	 * @return the totalDebit
	 */
	public String getTotalDebit() {
		return totalDebit;
	}
	/**
	 * @param totalDebit the totalDebit to set
	 */
	public void setTotalDebit(String totalDebit) {
		this.totalDebit = totalDebit;
	}
	/**
	 * @return the totalCredit
	 */
	public String getTotalCredit() {
		return totalCredit;
	}
	/**
	 * @param totalCredit the totalCredit to set
	 */
	public void setTotalCredit(String totalCredit) {
		this.totalCredit = totalCredit;
	}
	/**
	 * @return the averageMonthlySpending
	 */
	public String getAverageMonthlySpending() {
		return averageMonthlySpending;
	}
	/**
	 * @param averageMonthlySpending the averageMonthlySpending to set
	 */
	public void setAverageMonthlySpending(String averageMonthlySpending) {
		this.averageMonthlySpending = averageMonthlySpending;
	}
	/**
	 * @return the averageMontlyincome
	 */
	public String getAverageMontlyincome() {
		return averageMontlyincome;
	}
	/**
	 * @param averageMontlyincome the averageMontlyincome to set
	 */
	public void setAverageMontlyincome(String averageMontlyincome) {
		this.averageMontlyincome = averageMontlyincome;
	}
	/**
	 * @return the txnCount
	 */
	public String getTxnCount() {
		return txnCount;
	}
	/**
	 * @param txnCount the txnCount to set
	 */
	public void setTxnCount(String txnCount) {
		this.txnCount = txnCount;
	}
	/**
	 * @return the channelCount
	 */
	public String getChannelCount() {
		return channelCount;
	}
	/**
	 * @param channelCount the channelCount to set
	 */
	public void setChannelCount(String channelCount) {
		this.channelCount = channelCount;
	}
	/**
	 * @return the maximumTxnAmout
	 */
	public String getMaximumTxnAmout() {
		return maximumTxnAmout;
	}
	/**
	 * @param maximumTxnAmout the maximumTxnAmout to set
	 */
	public void setMaximumTxnAmout(String maximumTxnAmout) {
		this.maximumTxnAmout = maximumTxnAmout;
	}
	/**
	 * @return the channelStatisticsListData
	 */
	public List<ChannelStatisticsData> getChannelStatisticsListData() {
		return channelStatisticsListData;
	}
	/**
	 * @param channelStatisticsListData the channelStatisticsListData to set
	 */
	public void setChannelStatisticsListData(List<ChannelStatisticsData> channelStatisticsListData) {
		this.channelStatisticsListData = channelStatisticsListData;
	}
	/**
	 * @return the aadhar
	 */
	public String getAadhar() {
		return aadhar;
	}
	/**
	 * @param aadhar the aadhar to set
	 */
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	
	

}
