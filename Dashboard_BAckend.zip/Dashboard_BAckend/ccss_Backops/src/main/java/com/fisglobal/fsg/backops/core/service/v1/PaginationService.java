package com.fisglobal.fsg.backops.core.service.v1;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.entity.Group_Master;
import com.fisglobal.fsg.backops.core.entity.Instid_Master;
import com.fisglobal.fsg.backops.core.entity.Menu_Master;
import com.fisglobal.fsg.backops.core.entity.RMS_Config;
import com.fisglobal.fsg.backops.core.entity.RMS_Rule;
import com.fisglobal.fsg.backops.core.entity.User_Master;
import com.fisglobal.fsg.backops.core.entity.repo.GroupRepo;
import com.fisglobal.fsg.backops.core.entity.repo.InstitutionRepo;
import com.fisglobal.fsg.backops.core.entity.repo.MenuRepo;
import com.fisglobal.fsg.backops.core.entity.repo.RMSConfigRepo;
import com.fisglobal.fsg.backops.core.entity.repo.RMS_Rule_Repo;
import com.fisglobal.fsg.backops.core.entity.repo.UserRepo;

@Service
public class PaginationService {

	@Inject
	private RMSConfigRepo configRepo;
	
	@Inject
	private UserRepo userRepo;
	
	@Inject
	private RMS_Rule_Repo ruleRepo;
	
	@Inject
	private MenuRepo menuRepo;
	
	@Inject
	private InstitutionRepo instRepo;
	
	@Inject
	private GroupRepo groupRepo;


	public Page<RMS_Config> getConfigList(String property_name,int pageSize,int pageNo) throws Exception {		
		Pageable paging = PageRequest.of(pageNo, pageSize,Sort.by("rmsid"));	
		Page<RMS_Config> pagedResult = configRepo.getProperty(property_name,paging);		
		return pagedResult;
	}
	
	public Page<User_Master> getUserList(int pageSize,int pageNo){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<User_Master> pagedResult = userRepo.findAll(paging);
		return pagedResult;
	}
	
	public Page<RMS_Rule> getRuleList(int pageSize,int pageNo){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<RMS_Rule> pagedResult = ruleRepo.findAll(paging);
		return pagedResult;
	}
	
	public Page<Menu_Master> getMenuList(int pageSize,int pageNo){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Menu_Master> pagedResult = menuRepo.findAll(paging);
		return pagedResult;
	}
	
	public Page<Instid_Master> getInstitutionList(int pageSize,int pageNo){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Instid_Master> pagedResult = instRepo.findAll(paging);
		return pagedResult;
	}
	
	public Page<Group_Master> getGrpList(int pageSize,int pageNo){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Group_Master> pagedResult = groupRepo.findAll(paging);
		return pagedResult;
	}
	public Page<User_Master> getUserListDashboard(int pageSize,int pageNo,String loginType){
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<User_Master> pagedResult = userRepo.findByLoginTypeContaining(loginType,paging);
		return pagedResult;
	}
}
