package com.fisglobal.fsg.backops.core.controller.v1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fisglobal.fsg.backops.core.data.v1.EventDataTypeDetails;
import com.fisglobal.fsg.backops.core.data.v1.EventRequestResponse;
import com.fisglobal.fsg.backops.core.data.v1.EventTagDetails;
import com.fisglobal.fsg.backops.core.entity.DataTypeMaster;
import com.fisglobal.fsg.backops.core.entity.Event_Request;
import com.fisglobal.fsg.backops.core.entity.repo.DataTypeRepo;
import com.fisglobal.fsg.backops.core.entity.repo.EventRequestRepo;

@RestController
@RequestMapping(value = "/app/rest/v1.0/service/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class EventRequestController {

	@Inject
	private EventRequestRepo eventRequestRepo;
	
	@Inject
	private DataTypeRepo dataTypeRepo;

	@RequestMapping(value = "event/{eventtype}", method = RequestMethod.GET)
	public ResponseEntity<EventRequestResponse> changePassword(
			@RequestHeader(value = "requestid") String reqId,
			@PathVariable String eventtype) {

		EventRequestResponse response = new EventRequestResponse();
		
		List<Event_Request> taglist =  eventRequestRepo.getTagDetails(eventtype);
		
		List<EventTagDetails> eventTagDetails = new ArrayList<EventTagDetails>();
		
		
		

		for(Event_Request eventRequest:taglist) {
			response.setEVENT_NAME(eventRequest.getEventName());
			response.setEVENT_TYPE(eventRequest.getEventType());
			
			EventTagDetails eventTagdts = new EventTagDetails();
			
			eventTagdts.setDataType(eventRequest.getDataType());
			eventTagdts.setIsActive(eventRequest.getIsActive());
			eventTagdts.setIsMandate(eventRequest.getIsMandate());
			eventTagdts.setParentTagName(eventRequest.getParentTagName());
			eventTagdts.setTagName(eventRequest.getPropertyValue());
			
			List<EventDataTypeDetails> dataTypeDetails = new ArrayList<EventDataTypeDetails>();	
			ArrayList<DataTypeMaster> dataTypeList = dataTypeRepo.getDataTypeDetails(eventRequest.getDataType());
			
			
			for(DataTypeMaster dataTypeMaster:dataTypeList) {
				EventDataTypeDetails dataTypeDts = new EventDataTypeDetails();
				dataTypeDts.setAllowedCondition(dataTypeMaster.getAllowedCondition());
				dataTypeDts.setDataTypeCode(dataTypeMaster.getDataTypeCode());
				dataTypeDts.setDataTypeDesc(dataTypeMaster.getDataTypeDesc());
				
				dataTypeDetails.add(dataTypeDts);
			}
			
			eventTagdts.setDataTypeDetails(dataTypeDetails);
			eventTagDetails.add(eventTagdts);
		}
		
		response.setEventTagDetails(eventTagDetails);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
