package com.fisglobal.fsg.backops.core.common;

import java.util.List;

public class ErrorDetails {

	private List<Error> errorList;

	public List<Error> getErrorList() {
		return errorList;
	}

	public void setErrorList(List<Error> errorList) {
		this.errorList = errorList;
	}

}
