/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e5745290
 *
 */
@Table(name = "CCSS_CBS_LOAN_DETAILS")
@Entity
public class Ccss_CBS_Loan_Details {
	
	
		@Id
		@Column(name = "ID")
		private String Id;
		

		@Column(name = "ACCT_NO")
		private String acct_No;
		
		@Column(name = "ACT_TYPE")
	    private String act_Type;
	    
		@Column(name = "STAT")
		private String stat;
		
		@Column(name = "LST_FIN_DATE")
		private String lst_Fin_Date;
	    
		@Column(name = "CAT")
		private String cat;
		
		@Column(name = "CUSTOMER_NO")
	    private String customer_No;
		
		@Column(name = "APPRV_DATE")
		private String apprv_Date;

		@Column(name = "EXTN_COUNTER")
		private String extn_Counter;
		
		@Column(name = "BR_NO")
	    private String br_No;
		
		@Column(name = "CAT_TYPE_NAME")
		private String cat_Type_Name;
	
		@Column(name = "LOAN_TRM")
	    private String loan_Trm;
		
		@Column(name = "GL_CLASS_CODE")
	    private String gl_Class_Code;
		
		@Column(name = "TRF_ACCT_NO")
	    private String trf_Acct_No;
		
		@Column(name = "INT_RT")
	    private String int_Rt;
	    
		@Column(name = "SEC_ACCESS_IND")
	    private String sec_Access_Ind;
		
		@Column(name = "LOAN_BAL")
		private String loan_Bal;
		
		@Column(name = "APP_AMT")
	    private String app_Amt;
		
		@Column(name = "ADV_VAL")
	    private String adv_val;
		
		@Column(name = "BAD_DEBT_IND")
		private String bad_Debt_Ind;
		
		@Column(name = "OLD_BAD_DEBT_IND")
	    private String old_Bad_Debt_Ind;
		
		@Column(name = "INT_INCR")
	    private String int_Incr;
		
		@Column(name = "ARR_INT_INCR")
		private String arr_Int_Incr;
		
		@Column(name = "SHORT_NAME")
	    private String short_Name;
		
		@Column(name = "LINKED_ACCOUNT_NO")
	    private String linked_Account_No; 
		
		@Column(name = "CHEQUE_BOOK_CNT")
	    private String cheque_Book_Cnt;
		
		@Column(name = "DUMMYROW")
	    private String dummyrow;

		/**
		 * @return the id
		 */
		public String getId() {
			return Id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(String id) {
			Id = id;
		}

		/**
		 * @return the acct_No
		 */
		public String getAcct_No() {
			return acct_No;
		}

		/**
		 * @param acct_No the acct_No to set
		 */
		public void setAcct_No(String acct_No) {
			this.acct_No = acct_No;
		}

		/**
		 * @return the act_Type
		 */
		public String getAct_Type() {
			return act_Type;
		}

		/**
		 * @param act_Type the act_Type to set
		 */
		public void setAct_Type(String act_Type) {
			this.act_Type = act_Type;
		}

		/**
		 * @return the stat
		 */
		public String getStat() {
			return stat;
		}

		/**
		 * @param stat the stat to set
		 */
		public void setStat(String stat) {
			this.stat = stat;
		}

		/**
		 * @return the lst_Fin_Date
		 */
		public String getLst_Fin_Date() {
			return lst_Fin_Date;
		}

		/**
		 * @param lst_Fin_Date the lst_Fin_Date to set
		 */
		public void setLst_Fin_Date(String lst_Fin_Date) {
			this.lst_Fin_Date = lst_Fin_Date;
		}

		/**
		 * @return the cat
		 */
		public String getCat() {
			return cat;
		}

		/**
		 * @param cat the cat to set
		 */
		public void setCat(String cat) {
			this.cat = cat;
		}

		/**
		 * @return the customer_No
		 */
		public String getCustomer_No() {
			return customer_No;
		}

		/**
		 * @param customer_No the customer_No to set
		 */
		public void setCustomer_No(String customer_No) {
			this.customer_No = customer_No;
		}

		/**
		 * @return the apprv_Date
		 */
		public String getApprv_Date() {
			return apprv_Date;
		}

		/**
		 * @param apprv_Date the apprv_Date to set
		 */
		public void setApprv_Date(String apprv_Date) {
			this.apprv_Date = apprv_Date;
		}

		/**
		 * @return the extn_Counter
		 */
		public String getExtn_Counter() {
			return extn_Counter;
		}

		/**
		 * @param extn_Counter the extn_Counter to set
		 */
		public void setExtn_Counter(String extn_Counter) {
			this.extn_Counter = extn_Counter;
		}

		/**
		 * @return the br_No
		 */
		public String getBr_No() {
			return br_No;
		}

		/**
		 * @param br_No the br_No to set
		 */
		public void setBr_No(String br_No) {
			this.br_No = br_No;
		}

		/**
		 * @return the cat_Type_Name
		 */
		public String getCat_Type_Name() {
			return cat_Type_Name;
		}

		/**
		 * @param cat_Type_Name the cat_Type_Name to set
		 */
		public void setCat_Type_Name(String cat_Type_Name) {
			this.cat_Type_Name = cat_Type_Name;
		}

		/**
		 * @return the loan_Trm
		 */
		public String getLoan_Trm() {
			return loan_Trm;
		}

		/**
		 * @param loan_Trm the loan_Trm to set
		 */
		public void setLoan_Trm(String loan_Trm) {
			this.loan_Trm = loan_Trm;
		}

		/**
		 * @return the gl_Class_Code
		 */
		public String getGl_Class_Code() {
			return gl_Class_Code;
		}

		/**
		 * @param gl_Class_Code the gl_Class_Code to set
		 */
		public void setGl_Class_Code(String gl_Class_Code) {
			this.gl_Class_Code = gl_Class_Code;
		}

		/**
		 * @return the trf_Acct_No
		 */
		public String getTrf_Acct_No() {
			return trf_Acct_No;
		}

		/**
		 * @param trf_Acct_No the trf_Acct_No to set
		 */
		public void setTrf_Acct_No(String trf_Acct_No) {
			this.trf_Acct_No = trf_Acct_No;
		}

		/**
		 * @return the int_Rt
		 */
		public String getInt_Rt() {
			return int_Rt;
		}

		/**
		 * @param int_Rt the int_Rt to set
		 */
		public void setInt_Rt(String int_Rt) {
			this.int_Rt = int_Rt;
		}

		/**
		 * @return the sec_Access_Ind
		 */
		public String getSec_Access_Ind() {
			return sec_Access_Ind;
		}

		/**
		 * @param sec_Access_Ind the sec_Access_Ind to set
		 */
		public void setSec_Access_Ind(String sec_Access_Ind) {
			this.sec_Access_Ind = sec_Access_Ind;
		}

		/**
		 * @return the loan_Bal
		 */
		public String getLoan_Bal() {
			return loan_Bal;
		}

		/**
		 * @param loan_Bal the loan_Bal to set
		 */
		public void setLoan_Bal(String loan_Bal) {
			this.loan_Bal = loan_Bal;
		}

		/**
		 * @return the app_Amt
		 */
		public String getApp_Amt() {
			return app_Amt;
		}

		/**
		 * @param app_Amt the app_Amt to set
		 */
		public void setApp_Amt(String app_Amt) {
			this.app_Amt = app_Amt;
		}

		/**
		 * @return the adv_val
		 */
		public String getAdv_val() {
			return adv_val;
		}

		/**
		 * @param adv_val the adv_val to set
		 */
		public void setAdv_val(String adv_val) {
			this.adv_val = adv_val;
		}

		/**
		 * @return the bad_Debt_Ind
		 */
		public String getBad_Debt_Ind() {
			return bad_Debt_Ind;
		}

		/**
		 * @param bad_Debt_Ind the bad_Debt_Ind to set
		 */
		public void setBad_Debt_Ind(String bad_Debt_Ind) {
			this.bad_Debt_Ind = bad_Debt_Ind;
		}

		/**
		 * @return the old_Bad_Debt_Ind
		 */
		public String getOld_Bad_Debt_Ind() {
			return old_Bad_Debt_Ind;
		}

		/**
		 * @param old_Bad_Debt_Ind the old_Bad_Debt_Ind to set
		 */
		public void setOld_Bad_Debt_Ind(String old_Bad_Debt_Ind) {
			this.old_Bad_Debt_Ind = old_Bad_Debt_Ind;
		}

		/**
		 * @return the int_Incr
		 */
		public String getInt_Incr() {
			return int_Incr;
		}

		/**
		 * @param int_Incr the int_Incr to set
		 */
		public void setInt_Incr(String int_Incr) {
			this.int_Incr = int_Incr;
		}

		/**
		 * @return the arr_Int_Incr
		 */
		public String getArr_Int_Incr() {
			return arr_Int_Incr;
		}

		/**
		 * @param arr_Int_Incr the arr_Int_Incr to set
		 */
		public void setArr_Int_Incr(String arr_Int_Incr) {
			this.arr_Int_Incr = arr_Int_Incr;
		}

		/**
		 * @return the short_Name
		 */
		public String getShort_Name() {
			return short_Name;
		}

		/**
		 * @param short_Name the short_Name to set
		 */
		public void setShort_Name(String short_Name) {
			this.short_Name = short_Name;
		}

		/**
		 * @return the linked_Account_No
		 */
		public String getLinked_Account_No() {
			return linked_Account_No;
		}

		/**
		 * @param linked_Account_No the linked_Account_No to set
		 */
		public void setLinked_Account_No(String linked_Account_No) {
			this.linked_Account_No = linked_Account_No;
		}

		/**
		 * @return the cheque_Book_Cnt
		 */
		public String getCheque_Book_Cnt() {
			return cheque_Book_Cnt;
		}

		/**
		 * @param cheque_Book_Cnt the cheque_Book_Cnt to set
		 */
		public void setCheque_Book_Cnt(String cheque_Book_Cnt) {
			this.cheque_Book_Cnt = cheque_Book_Cnt;
		}

		/**
		 * @return the dummyrow
		 */
		public String getDummyrow() {
			return dummyrow;
		}

		/**
		 * @param dummyrow the dummyrow to set
		 */
		public void setDummyrow(String dummyrow) {
			this.dummyrow = dummyrow;
		}
	
		
		

}
