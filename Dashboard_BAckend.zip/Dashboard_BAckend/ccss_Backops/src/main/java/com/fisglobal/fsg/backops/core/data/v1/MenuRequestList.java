package com.fisglobal.fsg.backops.core.data.v1;

import java.util.List;

public class MenuRequestList {

	private List<MenuRequest> menuRequest;

	public List<MenuRequest> getMenuRequest() {
		return menuRequest;
	}

	public void setMenuRequest(List<MenuRequest> menuRequest) {
		this.menuRequest = menuRequest;
	}

}
