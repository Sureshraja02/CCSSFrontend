/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.data;

/**
 * @author e5745290
 *
 */
public class IfsccodeSearchRequestData {

	private String ifsccode;

	/**
	 * @return the ifsccode
	 */
	public String getIfsccode() {
		return ifsccode;
	}

	/**
	 * @param ifsccode the ifsccode to set
	 */
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	
	
}
