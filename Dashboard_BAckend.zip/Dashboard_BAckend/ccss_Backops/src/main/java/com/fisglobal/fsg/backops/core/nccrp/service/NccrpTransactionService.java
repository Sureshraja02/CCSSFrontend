/**
 * 
 */
package com.fisglobal.fsg.backops.core.nccrp.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fisglobal.fsg.backops.core.common.RMSConstants;
import com.fisglobal.fsg.backops.core.nccrp.data.BankDetailsData;
import com.fisglobal.fsg.backops.core.nccrp.data.DashboardInterface;
import com.fisglobal.fsg.backops.core.nccrp.data.I4CCallBackRequest;
import com.fisglobal.fsg.backops.core.nccrp.data.I4CCallBackResponse;
import com.fisglobal.fsg.backops.core.nccrp.data.I4CRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.I4CResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.IfsccodeSearchRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.IfsccodeSearchResponseData;
import com.fisglobal.fsg.backops.core.nccrp.data.ReportInterfaceData;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchRequestData;
import com.fisglobal.fsg.backops.core.nccrp.data.TransactionSearchResponseData;
import com.fisglobal.fsg.backops.core.nccrp.entity.CcssCBSTransactionFraudDetails_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.CcssEmailCaseList;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_BankCodes_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Callback_Ack_Resp_DAO;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Cftd_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.Ccss_Trans_Details;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CCSSBankCodesRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CCSSReqAuditRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssCallbackAckRespDetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssCbsTransactionFraudDetailsRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.CcssEmailCaseListRepo;
import com.fisglobal.fsg.backops.core.nccrp.entity.repo.Ccss_CftdRepo;
import com.fisglobal.fsg.backops.core.nccrp.fileupload.data.DownloadResponseData;

/**
 * @author e5745290
 *
 */
@Service
public class NccrpTransactionService {

	@Autowired
	Ccss_CftdRepo ccssCftd;
	
	@Inject
	private Ccss_CftdRepo ccss_CftdRepo;

	@Inject
	private CcssCbsTransactionFraudDetailsRepo fraudDetailsRepo;

	@Inject
	private CcssCallbackAckRespDetailsRepo ccssCallbackAckRespDetailsRepo;

	@Inject
	private CCSSBankCodesRepo bankRepo;

	@Autowired
	CcssEmailCaseListRepo emailRepo;
	
	@Autowired
	CCSSReqAuditRepo cCSSReqAuditRepo;
	
 private static final String CSV_HEADER = "SNO,ACKNOWLEDGEMENT_NO,ACCOUNT_NO,COMPLIANT_RRN,TRANSACTION_AMOUNT,DISPUTE_AMOUNT,COMPLAINT_DATE,TRANSACTION_DATE,TRANSACTION_TIME,STATUS,REASON\n";
	 
 private static final String DIGITAL_CSV_HEADER = "SNO,ACCOUNT_NO,MOBILE_NUMBER,ACKNOWLEDGEMENT_NO,COMPLAINT_RRN\n";
 
	 private final Path fileStorageLocation = Paths.get("Report_Download").toAbsolutePath().normalize();
	 
	 private final Path fileStorageLocation1 = Paths.get("download").toAbsolutePath().normalize();
	 
	

	public Page<HashMap<String, Object>> getNccrpComplaintstatus(int pageSize, int pageNo, String ackNo) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		if (ackNo == null) {
			regList = ccss_CftdRepo.getTxnStatusbypaging(paging);
		} else {
			regList = ccss_CftdRepo.getTxnStatusbypagingwithLike(ackNo, paging);
		}
		return regList;
	}

	public Page<Ccss_Trans_Details> getTransactionHistory(int pageSize, int pageNo) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Ccss_Trans_Details> regList = null;
		return regList;
	}

	public Page<CcssEmailCaseList> getEmailCaseList(int pageSize, int pageNo) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<CcssEmailCaseList> regList = emailRepo.findAll(paging);
		return regList;
	}

	public CcssEmailCaseList storeEmailCaseList(CcssEmailCaseList caseList) {

		System.out.println(caseList);

		return emailRepo.save(caseList);

	}

	public Page<Ccss_Cftd_Details> getNccrpComplaintHistory(int pageSize, int pageNo) {
		return this.getNccrpComplaintHistory(pageSize, pageNo, null);
	}

	public Page<Ccss_Cftd_Details> getNccrpComplaintHistory(int pageSize, int pageNo, String ackNo) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Ccss_Cftd_Details> regList = null;
		if (ackNo == null) {
			regList = ccss_CftdRepo.findAll(paging);
		} else {
			regList = ccss_CftdRepo.findByAcknowledgementNoContaining(ackNo, paging);
		}
		return regList;
	}

	public TransactionSearchResponseData transactionSearchPage(
			TransactionSearchRequestData transactionSearchRequestData) {

		int recordSize = 1;
		String ackNo = "";
		TransactionSearchResponseData rsponse = new TransactionSearchResponseData();
		List<I4CCallBackRequest> i4CCallBackRequest = new ArrayList<I4CCallBackRequest>();
		List<I4CRequestData> i4CRequestDataList = new ArrayList<I4CRequestData>();
		List<I4CCallBackResponse> i4CCallBackResponse = new ArrayList<I4CCallBackResponse>();
		List<I4CResponseData> i4CResponseData = new ArrayList<I4CResponseData>();

		List<Ccss_Cftd_Details> ccssCftdList = ccss_CftdRepo.getCftd_Details(
				transactionSearchRequestData.getAcknowledgementNo(), transactionSearchRequestData.getAcctNo(),
				transactionSearchRequestData.getTransactionId());
		if (!ccssCftdList.isEmpty()) {
			for (Ccss_Cftd_Details ccssCftd : ccssCftdList) {
				I4CRequestData i4CRequestData = new I4CRequestData();
				i4CRequestData.setsNo(recordSize);
				i4CRequestData.setAcctNo(ccssCftd.getPayerAccountNumber());
				i4CRequestData.setAcknowledgementNo(ccssCftd.getAcknowledgementNo());
				i4CRequestData.setMobileNo(ccssCftd.getPayerMobileNumber());
				i4CRequestData.setTransactionId(ccssCftd.getTransactionId());
				i4CRequestData.setAmount(ccssCftd.getAmount());
				i4CRequestData.setDisputedAmount(String.valueOf(ccssCftd.getDisputedAmount()));
				i4CRequestData.setDistrict(ccssCftd.getDistrict());
				i4CRequestData.setState(ccssCftd.getState());
				i4CRequestData.setHoldStatus(ccssCftd.getHoldStatus());
				i4CRequestData.setModeOfPayment(ccssCftd.getModeOfPayment());
				i4CRequestData.setMobileNo(ccssCftd.getPayerMobileNumber());
				i4CRequestData.setSubCategory(ccssCftd.getSubCategory());
				i4CRequestData.setPayerBank(ccssCftd.getPayerBank());
				i4CRequestData.setTransactionDate(ccssCftd.getTransactionDate());
				//i4CRequestData.setComplaintDate(ccssCftd.getComplaintDate());
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate = dateFormat.format(ccssCftd.getEntryDate());
				i4CRequestData.setComplaintDate(strDate);
				i4CRequestDataList.add(i4CRequestData);
				recordSize++;
			}
			recordSize = 1;
		}
		List<CcssCBSTransactionFraudDetails_DAO> CcssCBSTransactionFraudDetails = fraudDetailsRepo
				.getFraudDetailByAccntAndRrnAndAckNumber(transactionSearchRequestData.getTransactionId(),
						transactionSearchRequestData.getAcctNo(), transactionSearchRequestData.getAcknowledgementNo());
		if (!CcssCBSTransactionFraudDetails.isEmpty()) {
			for (CcssCBSTransactionFraudDetails_DAO fraudDao : CcssCBSTransactionFraudDetails) {
				I4CCallBackRequest callbackRequest = new I4CCallBackRequest();
				callbackRequest.setsNo(recordSize);
				callbackRequest.setAcctNo(fraudDao.getAccountNo());
				callbackRequest.setAcknowledgementNo(fraudDao.getAcknowledgementNo());
				callbackRequest.setAmount(fraudDao.getAmount());
				callbackRequest.setAtmBranch(fraudDao.getAtmBranch());
				callbackRequest.setAtmId(fraudDao.getAtmId());
				callbackRequest.setAtmPlace(fraudDao.getAtmPlace());
				callbackRequest.setBeneName(fraudDao.getBeneName());
				callbackRequest.setBeneRemiAcctNum(fraudDao.getBeneRemiAcctNum());
				callbackRequest.setBeneRemiBank(fraudDao.getBeneRemiBank());
				callbackRequest.setBeneRemiIfsc(fraudDao.getBeneRemiIfsc());
				callbackRequest.setBeneBankCode(fraudDao.getBeneBankCode());
				callbackRequest.setChannel(fraudDao.getChannel());
				callbackRequest.setComplaintRrn(fraudDao.getComplaintRrn());
				callbackRequest.setDisputeBalance(fraudDao.getDisputeBalance());
				callbackRequest.setFraud_Fg(fraudDao.getFraud_Fg());
				callbackRequest.setFraudStatus(fraudDao.getFraudStatus());
				callbackRequest.setMerchantId(fraudDao.getMerchantId());
				callbackRequest.setRemarks(fraudDao.getRemarks());
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate = dateFormat.format(fraudDao.getCreatedDate());
				callbackRequest.setComplaintDate(strDate);
				i4CCallBackRequest.add(callbackRequest);
				recordSize++;

			}
			recordSize = 1;
		}

		if (ccssCftdList != null && !ccssCftdList.isEmpty()) {
			ackNo = ccssCftdList.get(0).getAcknowledgementNo();
			if (ackNo != null) {
				List<Ccss_Callback_Ack_Resp_DAO> ccss_Callback_Ack_Resp_DAO = ccssCallbackAckRespDetailsRepo
						.getCallBackAckResponseByAckType("BANK", ackNo);
				if (!ccss_Callback_Ack_Resp_DAO.isEmpty()) {
					for (Ccss_Callback_Ack_Resp_DAO respDao : ccss_Callback_Ack_Resp_DAO) {
						I4CCallBackResponse callBackresponseData = new I4CCallBackResponse();
						callBackresponseData.setsNo(recordSize);
						callBackresponseData.setAcknowledgementNo(respDao.getAcknowledgementNo());
						callBackresponseData.setResponseCode(respDao.getRespCode());
						callBackresponseData.setResponseMsg(respDao.getRespMsg());
						callBackresponseData.setMessage(respDao.getMessage());
						SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
						String strDate = dateFormat.format(respDao.getEntryDateTime());
						callBackresponseData.setComplaintDate(strDate);
						i4CCallBackResponse.add(callBackresponseData);
					}
					recordSize = 1;
				}

				List<Ccss_Callback_Ack_Resp_DAO> ccss_Callback_Ack_rsp = ccssCallbackAckRespDetailsRepo
						.getCallBackAckResponseByAckType("I4C", ackNo);
				if (!ccss_Callback_Ack_rsp.isEmpty()) {
					for (Ccss_Callback_Ack_Resp_DAO respDao : ccss_Callback_Ack_rsp) {
						I4CResponseData callBackAck = new I4CResponseData();
						callBackAck.setsNo(recordSize);
						callBackAck.setAcknowledgementNo(respDao.getAcknowledgementNo());
						callBackAck.setResponseCode(respDao.getRespCode());
						callBackAck.setResponseMsg(respDao.getRespMsg());
						callBackAck.setMessage(respDao.getMessage());
						SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
						String strDate = dateFormat.format(respDao.getEntryDateTime());
						callBackAck.setComplaintDate(strDate);
						i4CResponseData.add(callBackAck);
					}
					recordSize = 1;
				}
			}

		}

		rsponse.setI4CCallBackRequest(i4CCallBackRequest);
		rsponse.setI4CRequestData(i4CRequestDataList);
		rsponse.setI4CCallBackResponse(i4CCallBackResponse);
		rsponse.setI4CResponseData(i4CResponseData);

		return rsponse;
	}

	public IfsccodeSearchResponseData ifsccodesearch(IfsccodeSearchRequestData request) {

		int recordSize = 1;
		IfsccodeSearchResponseData response = new IfsccodeSearchResponseData();
		List<BankDetailsData> bankDetailsList = new ArrayList<BankDetailsData>();
		List<Ccss_BankCodes_DAO> bankDetails = bankRepo.getBankDetailSByIfsccode(request.getIfsccode());
		if (bankDetails != null && !bankDetails.isEmpty()) {
			for (Ccss_BankCodes_DAO bankDao : bankDetails) {
				BankDetailsData bankDetail = new BankDetailsData();
				bankDetail.setBankCode(bankDao.getBankCode());
				bankDetail.setsNo(recordSize);
				bankDetail.setBankName(bankDao.getBankName());
				bankDetail.setIfscCode(bankDao.getBankIfscCode());
				bankDetailsList.add(bankDetail);
				recordSize++;
			}

		}
		response.setBankDetails(bankDetailsList);
		return response;
	}
	
	public Page<HashMap<String, Object>> getFullySuccessRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			//regList = ccss_CftdRepo.getFullyProcessedRecord(sd.getTime(), ed.getTime(), paging);
			
			regList=cCSSReqAuditRepo.readFullySuccessCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getDigitalBlockRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			//regList = ccss_CftdRepo.getFullyProcessedRecord(sd.getTime(), ed.getTime(), paging);
			
			regList=cCSSReqAuditRepo.readDigitalBlockCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getPartialSuccessRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readPartialSuccessCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getFullyFailedRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readFullyFailedCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public DownloadResponseData downlaodPartialSuccessRecord(int pageSize, int pageNo, String timeline) {
		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadPartialSuccessCountDetails(sd.getTime(), ed.getTime());
		
			
			if(regList!=null && !regList.isEmpty())
			{
				

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
			
		return downloadresp;
	}
	
	public DownloadResponseData downloadFullyFailedRecord(int pageSize, int pageNo, String timeline) {

		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadFullyFailedCountDetails(sd.getTime(), ed.getTime());
		
			if(regList!=null && !regList.isEmpty())
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
			
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
		return downloadresp;
	}
	
	public DownloadResponseData downlaodFullySuccessRecord(int pageSize, int pageNo, String timeline) {
		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadFullySuccessCountDetails(sd.getTime(), ed.getTime());
		
			
			if(regList!=null && !regList.isEmpty())
			{
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					 strDate = dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
			
		return downloadresp;
	}
	
	public DownloadResponseData downlaodDigitalBlockRecords(int pageSize, int pageNo, String timeline) {
		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(DIGITAL_CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			
			 List<DashboardInterface> list= ccssCftd.getDigitalBlock(sd.getTime(), ed.getTime());
			
			 if (list != null && !list.isEmpty()) {
					downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
					 for(DashboardInterface entity:list)
						{
						 csvContent.append(sNo).append(",")
						 .append(entity.getAccountNo()).append(",")
						 .append(entity.getMobileNo()).append(",")
						 .append(entity.getAcknowlegementNo()).append(",");
			           
			              if(StringUtils.isNotBlank(entity.getComplaintRrn()))
			              {
			            	  csvContent.append(entity.getComplaintRrn()).append("\n");  
			              }else
			              {
			            	  csvContent.append("").append("\n");  
			              }
			             
			             
						 sNo++;
						}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
			
		return downloadresp;
	}
	
	public Page<HashMap<String, Object>> getFullyFailedTechnicalRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readFullyFailedTechnicalCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getPartialSuccessTechnicalRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readPartialSuccessTechnicalCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getFullyFailedBusinessRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readFullyFailedBusinessCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	public Page<HashMap<String, Object>> getPartialSuccessBusinessRecord(int pageSize, int pageNo, String timeline) {

		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<HashMap<String, Object>> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.readPartialSuccessBusinessCountDetails(sd.getTime(), ed.getTime(), paging);
		
		return regList;
	}
	
	
	public DownloadResponseData downlaodPartialSuccessTechnicalRecord(int pageSize, int pageNo, String timeline) {
		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadPartialSuccessTechnicalCountDetails(sd.getTime(), ed.getTime());
		
			
			if(regList!=null && !regList.isEmpty())
			{
				

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
			
		return downloadresp;
	}
	
	public DownloadResponseData downlaodPartialSuccessBusinessRecord(int pageSize, int pageNo, String timeline) {
		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadPartialSuccessBusinessCountDetails(sd.getTime(), ed.getTime());
		
			
			if(regList!=null && !regList.isEmpty())
			{
				

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
			
		return downloadresp;
	}
	
	public DownloadResponseData downloadFullyFailedTechnicalRecord(int pageSize, int pageNo, String timeline) {

		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadFullyFailedTechnicalCountDetails(sd.getTime(), ed.getTime());
		
			if(regList!=null && !regList.isEmpty())
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
			
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
		return downloadresp;
	}
	
	public DownloadResponseData downloadFullyFailedBusinessRecord(int pageSize, int pageNo, String timeline) {

		DownloadResponseData downloadresp=new DownloadResponseData();
		
		int sNo=1;
		
		long startTime = System.currentTimeMillis();
		String filename=String.valueOf(startTime)+".csv";
		downloadresp.setFileName(filename);

		 StringBuilder csvContent = new StringBuilder();
	        csvContent.append(CSV_HEADER);

		
		 Path targetLocation = this.fileStorageLocation1.resolve(filename);
		Pageable paging = PageRequest.of(pageNo, pageSize);
		List<ReportInterfaceData> regList = null;
		 
		Date startDate = new Date();
		Calendar sd = Calendar.getInstance();
		sd.setTime(startDate);

		Date endDate = new Date();
		Calendar ed = Calendar.getInstance();
		ed.setTime(endDate);

		switch (timeline.toString().toUpperCase()) {

		case "TODAY":
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

//			ed.set(Calendar.HOUR_OF_DAY, 23);
//			ed.set(Calendar.MINUTE, 59);
//			ed.set(Calendar.SECOND, 59);
//			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "YESTERDAY":
			sd.add(Calendar.DAY_OF_MONTH, -1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "DAYBYESTER":
			sd.add(Calendar.DAY_OF_MONTH, -2);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.DAY_OF_MONTH, -2);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		case "MONTH":
			sd.set(Calendar.DAY_OF_MONTH, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			
			ed.add(Calendar.DAY_OF_MONTH, -1);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);

			break;
		case "7DAY":
			sd.add(Calendar.DAY_OF_MONTH, -7);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "YTD":
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);
			break;
		case "LY":
			sd.add(Calendar.YEAR, -1);
			sd.set(sd.get(Calendar.YEAR), Calendar.JANUARY, 1);
			sd.set(Calendar.HOUR_OF_DAY, 0);
			sd.set(Calendar.MINUTE, 0);
			sd.set(Calendar.SECOND, 0);
			sd.set(Calendar.MILLISECOND, 0);

			ed.add(Calendar.YEAR, -1);
			ed.set(ed.get(Calendar.YEAR), Calendar.DECEMBER, 31);
			ed.set(Calendar.HOUR_OF_DAY, 23);
			ed.set(Calendar.MINUTE, 59);
			ed.set(Calendar.SECOND, 59);
			ed.set(Calendar.MILLISECOND, 999);
			break;
		default:
			break;

		}

		System.out.println(sd.getTime());
		System.out.println(ed.getTime());
			regList = cCSSReqAuditRepo.downloadFullyFailedBusinessCountDetails(sd.getTime(), ed.getTime());
		
			if(regList!=null && !regList.isEmpty())
			{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a");
				String strDate=null;
			
				for(ReportInterfaceData cCSS_REQ_Audit_DAO:regList)
				{
					strDate= dateFormat.format(cCSS_REQ_Audit_DAO.getEntryDate());
					
					 csvContent.append(sNo).append(",")
					 .append(cCSS_REQ_Audit_DAO.getAcknowledgementNo()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getPayerAccountNumber()).append(",")
					 .append(cCSS_REQ_Audit_DAO.getRrn()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getAmount()).append(",")		                     
                      .append(cCSS_REQ_Audit_DAO.getDisputedAmount()).append(",")		                      
                      .append(strDate).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransDate()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getTransTIme()).append(",")
                      .append(cCSS_REQ_Audit_DAO.getStatus()).append(",")	
					 .append(cCSS_REQ_Audit_DAO.getStatusReason()).append("\n");	
				
					 sNo++;
				}
			
				try {
					targetLocation.toFile().createNewFile();
				 
				 OutputStream os = new FileOutputStream(targetLocation.toFile());
		         os.write(csvContent.toString().getBytes());
		         downloadresp.setStatus(RMSConstants.SUCCESS_CODE);
		         
				}
		         catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				downloadresp.setStatus(RMSConstants.FAILURE_CODE);
				downloadresp.setStatusDesc("No record Found for the Date");
			}
			
		return downloadresp;
	}
	
}
