package com.fisglobal.fsg.backops.core.common;

public interface RMSConstants {
	
	public static final String DEDUPCHECK_CODE = "259";
	public static final String DEDUPCHECK_MESSAGE = "Data already exists in the hierarchy";
	
	public static final String INVALID_DIGITAL_SIGNATURE_CODE="999";
	public static final String INVALID_DIGITAL_SIGNATURE_MSG="Invalid Digital Signature";

	public static final String INVALID_CREDENTIALS_CODE="B-101";
	public static final String INVALID_CREDENTIALS_MSG="Invalid Credentials";
	
	public static final String INVALID_CONFIG_CODE="B-102";
	public static final String INVALID_CONFIG_MSG="Invalid Property Name";
	
	public static final String INVALID_REQUEST_CODE="B-103";
	public static final String INVALID_REQUEST_MSG="Invalid Request";
	
	public static final String INVALID_GRP_CODE="B-104";
	public static final String INVALID_GRP_MSG="Invalid Group";

	public static final String SUCCESS_CODE="00";
	public static final String SUCCESS_MSG="success";
	
	public static final String VALIDATION_ERROR_CODE="B-104";
	public static final String VALIDATION_ERROR_MSG="Validation failed";
	
	
	public static final String orgNameCode="100001";
	public static final String orgLogoCode="100002";
	public static final String INSTORGCode="100003";
	public static final String orgIDCode="100004";
	public static final String orgPrimaryColorCode="100005";
	public static final String orgSecondaryColorCode="100006";
	public static final String createdUserIDCode="100007";
	public static final String appInfoColorCode="100008";
	public static final String appWarningColorCode="100009";
	public static final String appSuccessColorCode="100010";
	public static final String appDangerColorCode="100011";
	
	public static final String userIdCode="100012";
	public static final String passwordCode="100013";
	public static final String userNameCode="100014";
	public static final String userTypeCode="100015";
	public static final String groupIdCode="100016";
	public static final String instidCode="100017";
	public static final String mobileNoCode="100018";
	public static final String emailCode="100019";
	

public static final String SUCCESS = "Success";
public static final String FAILURE_CODE = "01";
public static final String FAILURE_MSG = "Failure";
public static final String I4C_FAILURE = "32";
public static final String HOLD_REASON = "01-Collateral";


public static final String SYNC_CALL = "SYNC-CALL";
public static final String ASYNC_CALL = "ASYNC-CALL";
public static final String I4C_KEYMSTR = "I4CKeymaster";

}
