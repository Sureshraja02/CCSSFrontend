package com.fisglobal.fsg.backops.core.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fisglobal.fsg.backops.core.entity.pk.Group_Master_PK;

@Table(name = "GROUP_MASTER")
@Entity
@IdClass(Group_Master_PK.class)
public class Group_Master implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "GROUPID")
	private String groupId;

	@Column(name = "GROUPNAME")
	private String groupName;

	@Column(name = "MAKERID")
	private String makerId;

	@Column(name = "CHECKERID")
	private String checkerId;

	@Id
	@Column(name = "TID")
	private String tid;

	@Id
	@Column(name = "SID")
	private String sid;

	@Column(name = "MODIFIEDDATE")
	private LocalDateTime modifiedDate;

	@Column(name = "INSERTEDDATE")
	private LocalDateTime insertedDate;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getMakerId() {
		return makerId;
	}

	public void setMakerId(String makerId) {
		this.makerId = makerId;
	}

	public String getCheckerId() {
		return checkerId;
	}

	public void setCheckerId(String checkerId) {
		this.checkerId = checkerId;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public LocalDateTime getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public LocalDateTime getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(LocalDateTime insertedDate) {
		this.insertedDate = insertedDate;
	}

}
